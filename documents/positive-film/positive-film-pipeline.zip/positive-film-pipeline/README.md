# Positive Film - analysis pipeline

Code used to measure the Ricoh GR Positive Film look (study: positive-film-study.md, tool: https://cardopoli.github.io/enricopolicardo.com/tools/positive-film/).

## Requirements
Python 3.10+ and: `pip install rawpy colour-science scikit-image scikit-learn scipy numpy pillow`

## Data
Not included. Put RAW + in-camera JPEG pairs from the same frame in `data/` (shot as RAW+JPEG with the look you want to measure, default settings) and list them in `python/pairs.py`. Daylight frames with a spread of colours work best; aim for at least four.

## Run (from the python/ folder, in this order)
1. `render.py` - develops each RAW to linear XYZ (camera white balance, no curve), aligns it to its JPEG, saves `aligned.npz`
2. `fit.py` - masks unusable pixels, fits the shared tone curve (prints exposure offsets and the curve table)
3. `fit2.py`, `model.py` - first colour fits (exploratory; `model.py` defines the band weighting used later)
4. `validate.py` - compares luminance-only and per-channel curve baselines
5. `model2.py` - fits the colour stage on top of the per-channel curve, with leave-one-out validation
6. `final.py` - smooths the curve, refits, prints accuracy and writes `formula.json`
7. `vis.py` - optional side-by-side comparison image

Later scripts reuse parts of earlier ones with `exec()`, so keep them together and run them in order. The `ref=` frame in `fit.py` anchors exposure; any well-exposed daylight frame works.

## JavaScript
`js/pf-core.js` is the formula as an ES module, as used by the web tool: `pixel(r, g, b, out, offset, colourAmount)` takes linear sRGB with camera white balance (1.0 = raw clip) and writes linear sRGB.

## Licence
Free to use, change and share. Credit appreciated: Enrico Policardo, Positive Film study (2026).
