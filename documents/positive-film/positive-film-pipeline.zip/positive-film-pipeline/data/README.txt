Put RAW + JPEG pairs here.
