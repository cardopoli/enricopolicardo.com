import numpy as np,colour,pickle,json
from scipy.ndimage import gaussian_filter1d
exec(open('model.py').read().split("X=[];yC")[0])   # S, ir, offs, WP, hw, lw, HB, LB
# smooth monotone table, 0.05 stop grid
st=np.arange(-8,3.0001,0.05); Lt=ir.predict(np.log2(0.18)+st)
Ls=gaussian_filter1d(Lt,3,mode='nearest'); Ls=np.maximum.accumulate(Ls); Ls[st>=2.5]=Ls[st>=2.5].max()
Ls=np.clip(Ls,0,100)
def L2Y(L): return np.where(L>8,((L+16)/116)**3,L/903.3)
def curveY(c): return L2Y(np.interp(np.log2(np.clip(c,1e-9,None)/0.18),st,Ls))
def perchannel(x):
    rgb=np.clip(colour.XYZ_to_RGB(x,'sRGB',apply_cctf_encoding=False),1e-9,None)
    return colour.XYZ_to_Lab(colour.RGB_to_XYZ(curveY(rgb),'sRGB',apply_cctf_decoding=False),WP)
PC={n:(perchannel(x),lj) for n,(x,lj) in S.items()}
pickle.dump(PC,open('pc.pkl','wb'))
src=open('model2.py').read(); exec(src[src.index("def lch"):src.index("full=build")])
full=build(names)
print('image      curve only   full formula   leave-one-out')
for n in names:
    b,lj=PC[n]; lo=build([k for k in names if k!=n])
    print(f"{n:9s}    {de(b,lj):5.2f}        {de(apply(full,b),lj):5.2f}          {de(apply(lo,b),lj):5.2f}")
for i,(bn,c) in enumerate(HB): print(f"{bn:9s}  {(np.exp(full['gh'][i])-1)*100:+5.0f}%  {full['dh'][i]:+6.1f}°  {full['dl'][i]:+5.1f}")
print('L sat',np.round(np.exp(full['gl']),2),'L dl',np.round(full['dl'][8:],1),'cast',np.round(full['cast'],2))
pickle.dump(full,open('full.pkl','wb'))
F=dict(name='Ricoh GR Positive Film (original GR, 2013)',version='0.1',date='2026-11-17',
  curve=dict(stops=[round(float(s),2) for s in st],Lstar=[round(float(v),3) for v in Ls],note='Input: linear RGB channel value, 1.0 = raw clip, mid grey 0.18. Output: CIE L*. Apply to R, G and B separately.'),
  hue_bands=[dict(name=b,centre=c) for b,c in HB],light_bands=LB,
  sat_log_hue=[round(float(v),4) for v in full['gh']],sat_log_light=[round(float(v),4) for v in full['gl']],
  hue_shift=[round(float(v),3) for v in full['dh']],lightness_shift=[round(float(v),3) for v in full['dl']],
  grey_cast_ab=[round(float(v),3) for v in full['cast']])
json.dump(F,open('formula.json','w'),indent=1)
