import numpy as np,colour
from scipy.ndimage import gaussian_filter,sobel
from sklearn.isotonic import IsotonicRegression
D=np.load('aligned.npz'); names=[k[:-2] for k in D if k.endswith('_x')]
WP=colour.CCS_ILLUMINANTS['CIE 1931 2 Degree Standard Observer']['D65']
def lab_of_jpg(j): return colour.XYZ_to_Lab(colour.sRGB_to_XYZ(j),WP)
S={}
for n in names:
    x=D[n+'_x'];j=D[n+'_j']
    x=np.stack([gaussian_filter(x[...,c],1.2) for c in range(3)],-1); j=np.stack([gaussian_filter(j[...,c],1.2) for c in range(3)],-1)
    lj=lab_of_jpg(j)
    g=np.hypot(sobel(np.log(x[...,1]+1e-3),0),sobel(np.log(x[...,1]+1e-3),1))
    ok=(x.max(-1)<0.95*x.max())&(x[...,1]>1e-4)&(j.max(-1)<0.985)&(j.min(-1)>0.01)&(g<np.percentile(g,70))
    m=8;ok[:m]=ok[-m:]=False;ok[:,:m]=ok[:,-m:]=False
    S[n]=(x[ok],lj[ok])
    print(n,'usable px',ok.sum())
# ---- tone curve on near-neutral pixels, with per-image exposure offset
def neutral(x,lj): return np.hypot(lj[:,1],lj[:,2])<6
ref=names[0]; off={ref:0.0}
def curve_fit(offs):
    X=[];Y=[]
    for n,(x,lj) in S.items():
        s=neutral(x,lj); X.append(np.log2(x[s,1])+offs[n]); Y.append(lj[s,0])
    X=np.concatenate(X);Y=np.concatenate(Y)
    ir=IsotonicRegression(out_of_bounds='clip').fit(X,Y); return ir,np.mean((ir.predict(X)-Y)**2)
offs={n:0.0 for n in S}
for it in range(3):
    for n in S:
        if n==ref: continue
        best=None
        for e in np.arange(-2,2.01,0.05):
            o=dict(offs);o[n]=e; ir,mse=curve_fit(o)
            if best is None or mse<best[0]: best=(mse,e)
        offs[n]=best[1]
ir,mse=curve_fit(offs)
print('exposure offsets (stops)',{k:round(v,2) for k,v in offs.items()},'curve rms L*',round(mse**.5,2))
# curve table: scene stops relative to mid grey (Y=0.18 at ref exposure)
pts=np.arange(-6,3.01,0.5)
print('scene stops vs 18% grey -> output L*:')
print(' '.join(f"{p:+.1f}:{ir.predict([np.log2(0.18)+p])[0]:.1f}" for p in pts))
np.save('curve.npy',np.stack([pts,ir.predict(np.log2(0.18)+pts)]))
# ---- colour: neutral render = keep chromaticity, set L via curve
bands=[('red',20),('orange',50),('yellow',85),('green',135),('aqua',190),('blue',250),('purple',300),('magenta',340)]
rows=[];allp=[]
for n,(x,lj) in S.items():
    Lt=ir.predict(np.log2(x[:,1])+offs[n])
    Yt=colour.models.cie_lab.intermediate_luminance_function_CIE1976 if False else None
    Ynew=np.where(Lt>8,((Lt+16)/116)**3,Lt/903.3)
    xs=x*(Ynew/x[:,1])[:,None]
    ls=colour.XYZ_to_Lab(xs,WP)
    allp.append((n,ls,lj))
def lch(l): return l[:,0],np.hypot(l[:,1],l[:,2]),np.degrees(np.arctan2(l[:,2],l[:,1]))%360
res={}
print('\nband      n_px  dL    chroma%   hue°   (per image chroma%)')
for b,c in bands:
    dLs=[];cr=[];dh=[];per={}
    for n,ls,lj in allp:
        L1,C1,h1=lch(ls);L2,C2,h2=lch(lj)
        w=(np.abs((h1-c+180)%360-180)<20)&(C1>10)&(L1>15)&(L1<92)
        if w.sum()<30: continue
        dLs.append(L2[w]-L1[w]);cr.append(C2[w]/C1[w]);dh.append((h2[w]-h1[w]+180)%360-180)
        per[n]=round((np.median(C2[w]/C1[w])-1)*100)
    if not dLs: print(b,'no data');continue
    dLs=np.concatenate(dLs);cr=np.concatenate(cr);dh=np.concatenate(dh)
    res[b]=(len(dLs),np.median(dLs),(np.median(cr)-1)*100,np.median(dh))
    print(f"{b:8s}{len(dLs):7d} {np.median(dLs):+5.1f}  {(np.median(cr)-1)*100:+5.0f}%  {np.median(dh):+6.1f}   {per}")
# neutral cast
cast=[]
for n,ls,lj in allp:
    L1,C1,h1=lch(ls); w=C1<3
    cast.append(np.median(lj[w,1:],0))
print('grey cast a*,b* per image',{allp[i][0]:np.round(cast[i],1) for i in range(len(allp))})
np.save('bands.npy',np.array([[c,*res[b][1:]] if b in res else [c,0,0,0] for b,c in bands]))
import pickle;pickle.dump((offs,),open('offs.pkl','wb'))
