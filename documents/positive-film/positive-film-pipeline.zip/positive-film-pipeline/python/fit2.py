import numpy as np,colour,pickle
from scipy.ndimage import gaussian_filter,sobel
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import HuberRegressor
exec(open('fit.py').read().split('# ---- colour')[0].replace("print(","(lambda *a,**k:None)("))
WP=colour.CCS_ILLUMINANTS['CIE 1931 2 Degree Standard Observer']['D65']
def lch(l): return l[:,0],np.hypot(l[:,1],l[:,2]),np.degrees(np.arctan2(l[:,2],l[:,1]))%360
P={}
for n,(x,lj) in S.items():
    Lt=ir.predict(np.log2(x[:,1])+offs[n]); Yn=np.where(Lt>8,((Lt+16)/116)**3,Lt/903.3)
    ls=colour.XYZ_to_Lab(x*(Yn/x[:,1])[:,None],WP); P[n]=(lch(ls),lch(lj),ls,lj)
bands=[('red',20),('orange',50),('yellow',85),('green',135),('aqua',190),('blue',250),('purple',300),('magenta',340)]
print('band     px     chroma gain(all)  hue shift  dL   | gain per image')
OUT=[]
for b,c in bands:
    A=[];per={}
    for n,((L1,C1,h1),(L2,C2,h2),_,_) in P.items():
        w=(np.abs((h1-c+180)%360-180)<22)&(C1>15)&(L1>20)&(L1<88)
        if w.sum()<150: continue
        hr=HuberRegressor(fit_intercept=False).fit(C1[w,None],C2[w])
        per[n]=round(hr.coef_[0],2); A.append((C1[w],C2[w],(h2[w]-h1[w]+180)%360-180,L2[w]-L1[w]))
    if not A: print(b,'no data'); OUT.append((b,c,None,None,None));continue
    C1=np.concatenate([a[0] for a in A]);C2=np.concatenate([a[1] for a in A])
    g=HuberRegressor(fit_intercept=False).fit(C1[:,None],C2).coef_[0]
    dh=np.median(np.concatenate([a[2] for a in A]));dL=np.median(np.concatenate([a[3] for a in A]))
    OUT.append((b,c,g,dh,dL))
    print(f"{b:8s}{len(C1):6d}   x{g:.2f} ({(g-1)*100:+.0f}%)      {dh:+6.1f}°  {dL:+5.1f} | {per}")
# chroma gain vs lightness (all hues)
print('\nchroma gain by lightness band:')
for lo,hi in [(20,40),(40,60),(60,80),(80,90)]:
    c1=[];c2=[]
    for n,((L1,C1,h1),(L2,C2,h2),_,_) in P.items():
        w=(C1>15)&(L1>=lo)&(L1<hi); c1.append(C1[w]);c2.append(C2[w])
    c1=np.concatenate(c1);c2=np.concatenate(c2)
    print(f" L{lo}-{hi}: x{HuberRegressor(fit_intercept=False).fit(c1[:,None],c2).coef_[0]:.2f}  ({len(c1)} px)")
print('\ngrey cast by lightness (a*, b*):')
for lo,hi in [(10,30),(30,50),(50,70),(70,90)]:
    v=[];
    for n,((L1,C1,h1),_,ls,lj) in P.items():
        w=(C1<3)&(L1>=lo)&(L1<hi); v.append(lj[w,1:]-ls[w,1:])
    v=np.concatenate(v); print(f" L{lo}-{hi}: a{np.median(v[:,0]):+.1f} b{np.median(v[:,1]):+.1f} ({len(v)} px)")
pickle.dump(OUT,open('bands.pkl','wb'))
