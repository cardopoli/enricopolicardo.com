import numpy as np,colour,pickle
from sklearn.linear_model import HuberRegressor
exec(open('fit2.py').read().split("bands=[")[0])
HB=[('red',20),('orange',50),('yellow',85),('green',135),('aqua',190),('blue',250),('purple',300),('magenta',340)]
LB=[25,45,65,85]
def hw(h):  # circular linear interpolation weights over hue bands
    c=np.array([b[1] for b in HB]);W=np.zeros((len(h),len(c)))
    for i,hh in enumerate(h):
        d=(hh-c+180)%360-180; j=np.argsort(np.abs(d))[:2]; dd=np.abs(d[j]); W[i,j]=1-dd/dd.sum()
    return W
def lw(L):
    W=np.zeros((len(L),len(LB)));Lc=np.clip(L,LB[0],LB[-1])
    for i,l in enumerate(Lc):
        k=min(np.searchsorted(LB,l),len(LB)-1);k=max(k,1);t=(l-LB[k-1])/(LB[k]-LB[k-1]);W[i,k-1]=1-t;W[i,k]=t
    return W
X=[];yC=[];yH=[];yL=[]
rng=np.random.default_rng(0)
for n,((L1,C1,h1),(L2,C2,h2),_,_) in P.items():
    w=np.where((C1>12)&(L1>15)&(L1<90))[0]; w=rng.choice(w,min(len(w),8000),replace=False)
    X.append(np.hstack([hw(h1[w]),lw(L1[w])])); yC.append(np.log(C2[w]/C1[w])); yH.append((h2[w]-h1[w]+180)%360-180); yL.append(L2[w]-L1[w])
X=np.vstack(X);yC=np.concatenate(yC);yH=np.concatenate(yH);yL=np.concatenate(yL)
nh=len(HB)
# chroma: log gain = hue term + lightness term (lightness anchored so L65 term = 0 for identifiability)
Xc=np.delete(X,nh+2,axis=1)
mc=HuberRegressor(fit_intercept=False,max_iter=500,alpha=1e-3).fit(Xc,yC)
gh=mc.coef_[:nh]; gl=np.insert(mc.coef_[nh:],2,0.0)
mh=HuberRegressor(fit_intercept=False,max_iter=500,alpha=1e-3).fit(X[:,:nh],yH)
ml=HuberRegressor(fit_intercept=False,max_iter=500,alpha=1e-3).fit(X[:,:nh],yL)
print('HUE BAND   saturation   hue shift   lightness')
for i,(b,c) in enumerate(HB):
    print(f"{b:9s}  {(np.exp(gh[i])-1)*100:+5.0f}%      {mh.coef_[i]:+5.1f}°     {ml.coef_[i]:+5.1f}")
print('LIGHTNESS  saturation multiplier (relative to L65)')
for L,g in zip(LB,gl): print(f"  L{L}:  x{np.exp(g):.2f}")
M=dict(HB=HB,LB=LB,gh=gh,gl=gl,dh=mh.coef_,dl=ml.coef_,cast=(1.7,-0.9))
pickle.dump(M,open('model.pkl','wb'))
