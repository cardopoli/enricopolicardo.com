import numpy as np,colour,pickle
from sklearn.linear_model import HuberRegressor
exec(open('model.py').read().split("X=[];yC")[0])
PC=pickle.load(open('pc.pkl','rb'))
def lch(l): return l[:,0],np.hypot(l[:,1],l[:,2]),np.degrees(np.arctan2(l[:,2],l[:,1]))%360
names=list(PC); rng=np.random.default_rng(1)
def build(train):
    X=[];yC=[];yH=[];yL=[];cast=[]
    for n in train:
        b,lj=PC[n];L1,C1,h1=lch(b);L2,C2,h2=lch(lj)
        g=C1<3; cast.append(lj[g,1:]-b[g,1:])
        w=np.where((C1>10)&(L1>12)&(L1<92))[0]; w=rng.choice(w,min(len(w),8000),replace=False)
        X.append(np.hstack([hw(h1[w]),lw(L1[w])])); yC.append(np.log(C2[w]/C1[w])); yH.append((h2[w]-h1[w]+180)%360-180); yL.append(L2[w]-L1[w])
    X=np.vstack(X);nh=len(HB)
    Xc=np.delete(X,nh+2,axis=1)
    mc=HuberRegressor(fit_intercept=False,max_iter=1000,alpha=1e-3).fit(Xc,np.concatenate(yC))
    mh=HuberRegressor(fit_intercept=False,max_iter=1000,alpha=1e-3).fit(X[:,:nh],np.concatenate(yH))
    ml=HuberRegressor(fit_intercept=False,max_iter=1000,alpha=1e-3).fit(X,np.concatenate(yL))
    return dict(gh=mc.coef_[:nh],gl=np.insert(mc.coef_[nh:],2,0.0),dh=mh.coef_,dl=ml.coef_,cast=np.median(np.concatenate(cast),0))
def apply(m,b):
    L,C,h=lch(b); Wh=hw(h);Wl=lw(L)
    C2=C*np.exp(Wh@m['gh']+Wl@m['gl']); h2=h+Wh@m['dh']; L2=L+np.hstack([Wh,Wl])@m['dl']
    out=np.stack([L2,C2*np.cos(np.radians(h2)),C2*np.sin(np.radians(h2))],-1); out[:,1:]+=m['cast']; return out
def de(a,b): return np.mean(colour.delta_E(a,b,'CIE 2000'))
full=build(names)
print('image      curve only   full formula   leave-one-out')
for n in names:
    b,lj=PC[n]; lo=build([k for k in names if k!=n])
    print(f"{n:9s}    {de(b,lj):5.2f}        {de(apply(full,b),lj):5.2f}          {de(apply(lo,b),lj):5.2f}")
print('\nHUE BAND   saturation   hue shift   lightness   (full fit, on top of curve)')
for i,(bn,c) in enumerate(HB): print(f"{bn:9s}  {(np.exp(full['gh'][i])-1)*100:+5.0f}%      {full['dh'][i]:+5.1f}°     {full['dl'][i]:+5.1f}")
print('LIGHTNESS saturation x:',{L:round(float(np.exp(g)),2) for L,g in zip(LB,full['gl'])},' lightness:',{L:round(float(v),1) for L,v in zip(LB,full['dl'][len(HB):])})
print('grey cast a*,b*:',np.round(full['cast'],2))
pickle.dump(full,open('full.pkl','wb'))
