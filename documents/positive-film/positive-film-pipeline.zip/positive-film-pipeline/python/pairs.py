# Put each RAW and its in-camera Positive Film JPEG in ../data and list them here.
U='../data/'
PAIRS={
 'street':('R0044557.DNG','R0044557.JPG'),
 # 'dog':('R0044564.DNG','R0044564.JPG'),
}
