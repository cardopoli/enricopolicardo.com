import sys,numpy as np,rawpy,colour
from PIL import Image
from skimage.registration import phase_cross_correlation
from skimage.transform import resize
from scipy.ndimage import shift as ndshift, gaussian_filter
from pairs import *
W,H=644,483  # working size (landscape)
out={}
for k,(d,j) in PAIRS.items():
    with rawpy.imread(U+d) as r:
        xyz=r.postprocess(use_camera_wb=True,output_color=rawpy.ColorSpace.XYZ,gamma=(1,1),
                          no_auto_bright=True,output_bps=16,half_size=True,user_flip=None).astype(np.float32)/65535
    jp=np.asarray(Image.open(U+j).convert('RGB')).astype(np.float32)/255
    sz=(jp.shape[0]//4,jp.shape[1]//4)
    xyz=resize(xyz,sz+(3,),anti_aliasing=True)
    jp=resize(jp,sz+(3,),anti_aliasing=True)
    # alignment on log-luminance edges
    a=np.log(xyz[...,1]+1e-3); b=np.log(colour.cctf_decoding(jp,'sRGB')@[0.2126,0.7152,0.0722]+1e-3)
    sh,err,_=phase_cross_correlation(gaussian_filter(b,1),gaussian_filter(a,1),upsample_factor=10)
    xyz=np.stack([ndshift(xyz[...,c],sh,order=1,mode='nearest') for c in range(3)],-1)
    corr=np.corrcoef(np.log(xyz[...,1]+1e-3).ravel(),b.ravel())[0,1]
    print(k,'shift',np.round(sh,2),'corr',round(corr,3),'maxY',round(float(np.percentile(xyz[...,1],99.5)),3))
    out[k]=(xyz,jp)
np.savez_compressed('aligned.npz',**{k+'_x':v[0] for k,v in out.items()},**{k+'_j':v[1] for k,v in out.items()})
