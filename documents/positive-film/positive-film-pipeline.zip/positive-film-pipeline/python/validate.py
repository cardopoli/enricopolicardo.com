import numpy as np,colour,pickle
from sklearn.linear_model import HuberRegressor
exec(open('model.py').read().split("X=[];yC")[0])
D2=np.load('aligned.npz')
def Lcurve(Y,off=0): return ir.predict(np.log2(np.clip(Y,1e-6,None))+off)
def L2Y(L): return np.where(L>8,((L+16)/116)**3,L/903.3)
M2s=colour.RGB_COLOURSPACES['sRGB']
def perchannel(x,off):
    rgb=colour.XYZ_to_RGB(x,'sRGB',apply_cctf_encoding=False)
    rgb=np.clip(rgb,1e-6,None)
    out=L2Y(np.stack([Lcurve(rgb[:,c],off) for c in range(3)],-1))
    return colour.XYZ_to_Lab(colour.RGB_to_XYZ(out,'sRGB',apply_cctf_decoding=False),WP)
def lumonly(x,off):
    Yn=L2Y(Lcurve(x[:,1],off)); return colour.XYZ_to_Lab(x*(Yn/x[:,1])[:,None],WP)
print('mean ΔE2000 vs real PF JPEG')
print('image      lum-only curve   per-channel curve')
R={}
for n,(x,lj) in S.items():
    a=lumonly(x,offs[n]);b=perchannel(x,offs[n])
    e1=np.mean(colour.delta_E(a,lj,'CIE 2000'));e2=np.mean(colour.delta_E(b,lj,'CIE 2000'))
    R[n]=(b,lj); print(f"{n:9s}   {e1:6.2f}          {e2:6.2f}")
pickle.dump({n:(v[0],v[1]) for n,v in R.items()},open('pc.pkl','wb'))
