import numpy as np,colour,pickle
from PIL import Image,ImageDraw
exec(open('validate.py').read().split("print('mean")[0])
exec(open('model2.py').read().split("full=build")[0].split("PC=pickle")[0])
src=open('model2.py').read(); exec(src[src.index("def apply"):src.index("def de")])
def lch(l): return l[:,0],np.hypot(l[:,1],l[:,2]),np.degrees(np.arctan2(l[:,2],l[:,1]))%360
full=pickle.load(open('full.pkl','rb'))
def toimg(lab,shape): 
    rgb=colour.XYZ_to_sRGB(colour.Lab_to_XYZ(lab,WP)); return (np.clip(rgb,0,1).reshape(shape)*255).astype(np.uint8)
rows=[]
for n in list(np.load('aligned.npz').keys())[:0] or [k[:-2] for k in np.load('aligned.npz') if k.endswith('_x')][:4]:
    x=D2[n+'_x'];j=D2[n+'_j'];sh=j.shape;xf=x.reshape(-1,3)
    xf=np.clip(xf,1e-6,None)
    b=perchannel(xf,offs[n]); f=apply(full,b)
    neutral=(np.clip(colour.XYZ_to_sRGB(xf/np.percentile(xf[:,1],99)*0.9),0,1).reshape(sh)*255).astype(np.uint8)
    tiles=[neutral,toimg(f,sh),(j*255).astype(np.uint8)]
    if sh[0]>sh[1]: tiles=[t[::1] for t in tiles]
    rows.append(np.hstack(tiles) if sh[1]>sh[0] else np.hstack([np.asarray(Image.fromarray(t).resize((sh[1]*483//sh[0],483))) for t in tiles]))
w=max(r.shape[1] for r in rows)
rows=[np.pad(r,((0,6),(0,w-r.shape[1]),(0,0)),constant_values=255) for r in rows]
im=Image.fromarray(np.vstack(rows)); top=Image.new('RGB',(w,30),'white');d=ImageDraw.Draw(top)
for i,t in enumerate(['Neutral RAW (no look)','Formula applied to RAW','Real GR Positive Film JPEG']): d.text((10+i*w//3,8),t,fill='black')
out=Image.new('RGB',(w,im.height+30),'white');out.paste(top,(0,0));out.paste(im,(0,30));out.save('comparison.jpg',quality=90)
print(out.size)
