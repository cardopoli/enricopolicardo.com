# Universal WordPress MCP Bridge (Beta)

**Version 0.6.2 - self-hosted, single ZIP, no Mac software required.**

This is an experimental, open-source WordPress plugin implementing an HTTPS [Model Context Protocol](https://modelcontextprotocol.io/) server directly inside WordPress. It does **not** require the ChatGPT desktop app, a separate Node/Python bridge, or WPVibe. It is not affiliated with OpenAI, WordPress.org or WPVibe.

## What it supports

| Feature | Details |
| --- | --- |
| Self-hosted remote MCP | WordPress REST API endpoint, compatible with recent Streamable HTTP JSON-RPC methods and `2026-07-28` discovery; legacy `2025-11-25`/`2025-06-18` initialisation |
| Login | OAuth 2.1-style authorisation code + PKCE S256, dynamic client registration and WordPress admin consent |
| Tools (read-only) | Site details; list/read WordPress posts, pages and public custom post types; search shortcodes; list media, plugins and cron tasks; inspect database size and backups; v0.3 adds exact row counts on individual tables and off-site backup configuration checks |
| Tools (when enabled) | Create page/post drafts; exact snippet replacement preserving multilingual markers; edit Yoast SEO fields |
| Controlled maintenance (since v0.2) | Request plugin deactivation or uninstall; move ordinary pages/posts to Trash; remove apparently orphaned WP-Cron hooks; delete OLD Redirect Redirection request logs in batches of 25,000 or fewer |
| Approvals | Publishing, plugin removal and every maintenance action require a separate 10-minute, one-use confirmation by the authorising WordPress administrator |
| Database optimisation (v0.3) | Restricted to the Redirect Redirection request-log table, at most 256 MB. A one-time administrator approval and explicit backup confirmation are required. No automatic optimisation. Repeat requests are blocked for seven days after the bridge runs one |
| Reversible controls | Revoke all connected clients; turn editing off; inspect recent tool activity |
| Languages | Reads raw qTranslate-XT format (`[:en]...[:it]...[:sl]...[:]`), without flattening markers |

**Not included in this beta:** unrestricted WP-CLI, arbitrary SQL, raw PHP execution, plugin/theme source editing, automated theme updates, remote media uploads, full Events Manager custom-table manipulation, permanently deleting posts/media, bulk plugin removals, WPVibe fleet operations, or anything bypassing WordPress permissions. It is **not** a full replacement for WPVibe yet.


## Upgrade from v0.2.0 to v0.3.0

1. Make a **verified, independently stored backup** first. The existing UpdraftPlus schedule and local host backup alone do not establish that restoration works.
2. WordPress **Plugins → Add New → Upload Plugin**, select `Universal-WordPress-MCP-Bridge-v0.3.0.zip`, then click **Replace current with uploaded**. The folder name is the same and the upgrade does not revoke your current OAuth connection or reset settings.
3. Keep **Settings → Universal MCP Bridge → Enable controlled maintenance requests** enabled if you want the existing maintenance tools. Ordinary content editing can remain disabled. Refresh the custom MCP tool list in your client after installation.
4. Test `site_info`, then `backup_health`, then `inspect_database_table` with the exact table name returned by `site_diagnostics`, e.g. `<your-prefix>_irrp_redirection_logs`, and `exact_count: true`. The table name is an example for ReThinkable, not a universal WordPress table prefix.
5. **Do not optimise the log table again solely because its allocated size looks unchanged.** MySQL InnoDB row estimates can be stale and `OPTIMIZE TABLE` is not a guarantee that hosting disk usage will decline. `request_log_table_optimisation` is a last-resort, deliberately narrow tool, not part of normal diagnostics. It requires admin approval, checked confirmation of an independent database backup and may temporarily lock the table.
6. If `backup_health` reports no remote destination, configure one in **Settings → UpdraftPlus Backups → Settings → Choose your remote storage** (Dropbox or Google Drive are available in the free UpdraftPlus version), complete authentication directly in WordPress, and run a **manual backup sent to remote storage**. Inspect the resulting UpdraftPlus log and verify its files at the destination; test restoration on staging before relying on it. The MCP Bridge never asks for your cloud account credentials.

### New v0.3 tools

| Tool | Safety and output |
| --- | --- |
| `inspect_database_table` | Read-only; validates a table on the current WordPress prefix. Returns reported allocation, index/data sizes, free space, InnoDB row estimate, optional exact `SELECT COUNT(*)` on one table up to 256 MB. Never returns table records. For Redirect Redirection, also counts request logs older than 30 days. |
| `backup_health` | Read-only; checks UpdraftPlus schedules, selected file components, remote destination types (no credentials), planned next runs and number of backup-history records. Does not claim a backup succeeded or can be restored. |
| `request_log_table_optimisation` | Optional, write-scope, disabled unless maintenance is enabled. Only the named Redirect Redirection request-log table. The request does not run SQL. The authorising WordPress administrator must approve, confirm a separate recoverable backup, and review an on-screen warning. Up to 256 MB; blocked for seven days after the bridge runs optimisation. |

**This remains a beta.** The v0.3 code was tested with mocked WordPress/database responses and PHP syntax checks. It has **not** undergone a full security audit, a staging integration test or live v0.3 testing. Do not install blindly on a critical production site.

## Upgrade from v0.1.1 to v0.2.0

1. Back up the database and plugin files first. On a production site, test this beta on staging if possible.
2. In WordPress Admin open **Plugins → Add New Plugin → Upload Plugin**, select `Universal-WordPress-MCP-Bridge-v0.2.0.zip` and choose **Replace current with uploaded**.
3. The plugin folder slug is unchanged: `universal-wordpress-mcp-bridge`. Existing OAuth connections and settings are retained during a normal replacement. No new connection is required if the existing token has `wp.write` permission; otherwise reauthorise and refresh the tool list.
4. Open **Settings → Universal MCP Bridge**. Keep **Allow draft creation and controlled text/SEO edits** OFF if you only want removals. Tick **Enable controlled maintenance requests (v0.2)** and save.
5. First try a reversible operation on a nonessential inactive plugin using `request_plugin_action` with `action=deactivate` only if it is active. The MCP tool gives a **review URL**, not an immediate result. Open it in your browser, check the exact plugin and only then click Confirm.
6. For Redirect Redirection log clean-up, use `request_redirect_log_cleanup` with `older_than_days: 30` (or a higher number); review count and approve. A single approval deletes **no more than 25,000** old request-log rows. It does **not** disable future logging or remove redirect rules.

### Tool names added or separated in v0.2

| Tool | Behaviour | Approval |
| --- | --- | --- |
| `request_plugin_action` | Request `deactivate` or `uninstall` for one named plugin. Uninstall requires inactive plugin. Already present in earlier code; now behind independent maintenance switch. | Yes |
| `request_trash_content` | Move one ordinary post/page to WordPress Trash, never permanent deletion | Yes |
| `request_cron_removal` | Remove all up to 25 occurrences of one apparently orphaned cron hook, refusing protected and active hooks | Yes |
| `request_redirect_log_cleanup` | Delete at most 25,000 old rows from the Redirect Redirection log table, age minimum 30 days | Yes |

Every request is bound to the original WordPress admin, expires after 10 minutes and is single-use. **Do not paste OAuth access tokens, refresh tokens, administrator passwords or the approval links into public places.**

## Install in WordPress

1. Make a verified backup or test on a staging site first. The plugin has not been tested on a live production installation.
2. Download the plugin ZIP and **do not unzip it**.
3. WordPress Admin → **Plugins → Add New Plugin → Upload Plugin**. Select the ZIP, install and activate.
4. Open **Settings → Universal MCP Bridge**.
5. Check that the **Public health check** URL returns JSON and says `"https": true`. If it returns 404, go to **Settings → Permalinks** and click Save Changes once.
6. Check that both the **OAuth discovery** and **Protected resource discovery** URLs display JSON. If Cloudflare/security rules block `/.well-known/`, allow those two read-only endpoints or adjust the webserver routing. WordPress rewrite rules are created on activation.
7. Tick **Enable external MCP connections**, then Save. Leave write and publishing permissions OFF until read-only access is working.
8. In a **compatible MCP client** that allows custom remote HTTPS OAuth/DCR connections, use this server URL:

   `https://YOUR-DOMAIN.example/wp-json/universal-mcp/v1/mcp`

9. Select **OAuth** authentication and **dynamic client registration** (DCR, public client with PKCE S256). Sign in through the normal WordPress administrator login and approve the consent screen. Defaults on a new install allow `chatgpt.com`, `chat.openai.com`, and `claude.ai`. Existing installations retain their saved callback allowlist: add `claude.ai` yourself before connecting Claude. For other MCP clients, allow only the exact host of the documented OAuth redirect URI. Desktop loopback redirect URLs require a separate opt-in.
10. Test `site_info`, `list_content` and `get_content`. To enable edits, return to Settings and enable **Allow draft creation and controlled text/SEO edits**, then authorise the `wp.write` scope. To enable removal requests, instead enable **Enable controlled maintenance requests (v0.3)**. These are independent controls: you can enable maintenance requests while leaving content editing off. Both require the OAuth `wp.write` scope. If your current connection has only `wp.read`, reconnect or reauthorise it with `wp.write` and refresh the client's tool list.

### Connecting ChatGPT in a browser

### v0.1.1+ correction for multilingual sites

OAuth issuer, MCP URL, token and registration URL are now generated from the WordPress **Home URL setting**, without language prefixes. In particular qTranslate-XT can rewrite `home_url()` and `rest_url()` to `/it/`, `/en/`, `/sl/`, which produces unstable OAuth audiences and breaks standard OAuth discovery. The bridge now advertises a stable `https://YOUR-SITE/wp-json/universal-mcp/v1/mcp`, and issuer `https://YOUR-SITE` (or your site's configured home subdirectory).

When upgrading from 0.1.0, existing OAuth clients must reconnect: credentials issued to the old language-specific audience cannot be reused. Recheck the health and well-known endpoints after upgrading. Do not put OAuth tokens or refresh tokens into chat.

MCP availability and permissions vary by ChatGPT account and client. This bridge cannot override client-side tool and OAuth scope restrictions. Test a `wp.read` tool first and reauthorise for `wp.write` only if your MCP client supports it. The bridge is now connected to ReThinkable on this account, but another account may have different features.

When eligible, in ChatGPT (web): **Plugins → + → Add custom MCP server**, enter the WordPress HTTPS URL, choose OAuth with DCR, and complete WordPress login/consent. No Mac desktop app is needed.

This plugin can also work with other remote MCP clients that support OAuth + DCR, even where ChatGPT custom connections are not available.

## Example WordPress address for ReThinkable

- Plugin settings: `https://example.org/wp-admin/options-general.php?page=universal-mcp-bridge`
- MCP URL: `https://example.org/wp-json/universal-mcp/v1/mcp`
- Health check: `https://example.org/wp-json/universal-mcp/v1/health`
- OAuth metadata: `https://example.org/.well-known/oauth-authorization-server`

These are canonical paths. ReThinkable confirmed v0.2.0 responding through the MCP plugin. Version 0.3.0 has not yet been installed or tested on the live site.

## Security design

- **Off by default**. HTTPS is required. No username or administrator password is embedded in the ZIP.
- No public content tools; every call must carry a valid OAuth bearer token issued for this exact MCP endpoint.
- OAuth codes expire after 5 minutes, access tokens after one hour, and rotating refresh tokens after 30 days. Tokens are stored as hashes.
- OAuth redirects are restricted by exact hostname allowlist, and authorisation always requires a WordPress administrator's login and consent.
- Only administrators can grant MCP access. All WordPress object permissions are checked again before reading/editing.
- OAuth tokens can be revoked in WordPress under **Settings → Universal MCP Bridge → Revoke every connection**.
- **Drafts only** when creating content. Existing content receives a standard WordPress revision on text updates.
- If an existing page contains qTranslate-XT markers, a snippet replacement is rejected if it changes the number of language markers.
- Publication, plugin deactivation and plugin uninstall require a second, one-time, expiring approval URL which must be opened and confirmed while logged into WordPress as the authorising administrator.
- The maintenance switch is OFF by default on fresh installations and independent of content editing. A tool call only creates a review request. No WordPress content or database rows change until that request is approved.
- `request_trash_content` only accepts ordinary WordPress `post`/`page`, never event types, and refuses the configured home/posts index. Published content becomes unavailable when trashed; it is not permanently deleted by this tool. The request expires and is rejected if content changes before approval.
- `request_cron_removal` requires an exact hook, refuses core/security/backup hooks and hooks with registered callbacks, and checks a snapshot on approval. Maximum 25 scheduled occurrences per request.
- `request_redirect_log_cleanup` is hard-coded to the table `<WordPress-prefix>irrp_redirection_logs`. It removes only request history older than 30 days, at most 25,000 rows per approval. It does NOT delete the actual redirect rules, clear WordPress revisions, or optimise any database table. Large backlogs take repeated approvals, and disk allocation may remain until table maintenance.
- No permanent post deletion, media deletion, arbitrary SQL, unrestricted cron commands, arbitrary filesystem operations or direct shell execution is provided.
- No arbitrary SQL, shell commands or PHP evaluation endpoint is implemented.
- A bounded action log records operation names and results, not passwords, tokens, post bodies or request parameters.

**Important:** A new security-sensitive WordPress plugin still deserves independent code review and staging tests before a production rollout. Use the standard WordPress security hardening controls, monitor activity, restrict callback hosts and do not publicly share approval links.

## Troubleshooting

**404 on MCP/health**: Activate plugin; go to Settings → Permalinks and save. Check `/wp-json/` is reachable.

**404 on `/.well-known`**: Webserver, CDN or security middleware may intercept dot-paths. Add explicit allow rules or ask the host to route these endpoints through WordPress. The REST fallbacks at `/wp-json/universal-mcp/v1/oauth/metadata` and `/oauth/resource` can assist diagnosis, but standards-based clients will still need the well-known discovery URLs.

**401 from MCP**: Expected without an OAuth token. Verify the OAuth discovery response and reconnect. If authorization fails even after signing in, verify that the HTTP `Authorization` header reaches PHP from your proxy/webserver.

**Tools not visible**: Connect with OAuth and refresh the client's discovered tool list. Read-only tools are available by default once the bridge is enabled; write tools appear only when enabled in settings.

**DCR callback rejected**: Add the client's exact callback hostname (not a full URL) to the allowlist in WordPress settings. Do not whitelist unknown domains.

**Maintenance tools not visible**: Enable **Settings → Universal MCP Bridge → Enable controlled maintenance requests**, save, refresh the MCP tool list and reauthorise the client for `wp.write` if required. Creating a request never performs the change; open the one-use review link in a browser as the same WordPress administrator.

**Plugin delete fails**: WordPress may require filesystem credentials. In that case use the standard Plugins admin screen, rather than widening MCP privileges.

**Yoast SEO changed but public meta looks old**: Rebuild Yoast's indexables and clear any WordPress/CDN cache. The `set_yoast_seo` tool uses standard post metadata and WordPress save hooks but does not guarantee immediate cache invalidation.

**Events Manager**: The plugin can read event post content but does not write the plugin's dedicated booking/event tables. Use Events Manager's own admin UI for schedule, ticket or booking operations.

## Developer tests

Requires PHP 7.4+ for syntax checks. The **separate development source package**, not the WordPress install ZIP, includes a mocked smoke test:

```bash
php tests/smoke.php
php tests/maintenance.php
find . -name '*.php' -not -path './tests/*' -exec php -l {} \;
```

The optional development source package contains mocked tests covering registration callback allowlists, OAuth token and refresh rotation, unauthorised access, modern MCP JSON-RPC discovery and tool calls, scope enforcement, qTranslate marker preservation, and maintenance safety boundaries. **These are unit/smoke tests, not a live WordPress integration or penetration test.**

## Licence

GPL-2.0-or-later. This community beta is provided without warranty.

## Backup checklist (no credentials shared with ChatGPT)

- Confirm UpdraftPlus backs up the WordPress database, plugins, themes, uploads and any required nonstandard files. Some folders or files may be excluded by default.
- Configure Dropbox or Google Drive in the UpdraftPlus **Settings** screen. Do not paste cloud login tokens or passwords into MCP/ChatGPT.
- Run **Backup Now**, ticking send to remote storage.
- Check the backup log for completion, and verify the archive is in the remote account.
- Test a restore on a separate staging installation. Only a successful restore test proves the backup is recoverable.
- Keep hosting-provider backups as an additional layer, not the only recoverable copy.


## Version 0.4.0: administrator-reviewed design CSS

This upgrade adds `inspect_design_css` (read only) and `request_design_css` (requires OAuth `wp.write`, the existing Controlled maintenance setting and approval in WordPress). No theme PHP, JavaScript, CSS files, WordPress menus, or content are edited. A valid replacement stylesheet is stored as a WordPress option and printed last in `wp_head` on public pages. The previous five stylesheet revisions are kept as backups. No design styles are inserted automatically on upgrade.

To use it: install this ZIP over 0.3, reconnect the MCP plugin in the AI client, call `inspect_design_css`, and send `request_design_css` with the complete proposed CSS and the returned SHA-256. Review the generated approval link in WordPress. It expires after ten minutes. Verify the website on desktop and mobile across all languages. To undo: call `inspect_design_css` to get the new SHA-256, then request the earlier CSS (or the empty string) and approve it.

CSS rejects HTML, JavaScript constructs, remote URLs, CSS imports, excessively long stylesheets, and malformed bracket/comment counts. The authorised WordPress user must have `manage_options` and `edit_theme_options`. These controls do not replace full browser visual testing or a staging site. This release is beta and has not been audited for production security.


## Version 0.5.0: optional progressive navigation, no extra plugin

The upgrade adds one optional setting in **Settings → Universal MCP Bridge → Front-end navigation**. It preserves the existing Inspiro theme, header, logo, hamburger, qTranslate-XT language selector, social links, colours and menu titles. It **does not** replace WordPress menus or edit database menu items.

### Try it without changing the public website

1. Install `Universal-WordPress-MCP-Bridge-v0.5.0.zip` over v0.4 and choose **Replace current with uploaded**. Existing connection, CSS and maintenance settings are preserved.
2. Open **Settings → Universal MCP Bridge → Front-end navigation**.
3. Click **Preview interactive menu as administrator**. The preview is visible only to logged-in administrators on pages with `?uwmcp_nav_preview=1`. Visit an Italian, Slovenian and English page.
4. Test mobile and desktop by opening the existing menu. The original hamburger controls the drawer. There are now *separate*, keyboard-accessible arrow buttons on sidebar sections to expand/collapse children. Clicking a section title continues to navigate to its page. Only the current page's ancestor branch starts open. The language menu stays visible. Opening a sibling section closes its siblings. No social links are moved.
5. If happy, tick **Enable improved sidebar navigation**, save settings and clear your site's page/CDN cache as appropriate. If not happy, leave it unticked; visitors continue to see the original menu.

The extension is lightweight: one ~5 KB JavaScript and one ~1 KB CSS asset only on front-end pages where the setting is enabled (or during admin preview). No dependencies or new WordPress plugins, shortcode plugins or database tables are introduced. The enhanced code avoids changing Inspiro's existing hamburger click/close handlers.

### Revert

Untick **Enable improved sidebar navigation**, save and clear cache. This removes the script and interaction styles without changing any WordPress menu, theme, page or existing bridge-managed CSS. The site-wide CSS previously approved through `request_design_css` remains separate and unchanged.

### Backend simplification

Do not uninstall Max Mega Menu until its existing header language and social controls have been replaced and verified on all three languages. Do not remove Smart Slider 3 Pro while the homepage or archive still uses it. CFDB7 and Flamingo are potential duplicate Contact Form 7 submission stores, but must be checked for existing records and exports before changing either. Optional editing utilities, such as Duplicate Page or Post Type Switcher, can be reviewed separately.

This is still a beta. The navigation behaviour was exercised in a local headless Chromium simulation in IT/SL/EN, but it has not yet been tested on the production WordPress theme and real phones.


## Version 0.6.0: controlled PHP and JavaScript editing

This upgrade preserves existing OAuth clients, tokens, CSS overrides, navigation, settings, content and plugin data. The new capability is **off by default**.

1. Upload `Universal-WordPress-MCP-Bridge-v0.6.0.zip` in **Plugins > Add New > Upload Plugin**, select **Replace current with uploaded**, and confirm it remains active.
2. In **Settings > Universal MCP Bridge**, tick **Enable active-theme PHP/JavaScript code reviews**. Keep existing connection/write/maintenance permissions as before. Save.
3. Refresh/reconnect the ChatGPT ReThinkable WordPress integration if its tool catalogue remains cached.
4. Use `list_theme_code` and `read_theme_code` to inspect existing PHP/JS files. `request_theme_code_patch` prepares an exact replace-once edit using the current source SHA-256; **it does not change the file**.
5. Open the review URL in the browser logged in as the **same WordPress administrator who authorised the MCP connection**. Check the proposed code, confirm you have a verified independent backup, then approve. The previous file is retained in a WordPress database option for rollback; use `list_theme_code_revisions` and `request_theme_code_rollback` to prepare a restoration.
6. Test on desktop/mobile and in IT/EN/SL. Purge browser/CDN cache after JavaScript changes, where required.

### Security boundaries and trade-offs

- Existing `.php` and `.js` files **only within the active theme**. Parent-theme files are not touched when a child theme is active. WordPress core, all plugins (including this bridge), uploads, `wp-config.php`, symbolic links, hidden paths, new files, and arbitrary file extensions are excluded.
- Requires `manage_options` and `edit_themes`; respects `DISALLOW_FILE_EDIT`, `DISALLOW_FILE_MODS` and `wp_is_file_mod_allowed('theme_editor')` if present.
- PHP code is parsed with `token_get_all(..., TOKEN_PARSE)` before accepting a patch and again at approval time. This checks syntax but **cannot guarantee runtime correctness or safety**.
- JavaScript code is **not** syntax-checked by this plugin. There is no external parser or shell execution. It needs manual review and browser console testing.
- Each edit is a match-once snippet replacement limited to a 192 KiB existing source file, with concurrency hashes, a 10-minute request expiry, individual administrator approval, an anti-CSRF nonce, a backup acknowledgement, atomic same-directory staging, opcache invalidation and an internal history of five previous revisions.
- A working independent backup and hosting-level recovery route are required before approving theme changes. Internal rollback cannot help if a fatal PHP error prevents the plugin itself from loading.
- Avoid editing the parent theme directly if possible: updates overwrite parent-theme customisations. Use a child theme for lasting changes. The bridge does **not** manage an external development/staging environment.
- This is a narrowly scoped code maintenance feature, not an unrestricted web shell, terminal, full filesystem editor or configuration manager.


### v0.6.1 (MCP catalogue compatibility)

Theme code tools are advertised consistently. Their execution remains protected by the existing explicit setting, administrator theme-edit capability, core file-edit restrictions, OAuth scope, and per-edit approval. MCP declares that its tool list can change, and `site_info` now reports the code-edit setting and file-edit permissions for diagnosis. No theme source files are changed by installing this update.


## Compatibility and release safety (v0.6.2)

See [COMPATIBILITY.md](COMPATIBILITY.md) for connection steps and a candid compatibility matrix. This beta is **not certified to work with every AI provider**. It uses a remote, HTTPS, stateless JSON-RPC MCP endpoint and OAuth authorization-code + PKCE with dynamic client registration. Compatibility depends on each client's remote MCP and OAuth implementation.

**Claude:** In Claude's custom connectors, select **Register automatically** for OAuth (DCR), enter your WordPress server URL from Settings > Universal MCP Bridge, and complete administrator consent. Do not select Claude's published identity mode (CIMD) because this version advertises `client_id_metadata_document_supported: false`. Before connecting, add `claude.ai` to your WordPress **Allowed OAuth callback domains** (existing installations do not inherit defaults).

Before a public production release, review this code with an independent WordPress/security specialist and run end-to-end connection and permissions tests against every advertised client. Distribution must never include database exports, live credentials, WP option dumps, private logs or OAuth tokens.
