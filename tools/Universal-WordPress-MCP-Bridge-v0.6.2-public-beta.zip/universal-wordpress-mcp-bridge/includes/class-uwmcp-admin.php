<?php
if (!defined('ABSPATH')) exit;

class UWMCP_Admin {
    public static function menu() { add_options_page('Universal MCP Bridge','Universal MCP Bridge','manage_options','universal-mcp-bridge',array(__CLASS__,'page')); }
    public static function register() {
        register_setting('uwmcp_settings_group','uwmcp_settings',array('type'=>'array','sanitize_callback'=>array(__CLASS__,'sanitize'),'default'=>array()));
    }
    public static function sanitize($raw) {
        if(!current_user_can('manage_options'))return uwmcp_settings();
        $old=uwmcp_settings();
        $list=preg_split('/[\r\n,]+/',(string)($raw['redirect_hosts']??''),-1,PREG_SPLIT_NO_EMPTY);
        $hosts=array();
        foreach($list as $item){$host=strtolower(trim($item));if(preg_match('/^(?:[a-z0-9-]+\.)*[a-z0-9-]+$/D',$host) && strlen($host)<=150)$hosts[]=$host;}
        $hosts=array_values(array_unique($hosts));
        if(!$hosts)$hosts=array('chatgpt.com','chat.openai.com','claude.ai');
        return array(
            'enabled'=>!empty($raw['enabled'])?1:0,
            'allow_writes'=>!empty($raw['allow_writes'])?1:0,
            'allow_publish'=>!empty($raw['allow_publish'])?1:0,
            'allow_maintenance'=>!empty($raw['allow_maintenance'])?1:0,
            'allow_code_edits'=>!empty($raw['allow_code_edits'])?1:0,
            'allow_loopback'=>!empty($raw['allow_loopback'])?1:0,
            'nav_enhanced'=>!empty($raw['nav_enhanced'])?1:0,
            'redirect_hosts'=>implode("\n",array_slice($hosts,0,20)),
        );
    }
    public static function page() {
        if(!current_user_can('manage_options'))wp_die('Administrators only.');
        if(isset($_POST['uwmcp_revoke']) && check_admin_referer('uwmcp_revoke_all','uwmcp_revoke_nonce')) {
            update_option('uwmcp_clients',array(),false);
            update_option('uwmcp_tokens',array(),false);
            uwmcp_log('revoke_access','ok',get_current_user_id());
            echo '<div class="notice notice-success"><p>All connected OAuth clients and access tokens revoked.</p></div>';
        }
        $s=uwmcp_settings();$clients=get_option('uwmcp_clients',array());$audit=get_option('uwmcp_audit',array());
        if(isset($_GET['uwmcp_code']) && $_GET['uwmcp_code']==='completed') echo '<div class="notice notice-success"><p>Theme code change applied. Check the public site, all languages and the browser console. Use the saved revision if rollback is needed.</p></div>';
        echo '<div class="wrap"><h1>Universal WordPress MCP Bridge</h1><p>Self-hosted MCP server. No Mac desktop app, external relay, application password or vendor account required.</p>';
        if(!uwmcp_is_https())echo '<div class="notice notice-error"><p><strong>HTTPS required.</strong> Your WordPress home URL is not HTTPS. Do not enable until HTTPS is correctly configured.</p></div>';
        echo '<table class="widefat striped" style="max-width:950px"><tbody>';
        foreach(array('MCP server URL'=>uwmcp_url(),'OAuth discovery'=>uwmcp_wellknown_url('authorization'),'Protected resource discovery'=>uwmcp_wellknown_url('protected'),'Public health check'=>uwmcp_rest_endpoint('health')) as $name=>$url) echo '<tr><th scope="row" style="width:220px">'.esc_html($name).'</th><td><code style="overflow-wrap:anywhere">'.esc_html($url).'</code></td></tr>';
        echo '</tbody></table>';
        echo '<form method="post" action="options.php" style="max-width:950px;margin-top:25px">';
        settings_fields('uwmcp_settings_group');
        echo '<h2>Connection and permissions</h2><fieldset>';
        self::checkbox('enabled',$s,'Enable external MCP connections','Disabled by default. The endpoints return errors until enabled.');
        self::checkbox('allow_writes',$s,'Allow draft creation and controlled text/SEO edits','WordPress OAuth scopes and user permissions are still required.');
        self::checkbox('allow_publish',$s,'Offer publish requests','Publication always requires WordPress administrator confirmation in a browser.');
        self::checkbox('allow_maintenance',$s,'Enable controlled maintenance requests (v0.4)','Allows requesting plugin actions, moving posts/pages to Trash, unscheduling orphaned cron jobs, and deleting old Redirect Redirection logs. Each request requires a separate WordPress administrator approval. Requires an OAuth connection authorised for wp.write.');
        echo '<h2>Controlled active-theme PHP / JavaScript editing (v0.6)</h2>';
        echo '<p>Disabled by default. Only existing .php and .js files in the active theme are eligible. No plugin, WordPress core, uploads, credentials, or arbitrary file paths. Every proposed change must be approved separately by the same WordPress administrator, and the old source is retained for a controlled rollback.</p>';
        self::checkbox('allow_code_edits',$s,'Enable active-theme PHP/JavaScript code reviews','Requires an OAuth wp.write scope and an administrator with edit_themes rights. WordPress DISALLOW_FILE_EDIT / DISALLOW_FILE_MODS restrictions are respected. PHP syntax is parsed before approval; JavaScript requires manual review.');
        self::checkbox('allow_loopback',$s,'Allow local-client OAuth redirect URLs','Only 127.0.0.1 or localhost over HTTP. Optional for desktop MCP clients.');
        echo '</fieldset>';
        echo '<h2>Front-end navigation</h2><p>Keep the existing Inspiro design and menu placement. Add accessible accordion buttons only to the existing sidebar sections; title links still navigate. No extra WordPress navigation plugin is needed.</p>';
        self::checkbox('nav_enhanced', $s, 'Enable improved sidebar navigation', 'Opt in after previewing. Provides separate expand/collapse buttons, preserves the language menu and social icons, adds current-page and keyboard support. Disable to return to the original menu.');
        $preview_url = add_query_arg('uwmcp_nav_preview', '1', home_url('/'));
        echo '<p><a href="'.esc_url($preview_url).'" target="_blank" rel="noopener noreferrer" class="button button-secondary">Preview interactive menu as administrator</a> <span class="description">Preview loads the enhanced menu only for the logged-in administrator, even when the option is off.</span></p>';
        echo '<h2>Allowed OAuth callback domains</h2><p>Exact domain names, one per line. Public clients can register only callbacks on these domains. Defaults for new installs: <code>chatgpt.com</code>, <code>chat.openai.com</code>, <code>claude.ai</code>. For existing installations, add the exact callback hostname of the selected AI client manually. Never allow wildcard or unknown callback domains.</p>';
        echo '<textarea name="uwmcp_settings[redirect_hosts]" rows="4" style="width:100%;max-width:440px" spellcheck="false">'.esc_textarea($s['redirect_hosts']).'</textarea>';
        submit_button('Save bridge settings');echo '</form>';
        if(isset($_GET['uwmcp_maintenance']) && $_GET['uwmcp_maintenance']==='completed') echo '<div class="notice notice-success"><p>Maintenance action approved and completed. See Recent activity below.</p></div>';
        $remote = get_option('updraft_service', '');
        $has_remote = is_array($remote) ? count(array_filter($remote)) > 0 : trim((string)$remote) !== '';
        echo '<h2>Backup safety</h2>';
        if (!$has_remote) echo '<div class="notice notice-warning inline"><p><strong>No off-site UpdraftPlus destination detected.</strong> Configure Dropbox or Google Drive in UpdraftPlus and verify an actual remote backup before any more database maintenance.</p></div>';
        else echo '<p>A remote backup destination is configured. Check the most recent UpdraftPlus log and test a restore to verify that it works.</p>';
        echo '<p>This bridge does not request or store remote backup credentials. MCP clients can call <code>backup_health</code> for scheduling information.</p>';
        echo '<h2>Managed design CSS</h2><p><strong>'.strlen(UWMCP_Design::current_css()).'</strong> bytes of site-wide CSS overrides. Changes are never applied until the requesting administrator approves them in WordPress. There are up to five previous versions for recovery. They are separate from the theme and survive normal theme updates.</p>';
        if(isset($_GET['uwmcp_design']) && $_GET['uwmcp_design']==='completed')echo '<div class="notice notice-success"><p>Design stylesheet updated successfully.</p></div>';
        echo '<h2>Connections</h2><p>'.count((array)$clients).' registered OAuth client(s). If a credential or connected application is compromised, revoke all connections below.</p>';
        echo '<form method="post">';wp_nonce_field('uwmcp_revoke_all','uwmcp_revoke_nonce');
        echo '<button type="submit" name="uwmcp_revoke" value="1" class="button" onclick="return confirm(\'Disconnect every MCP client and revoke all tokens?\')">Revoke every connection</button></form>';
        echo '<h2>Recent activity</h2><table class="widefat striped" style="max-width:950px"><thead><tr><th>Time (UTC)</th><th>Tool/action</th><th>Result</th><th>User ID</th></tr></thead><tbody>';
        foreach(array_slice((array)$audit,0,25) as $row)echo '<tr><td>'.esc_html($row['time']??'').'</td><td>'.esc_html($row['action']??'').'</td><td>'.esc_html($row['result']??'').'</td><td>'.esc_html($row['user_id']??'').'</td></tr>';
        echo '</tbody></table><h2>Important safety notes</h2><p>Keep WordPress, PHP and this plugin updated. Never enable an unrestricted database or PHP execution endpoint. Protect this site with backups and strong administrator login security. The connector does not remove usage limits imposed by a client platform.</p></div>';
    }
    private static function checkbox($field,$settings,$label,$description) {
        echo '<p><label><input type="checkbox" value="1" name="uwmcp_settings['.esc_attr($field).']" '.checked(!empty($settings[$field]),true,false).'> <strong>'.esc_html($label).'</strong></label><br><span class="description" style="margin-left:24px">'.esc_html($description).'</span></p>';
    }
}
