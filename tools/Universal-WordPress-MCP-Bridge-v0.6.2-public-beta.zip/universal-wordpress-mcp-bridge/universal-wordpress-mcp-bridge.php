<?php
/**
 * Plugin Name: Universal WordPress MCP Bridge (Beta)
 * Description: Self-hosted, OAuth-protected remote MCP tools for managing WordPress content. No desktop bridge or third-party service required.
 * Version: 0.6.2
 * Author: Universal MCP Bridge Contributors
 * License: GPL-2.0-or-later
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: universal-wordpress-mcp-bridge
 */
if (!defined('ABSPATH')) { exit; }

define('UWMCP_VERSION', '0.6.2');
define('UWMCP_PATH', plugin_dir_path(__FILE__));
define('UWMCP_FILE', __FILE__);
require_once UWMCP_PATH . 'includes/uwmcp-urls.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-oauth.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-operations.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-maintenance.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-diagnostics.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-design.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-navigation.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-code.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-tools.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-server.php';
require_once UWMCP_PATH . 'includes/class-uwmcp-admin.php';

function uwmcp_settings() {
    return wp_parse_args(get_option('uwmcp_settings', array()), array(
        'enabled' => 0, 'allow_writes' => 0, 'allow_publish' => 0, 'allow_maintenance' => 0,
        'nav_enhanced' => 0, 'allow_code_edits' => 0, 'redirect_hosts' => "chatgpt.com\nchat.openai.com\nclaude.ai",
    ));
}
function uwmcp_log($operation, $result, $user_id = 0) {
    $rows = get_option('uwmcp_audit', array());
    if (!is_array($rows)) $rows = array();
    array_unshift($rows, array('time'=>gmdate('c'),'action'=>sanitize_key($operation),'result'=>sanitize_key($result),'user_id'=>(int)$user_id));
    update_option('uwmcp_audit', array_slice($rows, 0, 80), false);
}

function uwmcp_rewrite_rules() {
    add_rewrite_rule('^\\.well-known/oauth-protected-resource/?$', 'index.php?uwmcp_wellknown=protected', 'top');
    add_rewrite_rule('^\\.well-known/oauth-authorization-server/?$', 'index.php?uwmcp_wellknown=authorization', 'top');
    // RFC 9728 permits the resource path appended after the well-known identifier.
    add_rewrite_rule('^\\.well-known/oauth-protected-resource/wp-json/universal-mcp/v1/mcp/?$', 'index.php?uwmcp_wellknown=protected', 'top');
}
add_action('init', 'uwmcp_rewrite_rules');
add_filter('query_vars', function($q){ $q[] = 'uwmcp_wellknown'; return $q; });
add_action('template_redirect', function() {
    $type = get_query_var('uwmcp_wellknown');
    if (!in_array($type, array('protected','authorization'), true)) return;
    if (!uwmcp_is_https()) { status_header(503); exit('HTTPS required'); }
    $json = $type === 'protected' ? UWMCP_OAuth::resource_metadata() : UWMCP_OAuth::server_metadata();
    status_header(200);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo wp_json_encode($json);
    exit;
}, 0);

add_action('rest_api_init', array('UWMCP_Server', 'routes'));
add_action('admin_post_uwmcp_authorize', array('UWMCP_OAuth', 'authorize'));
add_action('admin_post_nopriv_uwmcp_authorize', array('UWMCP_OAuth', 'authorize'));
add_action('admin_post_uwmcp_confirm_publish', array('UWMCP_Tools', 'confirm_publish'));
add_action('admin_post_uwmcp_confirm_plugin_action', array('UWMCP_Operations', 'confirm'));
add_action('admin_post_uwmcp_confirm_maintenance', array('UWMCP_Maintenance', 'confirm'));
add_action('admin_post_uwmcp_confirm_design_css', array('UWMCP_Design', 'confirm'));
add_action('admin_post_uwmcp_confirm_theme_code', array('UWMCP_Code', 'confirm'));
add_action('wp_head', array('UWMCP_Design', 'output_css'), 999);
add_action('wp_enqueue_scripts', array('UWMCP_Navigation', 'enqueue'));
add_action('admin_menu', array('UWMCP_Admin', 'menu'));
add_action('admin_init', array('UWMCP_Admin', 'register'));

register_activation_hook(__FILE__, function(){
    add_option('uwmcp_settings', array('enabled'=>0,'allow_writes'=>0,'allow_publish'=>0,'allow_maintenance'=>0,'redirect_hosts'=>"chatgpt.com\nchat.openai.com\nclaude.ai"), '', false);
    add_option('uwmcp_clients', array(), '', false);
    add_option('uwmcp_tokens', array(), '', false);
    add_option('uwmcp_audit', array(), '', false);
    uwmcp_rewrite_rules();
    flush_rewrite_rules(false);
});
register_deactivation_hook(__FILE__, function(){ flush_rewrite_rules(false); });
