# ReThinkable Editorial Kit 1.1.0

This is a small, update-safe WordPress plugin for ReThinkable RT.5.

## What it does

- Adds a **ReThinkable RT.5 - Contenuti della homepage** box to the existing homepage edit screen (WordPress page **12467**). It uses the site's existing **Advanced Custom Fields** plugin.
- Provides tabs for **Media, Italiano, Slovenščina and English**. An editor can change the title, opening texts, programme heading/introduction, ReThinkable section and participation section without editing HTML.
- Imports existing homepage copy into the fields the first time an editor opens the WordPress administration area after activation. The original page body is preserved as an automatic fallback. **The public content remains untouched until an administrator explicitly enables the new editing system.**
- Provides a **ReThinkable - Gestione quotidiana** dashboard widget linking directly to events, the homepage, media and the internal guide.
- Adds a publishing checklist to Events Manager event editing screens.
- Applies restrained typography to **single event pages only**, keeping event metadata smaller than descriptions.
- Does not change theme files, menus, booking data, plugin settings, users, roles, passwords or existing event records.

## Installation / test procedure

1. **Before installation**, verify a recent backup including the database and theme; preferably test on staging. WordPress has UpdraftPlus with daily Google Drive backups configured, but a successful restore has not been confirmed.
2. As a WordPress administrator, open **Plugins → Add Plugin → Upload Plugin**: `/wp-admin/plugin-install.php?tab=upload`.
3. Upload `rethinkable-editorial-kit-v1.1.0.zip`, install and activate.
4. Open **Pages → Homepage RT.5 - test editoriale** (ID 12467). There should be a tabbed editing box. Check the initial fields match the current live text in each language, and check the media fields.
5. Edit **one sentence** in one language and click Update. The public homepage is still unchanged at this stage (safe by default). Record the original sentence and verify the other languages are populated correctly. After enabling in step 6, open the public homepage and check that this single sentence changed and all others are unaffected.
6. Open **Homepage & Design → Design settings** and, after reviewing the imported fields and confirming your backup/staging test, tick the enable box and save. Only now will the edited homepage fields and the event / legacy-page CSS affect the public site.
7. Open **Events → an existing event** and check the new publishing checklist. Check both desktop and mobile event detail typography and bookings.
8. Check the WordPress **Dashboard** for the new quick-access widget.
9. Review the internal draft guide at `/wp-admin/post.php?post=12521&action=edit` and decide where CVCS wishes to keep the final handover documentation.

## Rollback and caveats

- The plugin starts in **public changes disabled** mode. To switch it on or off, use **Homepage & Design → Design settings**. This is deliberately restricted to administrators.
- If the plugin is deactivated, the page reverts to its original raw HTML. **Edits saved in ACF are retained as post metadata but no longer appear on the public page until the plugin is reactivated.** Export important editorial changes before permanently removing the plugin.
- The kit is intentionally scoped to **WordPress page 12467** and the **event** custom post type. If the homepage is replaced with a new page, the page ID in the plugin must be updated before relying on it.
- If ACF is inactive, the original page remains visible; the editing fields do not appear.
- The original page HTML remains stored, and the code editor is merely hidden on that page while the plugin and ACF are active. Site administrators with database access can still edit it.
- The plugin has passed PHP syntax checking and local rendering/import tests. It **has not been integration-tested on the production WordPress site**. Test on staging and perform the acceptance checks above before relying on it for ongoing editorial work.
- Do not add emoji icons to the site. The graphic asterisk is deliberately a monochrome text glyph.

## Operational responsibility

**Editorial:** add/update events, translations, copy, images, links, previews and booking details.

**Technical:** plugin updates, security, backup restoration, hosting/domain ownership, database, CSS and PHP, access management.

The plugin does **not** change access rights, move Aruba ownership, inspect historical data access, verify offsite restoration or solve incident-response and GDPR responsibilities. Those require explicit decisions by CVCS, its designated administrator and, as appropriate, data protection specialists.

### Links, quotes and older pages

The language tabs also allow editing the visible CTA labels, full programme/participation URLs, quotation text and its attribution. The hero button still scrolls to the programme section, so its destination remains protected. The contact mailto address is intentionally not editable here; it should be managed by CVCS as an organisation-wide setting.

The plugin includes subtle style corrections for the existing Participate, Support, Volunteer and Donate pages (IDs 10966, 10594, 8714, 10596). It loads those styles only on those pages and does not change their forms, shortcode content or payment information. It also carries the current IBM Plex Sans / Instrument Serif enqueue, so an Inspiro theme update will not silently remove the typography.

The existing 35-plugin inventory was reviewed for historical shortcode dependencies. Smart Slider 3 still occurs in archival pages/events; Shortcodes Ultimate occurs in event galleries/buttons and the Support page; Contact Form 7 still occurs in contact/booking pages. **Do not deactivate these merely because the new homepage no longer needs them.**

## Sidebar (1.1)
Separate top-level **Homepage & Design** menu. Its administrator-only Design settings submenu controls homepage publishing. ACF data is preserved.
