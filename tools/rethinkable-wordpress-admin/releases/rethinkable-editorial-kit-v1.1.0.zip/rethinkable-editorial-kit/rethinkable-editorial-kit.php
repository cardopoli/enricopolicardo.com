<?php
/**
 * Plugin Name: ReThinkable Editorial Kit
 * Description: Safe RT.5 homepage fields, editorial guidance and restrained event styles.
 * Version: 1.1.0
 * Author: ReThinkable
 * Requires PHP: 7.4
 * Text Domain: rethinkable-editorial-kit
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const RT_EDITORIAL_HOME_ID = 12467;
const RT_EDITORIAL_GUIDE_ID = 12521;

function rt_editorial_field_definitions() {
    return array(
        'hero_title'      => array( 'Titolo principale (senza punto finale)', 'text', 1 ),
        'hero_statement'  => array( 'Frase di apertura', 'textarea', 3 ),
        'hero_copy'       => array( 'Testo di apertura', 'textarea', 6 ),
        'programme_title' => array( 'Titolo del programma (senza punto finale)', 'text', 1 ),
        'programme_intro' => array( 'Introduzione al programma', 'textarea', 3 ),
        'about_title'     => array( 'Titolo sezione ReThinkable', 'text', 1 ),
        'about_copy'      => array( 'Testo sezione ReThinkable', 'textarea', 7 ),
        'participate_title' => array( 'Titolo sezione partecipazione', 'text', 1 ),
        'participate_copy'  => array( 'Testo sezione partecipazione', 'textarea', 5 ),
        'hero_link_label' => array( 'Testo del pulsante programma', 'text', 1 ),
        'programme_link_label' => array( 'Testo link programma completo', 'text', 1 ),
        'programme_link_url' => array( 'Indirizzo pagina programma completo', 'url', 1 ),
        'participate_link_label' => array( 'Testo link partecipazione', 'text', 1 ),
        'participate_link_url' => array( 'Indirizzo pagina partecipazione', 'url', 1 ),
        'contact_link_label' => array( 'Testo link contatto', 'text', 1 ),
        'quote_text' => array( 'Citazione', 'textarea', 4 ),
        'quote_attribution' => array( 'Attribuzione citazione', 'text', 1 ),
    );
}

add_action( 'acf/init', 'rt_editorial_register_acf_fields' );
function rt_editorial_register_acf_fields() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }
    $fields = array(
        array(
            'key' => 'field_rt5_media_tab', 'label' => 'Media condivisi', 'name' => '',
            'type' => 'tab', 'placement' => 'top',
        ),
        array(
            'key' => 'field_rt5_hero_video', 'label' => 'Video di apertura (MP4)', 'name' => 'rt5_hero_video',
            'type' => 'file', 'return_format' => 'url', 'library' => 'all', 'mime_types' => 'mp4',
            'instructions' => 'Il video è senza audio, in loop. Se non si carica, appare la foto di copertina.',
        ),
        array(
            'key' => 'field_rt5_hero_poster', 'label' => 'Immagine di copertina / riserva', 'name' => 'rt5_hero_poster',
            'type' => 'image', 'return_format' => 'url', 'library' => 'all', 'preview_size' => 'medium',
            'instructions' => 'Mostrata mentre il video si carica oppure se non può essere riprodotto.',
        ),
    );
    foreach ( array( 'it' => 'Italiano', 'sl' => 'Slovenščina', 'en' => 'English' ) as $lang => $display ) {
        $fields[] = array(
            'key' => 'field_rt5_tab_' . $lang, 'label' => $display,
            'name' => '', 'type' => 'tab', 'placement' => 'top',
        );
        foreach ( rt_editorial_field_definitions() as $name => $details ) {
            $fields[] = array(
                'key' => 'field_rt5_' . $name . '_' . $lang,
                'label' => $details[0],
                'name' => 'rt5_' . $name . '_' . $lang,
                'type' => $details[1],
                'rows' => $details[2],
                'new_lines' => '',
                'instructions' => 'Solo testo: non inserire HTML, simboli decorativi o shortcode.',
                'wrapper' => array( 'width' => '100' ),
            );
        }
    }
    acf_add_local_field_group( array(
        'key' => 'group_rethinkable_rt5_editorial',
        'title' => 'ReThinkable RT.5 - Contenuti della homepage',
        'fields' => $fields,
        'location' => array( array( array( 'param' => 'page', 'operator' => '==', 'value' => (string) RT_EDITORIAL_HOME_ID ) ) ),
        'menu_order' => -20,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
        'description' => 'Modifica soltanto i testi e i media. Il layout rimane protetto.',
    ) );
}

/**
 * Copy the current content into ACF once, after the fields exist.
 * This prevents an editor from encountering dozens of empty fields and keeps
 * the public page exactly as it was on activation.
 */
add_action( 'admin_init', 'rt_editorial_import_existing_content', 50 );
function rt_editorial_import_existing_content() {
    if ( ! current_user_can( 'edit_post', RT_EDITORIAL_HOME_ID ) || ! function_exists( 'update_field' ) ) { return; }
    if ( get_option( 'rt_editorial_kit_imported_v1' ) ) { return; }
    $post = get_post( RT_EDITORIAL_HOME_ID );
    if ( ! $post || 'page' !== $post->post_type ) { return; }
    foreach ( array( 'it', 'sl', 'en' ) as $lang ) {
        $section = rt_editorial_extract_language( $post->post_content, $lang );
        if ( '' === $section ) { continue; }
        $values = rt_editorial_extract_defaults( $section, $lang );
        foreach ( $values as $name => $value ) {
            if ( '' !== $value && ! metadata_exists( 'post', RT_EDITORIAL_HOME_ID, 'rt5_' . $name . '_' . $lang ) ) {
                update_field( 'field_rt5_' . $name . '_' . $lang, $value, RT_EDITORIAL_HOME_ID );
            }
        }
    }
    $it = rt_editorial_extract_language( $post->post_content, 'it' );
    if ( $it ) {
        if ( preg_match( '~<source\s+src="([^"]+\.mp4)"~i', $it, $m ) ) {
            $id = attachment_url_to_postid( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) );
            if ( $id && ! metadata_exists( 'post', RT_EDITORIAL_HOME_ID, 'rt5_hero_video' ) ) {
                update_field( 'field_rt5_hero_video', $id, RT_EDITORIAL_HOME_ID );
            }
        }
        if ( preg_match( '~<img[^>]*class="[^"]*rtx-hero-fallback[^\"]*"[^>]*src="([^"]+)"~i', $it, $m ) ) {
            $id = attachment_url_to_postid( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) );
            if ( $id && ! metadata_exists( 'post', RT_EDITORIAL_HOME_ID, 'rt5_hero_poster' ) ) {
                update_field( 'field_rt5_hero_poster', $id, RT_EDITORIAL_HOME_ID );
            }
        }
    }
    update_option( 'rt_editorial_kit_imported_v1', '1', false );
}

function rt_editorial_extract_language( $content, $lang ) {
    $pattern = '~\[:' . preg_quote( $lang, '~' ) . '\](.*?)(?=\[:(?:it|sl|en)\]|\[:\]|\z)~s';
    return preg_match( $pattern, $content, $m ) ? $m[1] : '';
}
function rt_editorial_plain( $html ) {
    return trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
}
function rt_editorial_extract_defaults( $part, $lang ) {
    $v = array();
    if ( preg_match( '~<h1\s+id="rtx-title-' . preg_quote( $lang, '~' ) . '"[^>]*>(.*?)</h1>~s', $part, $m ) ) {
        $v['hero_title'] = rtrim( rt_editorial_plain( $m[1] ), '.' );
    }
    foreach ( array( 'hero_statement', 'hero_copy' ) as $name ) {
        if ( preg_match( '~<p\s+class="' . preg_quote( 'rtx-' . str_replace( '_', '-', $name ), '~' ) . '"[^>]*>(.*?)</p>~s', $part, $m ) ) {
            $v[$name] = rt_editorial_plain( $m[1] );
        }
    }
    if ( preg_match( '~<header\s+class="rtx-section-header">(.*?)</header>~s', $part, $m ) ) {
        if ( preg_match( '~<h2[^>]*>(.*?)</h2>~s', $m[1], $title ) ) { $v['programme_title'] = rtrim( rt_editorial_plain( $title[1] ), '.' ); }
        if ( preg_match( '~<p[^>]*>(.*?)</p>~s', $m[1], $intro ) ) { $v['programme_intro'] = rt_editorial_plain( $intro[1] ); }
    }
    if ( preg_match( '~<div\s+class="rtx-creature-body">\s*<h2[^>]*>(.*?)</h2>(.*?)</div>~s', $part, $m ) ) {
        $v['about_title'] = rt_editorial_plain( $m[1] );
        $v['about_copy'] = rt_editorial_plain( $m[2] );
    }
    if ( preg_match( '~<section\s+class="rtx-afterword">(.*?)</section>~s', $part, $m ) ) {
        if ( preg_match( '~<h2[^>]*>(.*?)</h2>~s', $m[1], $title ) ) { $v['participate_title'] = rt_editorial_plain( $title[1] ); }
        if ( preg_match( '~<p[^>]*>(.*?)</p>~s', $m[1], $copy ) ) { $v['participate_copy'] = rt_editorial_plain( $copy[1] ); }
    }
    if ( preg_match( '~<div\s+class="rtx-hero-bottom">\s*<a[^>]*>(.*?)</a>~s', $part, $m ) ) {
        $v['hero_link_label'] = rt_editorial_plain( $m[1] );
    }
    if ( preg_match( '~<a\s+class="rtx-more"\s+href="([^"]+)"[^>]*>(.*?)</a>~s', $part, $m ) ) {
        $v['programme_link_url'] = html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
        $v['programme_link_label'] = rt_editorial_plain( $m[2] );
    }
    if ( preg_match( '~<div\s+class="rtx-after-links">\s*<a\s+href="([^"]+)"[^>]*>(.*?)</a>\s*<a[^>]*>(.*?)</a>~s', $part, $m ) ) {
        $v['participate_link_url'] = html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
        $v['participate_link_label'] = rt_editorial_plain( $m[2] );
        $v['contact_link_label'] = rt_editorial_plain( $m[3] );
    }
    if ( preg_match( '~<section\s+class="rtx-quote"[^>]*>.*?<blockquote>\s*<p>(.*?)</p>\s*<footer>(.*?)</footer>~s', $part, $m ) ) {
        $v['quote_text'] = rt_editorial_plain( $m[1] );
        $v['quote_attribution'] = rt_editorial_plain( $m[2] );
    }
    return $v;
}

function rt_editorial_acf_text( $name, $lang ) {
    if ( ! function_exists( 'get_field' ) ) { return ''; }
    $value = get_field( 'rt5_' . $name . '_' . $lang, RT_EDITORIAL_HOME_ID );
    return is_string( $value ) ? trim( $value ) : '';
}
function rt_editorial_html_text( $value ) {
    return nl2br( esc_html( $value ) );
}
function rt_editorial_replace_class( $content, $tag, $class, $html ) {
    if ( '' === $html ) { return $content; }
    $pattern = '~(<' . preg_quote( $tag, '~' ) . '\b(?=[^>]*\bclass="[^"]*\b' . preg_quote( $class, '~' ) . '\b[^\"]*")[^>]*>)(.*?)(</' . preg_quote( $tag, '~' ) . '>)~is';
    return preg_replace_callback( $pattern, static function ( $m ) use ( $html ) {
        return $m[1] . $html . $m[3];
    }, $content, 1 );
}

function rt_editorial_apply_lang( $content, $lang ) {
    $hero_title = rt_editorial_acf_text( 'hero_title', $lang );
    if ( '' !== $hero_title ) {
        $pattern = '~(<h1\s+id="rtx-title-' . preg_quote( $lang, '~' ) . '"[^>]*>)(.*?)(</h1>)~is';
        $content = preg_replace_callback( $pattern, static function ( $m ) use ( $hero_title ) {
            return $m[1] . esc_html( rtrim( $hero_title, '.' ) ) . '<i>.</i>' . $m[3];
        }, $content, 1 );
    }
    foreach ( array( 'hero_statement', 'hero_copy' ) as $name ) {
        $value = rt_editorial_acf_text( $name, $lang );
        if ( '' !== $value ) {
            $content = rt_editorial_replace_class( $content, 'p', 'rtx-' . str_replace( '_', '-', $name ), rt_editorial_html_text( $value ) );
        }
    }
    $programme_title = rt_editorial_acf_text( 'programme_title', $lang );
    $programme_intro = rt_editorial_acf_text( 'programme_intro', $lang );
    if ( $programme_title || $programme_intro ) {
        $content = preg_replace_callback( '~(<header\s+class="rtx-section-header">)(.*?)(</header>)~is', static function ( $m ) use ( $programme_title, $programme_intro ) {
            $inner = $m[2];
            if ( $programme_title ) {
                $inner = preg_replace_callback( '~(<h2[^>]*>)(.*?)(</h2>)~is', static function ( $t ) use ( $programme_title ) {
                    return $t[1] . esc_html( rtrim( $programme_title, '.' ) ) . '<i>.</i>' . $t[3];
                }, $inner, 1 );
            }
            if ( $programme_intro ) {
                $intro_html = '<p>' . rt_editorial_html_text( $programme_intro ) . '</p>';
                if ( preg_match( '~<p\b~i', $inner ) ) {
                    $inner = preg_replace( '~<p[^>]*>.*?</p>~is', $intro_html, $inner, 1 );
                } else {
                    $inner .= $intro_html;
                }
            }
            return $m[1] . $inner . $m[3];
        }, $content, 1 );
    }
    $about_title = rt_editorial_acf_text( 'about_title', $lang );
    $about_copy = rt_editorial_acf_text( 'about_copy', $lang );
    if ( $about_title || $about_copy ) {
        $content = preg_replace_callback( '~(<div\s+class="rtx-creature-body">\s*<h2[^>]*>)(.*?)(</h2>)(.*?)(</div>)~is', static function ( $m ) use ( $about_title, $about_copy ) {
            return $m[1] . ( $about_title ? esc_html( $about_title ) : $m[2] ) . $m[3] .
                ( $about_copy ? '<p>' . rt_editorial_html_text( $about_copy ) . '</p>' : $m[4] ) . $m[5];
        }, $content, 1 );
    }
    $participate_title = rt_editorial_acf_text( 'participate_title', $lang );
    $participate_copy = rt_editorial_acf_text( 'participate_copy', $lang );
    if ( $participate_title || $participate_copy ) {
        $content = preg_replace_callback( '~(<section\s+class="rtx-afterword">\s*<div>.*?<h2[^>]*>)(.*?)(</h2>.*?<div>\s*<p[^>]*>)(.*?)(</p>)~is', static function ( $m ) use ( $participate_title, $participate_copy ) {
            return $m[1] . ( $participate_title ? esc_html( $participate_title ) : $m[2] ) . $m[3] .
                ( $participate_copy ? rt_editorial_html_text( $participate_copy ) : $m[4] ) . $m[5];
        }, $content, 1 );
    }
    $hero_link_label = rt_editorial_acf_text( 'hero_link_label', $lang );
    if ( $hero_link_label ) {
        $content = preg_replace_callback( '~(<a\s+class="rtx-link rtx-link-solid"[^>]*>)(.*?)(</a>)~is', static function( $m ) use ( $hero_link_label ) {
            return $m[1] . esc_html( $hero_link_label ) . $m[3];
        }, $content, 1 );
    }
    $programme_link_label = rt_editorial_acf_text( 'programme_link_label', $lang );
    $programme_link_url = rt_editorial_acf_text( 'programme_link_url', $lang );
    if ( $programme_link_label || $programme_link_url ) {
        $content = preg_replace_callback( '~(<a\s+class="rtx-more"[^>]*>)(.*?)(</a>)~is', static function ( $m ) use ( $programme_link_label, $programme_link_url ) {
            $open = $m[1];
            if ( $programme_link_url ) { $open = preg_replace( '~\bhref="[^"]*"~', 'href="' . esc_url( $programme_link_url ) . '"', $open, 1 ); }
            return $open . ( $programme_link_label ? esc_html( $programme_link_label ) : $m[2] ) . $m[3];
        }, $content, 1 );
    }
    $join_label = rt_editorial_acf_text( 'participate_link_label', $lang );
    $join_url = rt_editorial_acf_text( 'participate_link_url', $lang );
    $contact_label = rt_editorial_acf_text( 'contact_link_label', $lang );
    if ( $join_label || $join_url || $contact_label ) {
        $content = preg_replace_callback( '~(<div\s+class="rtx-after-links">)(.*?)(</div>)~is', static function ( $m ) use ( $join_label, $join_url, $contact_label ) {
            $index = 0;
            $inner = preg_replace_callback( '~(<a\b[^>]*>)(.*?)(</a>)~is', static function ( $a ) use ( &$index, $join_label, $join_url, $contact_label ) {
                $index++;
                if ( 1 === $index ) {
                    $open = $join_url ? preg_replace( '~\bhref="[^"]*"~', 'href="' . esc_url( $join_url ) . '"', $a[1], 1 ) : $a[1];
                    return $open . ( $join_label ? esc_html( $join_label ) : $a[2] ) . $a[3];
                }
                if ( 2 === $index && $contact_label ) { return $a[1] . esc_html( $contact_label ) . $a[3]; }
                return $a[0];
            }, $m[2] );
            return $m[1] . $inner . $m[3];
        }, $content, 1 );
    }
    $quote_text = rt_editorial_acf_text( 'quote_text', $lang );
    $quote_attribution = rt_editorial_acf_text( 'quote_attribution', $lang );
    if ( $quote_text || $quote_attribution ) {
        $content = preg_replace_callback( '~(<section\s+class="rtx-quote"[^>]*>.*?<blockquote>)(.*?)(</blockquote>)~is', static function( $m ) use ( $quote_text, $quote_attribution ) {
            $inner = $m[2];
            if ( $quote_text ) { $inner = preg_replace( '~<p>.*?</p>~is', '<p>' . rt_editorial_html_text( $quote_text ) . '</p>', $inner, 1 ); }
            if ( $quote_attribution ) { $inner = preg_replace( '~<footer>.*?</footer>~is', '<footer>' . esc_html( $quote_attribution ) . '</footer>', $inner, 1 ); }
            return $m[1] . $inner . $m[3];
        }, $content, 1 );
    }
    return $content;
}

add_filter( 'the_content', 'rt_editorial_render_homepage', 20 );
function rt_editorial_render_homepage( $content ) {
    if ( ! get_option( 'rt_editorial_kit_live_enabled', false ) || ! function_exists( 'get_field' ) || ! is_page( RT_EDITORIAL_HOME_ID ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( false === strpos( $content, 'rtx-lang-' ) ) { return $content; }
    if ( preg_match( '~\[:(?:it|sl|en)\]~', $content ) ) {
        $parts = preg_split( '~(\[:(?:it|sl|en)\]|\[:\])~', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
        $lang = '';
        foreach ( $parts as &$part ) {
            if ( preg_match( '~^\[:(it|sl|en)\]$~', $part, $m ) ) { $lang = $m[1]; continue; }
            if ( '[:]' === $part ) { $lang = ''; continue; }
            if ( $lang && false !== strpos( $part, 'rtx-lang-' . $lang ) ) {
                $part = rt_editorial_apply_lang( $part, $lang );
            }
        }
        unset( $part );
        $content = implode( '', $parts );
    } else {
        foreach ( array( 'it', 'sl', 'en' ) as $lang ) {
            if ( false !== strpos( $content, 'rtx-lang-' . $lang ) ) {
                $content = rt_editorial_apply_lang( $content, $lang );
                break;
            }
        }
    }
    $video = get_field( 'rt5_hero_video', RT_EDITORIAL_HOME_ID );
    $poster = get_field( 'rt5_hero_poster', RT_EDITORIAL_HOME_ID );
    if ( is_array( $video ) ) { $video = isset( $video['url'] ) ? $video['url'] : ''; }
    if ( is_array( $poster ) ) { $poster = isset( $poster['url'] ) ? $poster['url'] : ''; }
    if ( $poster && filter_var( $poster, FILTER_VALIDATE_URL ) ) {
        $content = preg_replace_callback( '~(<img\b[^>]*class="[^"]*rtx-hero-fallback[^\"]*"[^>]*\bsrc=")([^"]*)(")~i', static function( $m ) use ( $poster ) { return $m[1] . esc_url( $poster ) . $m[3]; }, $content );
        $content = preg_replace_callback( '~(<video\b[^>]*class="[^"]*rtx-hero-video[^\"]*"[^>]*\bposter=")([^"]*)(")~i', static function( $m ) use ( $poster ) { return $m[1] . esc_url( $poster ) . $m[3]; }, $content );
    }
    if ( $video && filter_var( $video, FILTER_VALIDATE_URL ) ) {
        $content = preg_replace( '~(<source\s+src=")[^"]+("\s+type="video/mp4")~i', '${1}' . esc_url( $video ) . '${2}', $content );
    }
    return $content;
}

add_action( 'admin_head-post.php', 'rt_editorial_hide_html_editor_on_home' );
function rt_editorial_hide_html_editor_on_home() {
    if ( ! function_exists( 'acf_add_local_field_group' ) || ! isset( $_GET['post'] ) || RT_EDITORIAL_HOME_ID !== absint( $_GET['post'] ) ) { return; }
    echo '<style>#postdivrich, #wp-content-wrap, .block-editor-writing-flow { display:none !important; }</style>';
    echo '<script>document.addEventListener("DOMContentLoaded",function(){var x=document.createElement("p");x.textContent="Per questa homepage modifica i campi ReThinkable RT.5 qui sotto. Il codice HTML originale rimane protetto come riserva.";x.style.cssText="padding:10px 14px;background:#f5f2ea;border-left:3px solid #171715";var a=document.querySelector("#post-body-content");if(a)a.prepend(x);});</script>';
}

add_action( 'wp_dashboard_setup', 'rt_editorial_dashboard_widget' );
function rt_editorial_dashboard_widget() {
    if ( ! current_user_can( 'edit_posts' ) ) { return; }
    wp_add_dashboard_widget( 'rt_editorial_quickstart', 'ReThinkable - Gestione quotidiana', 'rt_editorial_dashboard_output' );
}
function rt_editorial_dashboard_output() {
    $links = array(
        'Pubblica un evento' => admin_url( 'post-new.php?post_type=event' ),
        'Elenco eventi' => admin_url( 'edit.php?post_type=event' ),
        'Modifica homepage RT.5' => get_edit_post_link( RT_EDITORIAL_HOME_ID ),
        'Guida operativa (bozza interna)' => get_edit_post_link( RT_EDITORIAL_GUIDE_ID ),
        'Carica immagine o video' => admin_url( 'media-new.php' ),
    );
    echo '<p>Le attività editoriali si svolgono qui. Non modificare plugin, tema o credenziali per aggiornare un evento.</p><ul>';
    foreach ( $links as $name => $url ) {
        if ( $url ) { echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $name ) . '</a></li>'; }
    }
    echo '</ul><p><strong>Controllo prima di pubblicare:</strong> IT / SL / EN, data, luogo, iscrizioni, immagine, tag <code>rt5</code>.</p>';
    if ( current_user_can( 'manage_options' ) ) {
        echo '<p><a href="' . esc_url( admin_url( 'options-general.php?page=rt-editorial-settings' ) ) . '">Attivazione modifiche pubbliche (solo amministratori)</a></p>';
    }
}

add_action( 'add_meta_boxes_event', 'rt_editorial_event_checklist' );
function rt_editorial_event_checklist() {
    add_meta_box( 'rt5_event_checklist', 'ReThinkable - Controllo prima della pubblicazione', 'rt_editorial_event_checklist_output', 'event', 'side', 'default' );
}
function rt_editorial_event_checklist_output() {
    echo '<p>Verifica prima di pubblicare:</p><ol>';
    foreach ( array( 'Titolo e descrizione in IT / SL / EN', 'Estratto breve e leggibile', 'Data, ora e luogo esatti', 'Tag rt5 per i prossimi eventi RT.5', 'Prenotazioni e capienza corrette', 'Foto e collegamenti verificati' ) as $item ) {
        echo '<li>' . esc_html( $item ) . '</li>';
    }
    echo '</ol><p>Le prenotazioni restano gestite da Events Manager.</p>';
}

/* Keep the shared typefaces available if Inspiro is updated. The current
 * parent theme uses the same style handle, so it is not enqueued twice. */
add_action( 'wp_enqueue_scripts', 'rt_editorial_enqueue_fonts', 20 );
function rt_editorial_enqueue_fonts() {
    wp_enqueue_style( 'rt-editorial-typefaces',
        'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=Instrument+Serif:ital@0;1&display=swap',
        array(), null );
}

add_action( 'wp_enqueue_scripts', 'rt_editorial_enqueue_event_css', 50 );
function rt_editorial_enqueue_event_css() {
    if ( ! get_option( 'rt_editorial_kit_live_enabled', false ) ) { return; }
    if ( is_singular( 'event' ) ) {
        wp_enqueue_style( 'rt-editorial-event', plugin_dir_url( __FILE__ ) . 'assets/events.css', array(), '1.0.0' );
    }
    if ( is_page( array( 10966, 10594, 10596, 8714 ) ) ) {
        wp_enqueue_style( 'rt-editorial-pages', plugin_dir_url( __FILE__ ) . 'assets/legacy-pages.css', array(), '1.0.0' );
    }
}

/* Intentionally opt in to frontend changes only after a preview check. */
add_action( 'admin_init', 'rt_editorial_register_settings', 5 );
function rt_editorial_register_settings() {
    register_setting( 'rt_editorial_kit_settings', 'rt_editorial_kit_live_enabled', array(
        'type' => 'boolean', 'default' => false, 'sanitize_callback' => 'absint',
    ) );
}
add_action( 'admin_menu', 'rt_editorial_settings_menu' );
function rt_editorial_settings_menu() {
    add_menu_page( 'Homepage & Design', 'Homepage & Design', 'edit_pages',
        'rt-editorial-home', 'rt_editorial_admin_home', 'dashicons-layout', 30 );
    add_submenu_page('rt-editorial-home', 'Homepage editor', 'Homepage editor',
        'edit_pages', 'rt-editorial-home', 'rt_editorial_admin_home');
    add_submenu_page('rt-editorial-home', 'Design settings', 'Design settings',
        'manage_options', 'rt-editorial-settings', 'rt_editorial_settings_page');
}
function rt_editorial_admin_home() {
    if ( ! current_user_can( 'edit_pages' ) ) { wp_die( 'Insufficient permissions.' ); }
    echo '<div class="wrap"><h1>Homepage &amp; Design</h1>';
    echo '<p>Change RT.5 homepage text, images and video using the guided editor. Keep the layout intact.</p>';
    echo '<p><a class="button button-primary" href="' . esc_url( get_edit_post_link( RT_EDITORIAL_HOME_ID ) ) . '">Edit homepage</a></p>';
    if ( current_user_can( 'manage_options' ) ) {
        echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=rt-editorial-settings' ) ) . '">Design and publishing settings</a></p>';
    }
    echo '</div>';
}
function rt_editorial_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    $enabled = (bool) get_option( 'rt_editorial_kit_live_enabled', false );
    echo '<div class="wrap"><h1>ReThinkable - Homepage e pagine eventi</h1>';
    echo '<p>Questo plugin offre un editor guidato per la homepage e piccoli miglioramenti alle pagine esistenti. Di default le modifiche pubbliche sono <strong>disattivate</strong> per sicurezza.</p>';
    echo '<form method="post" action="options.php">';
    settings_fields( 'rt_editorial_kit_settings' );
    echo '<input type="hidden" name="rt_editorial_kit_live_enabled" value="0">';
    echo '<label><input type="checkbox" name="rt_editorial_kit_live_enabled" value="1" ' . checked( $enabled, true, false ) . '> Attiva i campi della homepage e gli stili editoriali sul sito pubblico</label>';
    echo '<p>Prima di attivare: verifica IT / SL / EN, video, link, un evento e le iscrizioni. Tieni un backup verificato.</p>';
    submit_button( 'Salva impostazioni' );
    echo '</form><p><a href="' . esc_url( get_edit_post_link( RT_EDITORIAL_HOME_ID ) ) . '">Modifica homepage RT.5</a></p></div>';
}

add_action( 'admin_notices', 'rt_editorial_acf_notice' );
function rt_editorial_acf_notice() {
    if ( function_exists( 'acf_add_local_field_group' ) || ! current_user_can( 'manage_options' ) ) { return; }
    echo '<div class="notice notice-warning"><p>ReThinkable Editorial Kit richiede Advanced Custom Fields attivo. Il sito pubblico non viene modificato finché ACF non è disponibile.</p></div>';
}
