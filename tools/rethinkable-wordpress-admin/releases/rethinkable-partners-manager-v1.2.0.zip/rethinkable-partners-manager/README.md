# ReThinkable Partners Manager 1.2.0

WordPress plugin for edition-based partner and supporter credits. Each edition has its own organisation list, logo, role, website URL, ordering and visibility. This package bundles the nine logos supplied for RT.5 (2026-27).

## WordPress

After installation the plugin has its own main sidebar entry: **Partners & Supporters**. It does not manage the other plugins. Use **Partners & Supporters → Manage partners** to edit one edition; use **Copy to new edition** to prepare the next festival while keeping the current site unchanged. Only administrators can publish the new active edition. All existing options are retained when upgrading. Do not uninstall the old version before replacing the ZIP.

The footer retains the Inspiro layout and automatically renders smaller, linked partner logos and a separate supporter row. Check older logo widgets for duplication before deleting them. The plugin renders current partner links in marked About-page blocks; fixed edition markers keep the RT.5 programme and media kit historically correct.

## Shortcodes

- `[rt_partners]` for linked logos.
- `[rt_partners format="sentence"]` for the translated current-edition credits.
- `[rt_partners edition="2026-27" format="sentence"]` for fixed historical credits.

## Requirements

WordPress and an active theme. Automatic footer placement currently hooks into Inspiro's footer template part; for other themes add `[rt_partners]` in the footer. qTranslate-XT enables the three-language labels, but is not required for the database model. Store logos in the WordPress media library when updating an edition.

## Installation and checks

1. Confirm a recent database and file backup. Prefer testing on staging.
2. Plugins → Add New → Upload Plugin; upload the v1.2.0 ZIP and replace the existing plugin when prompted. Do not uninstall it.
3. Check the Partners & Supporters main menu, links and all nine logos.
4. Preview /it/, /sl/ and /en/ including mobile. Remove any old duplicated partner-logo widget, not unrelated widgets.
5. Check 'Chi siamo', RT.5 programme and media-kit credits, then test creating a **copy** of the edition without publishing it.

## Links

Official organisation URLs or authoritative profiles are stored in the edition records, editable in WordPress. proDES FVG initially links to its RIES profile; check every link before publishing a new edition. The intended CVCS name is **Centro Volontari Cooperazione allo Sviluppo - CVCS**.

## Support and security

The plugin checks nonces and capabilities, sanitises stored metadata and escapes links and labels on output. Editors may prepare lists, but only administrators activate an edition. No credentials, personal data, OAuth tokens, database exports, or backups are part of this distribution.

Documentation: https://github.com/cardopoli/enricopolicardo.com/tree/main/docs/rethinkable-wordpress-admin/
