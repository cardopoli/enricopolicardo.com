## 1.2.1 - 2026-11-20
- Fix duplicate oversized footer: integrate logos into existing original footer widgets.
- Keep historical Regione FVG, Io Sono FVG, GO!2025, Gorizia and Nova Gorica logos untouched; do not repeat their images.
- Add RT.5 partners in three compact columns and Cassa Rurale FVG alongside existing support logos.
- Preserve hyperlinks and per-edition partner administration; no migration of options.
- Progressive enhancement; keep extra footer hidden if theme structure cannot be found.

## 1.2.0 - 2026-11-20
- Standalone Partners & Supporters sidebar menu.
- Retain edition records, existing partner links and logos.

# Changelog

## 1.1.0 (2026-11-20)

- Introduced a unified **ReThinkable** WordPress sidebar hub, grouping Partners, Homepage, Editorial Kit, AI / MCP Bridge and Guide links.
- Added official/profile links for the nine RT.5 organisations, with a one-time migration that fills only empty URLs in existing v1.0.0 data.
- Linked organisation names in current and historical page credit paragraphs/lists as well as logos in the footer.
- Restricted publishing a different active edition to administrators.
- Added component/dependency status overview, upgrade documentation and partner link inventory.
- Retained footer widgets and responsive logo grid styling.

## 1.0.0 (2026-11-20)

- Initial edition-aware partner manager, logos, shortcodes and automatic Inspiro footer integration.
