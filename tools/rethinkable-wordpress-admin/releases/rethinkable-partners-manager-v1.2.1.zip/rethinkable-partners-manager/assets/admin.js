(function($){
'use strict';
$(function(){
  const table=$('#rtp-table tbody');
  let next=table.find('tr').length;
  const esc=(s)=>String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
  function row(i){const p='partners['+i+']';return `<tr class="rtp-row"><td><input type="number" class="small-text" min="0" max="999" name="${p}[sort]" value="${i+1}"></td><td><input class="regular-text" name="${p}[name]" required aria-label="Organisation name"></td><td><select name="${p}[role]"><option value="partner">Partner</option><option value="supporter">Supporter</option></select></td><td><input class="rtp-logo-url" name="${p}[logo]" aria-label="Logo image URL"><button type="button" class="button rtp-pick">Media</button></td><td><input type="url" name="${p}[url]" placeholder="https://" aria-label="Website URL"></td><td><input type="checkbox" name="${p}[enabled]" value="1" checked aria-label="Visible"></td><td><button type="button" class="button-link-delete rtp-remove">Remove</button></td></tr>`;}
  $('#rtp-add').on('click',function(){table.append(row(next++));});
  table.on('click','.rtp-remove',function(){if(window.confirm('Remove this organisation from the current edition?')) $(this).closest('tr').remove();});
  table.on('click','.rtp-pick',function(){const input=$(this).siblings('.rtp-logo-url');const frame=wp.media({title:'Choose partner logo',library:{type:'image'},multiple:false,button:{text:'Use this logo'}});frame.on('select',function(){const a=frame.state().get('selection').first().toJSON();input.val(a.url||'');});frame.open();});
});})(jQuery);
