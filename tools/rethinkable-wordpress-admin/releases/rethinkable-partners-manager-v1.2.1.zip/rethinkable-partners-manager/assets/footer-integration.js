/* ReThinkable footer integration: no new footer row, no widget alterations. */
(function () {
  'use strict';
  function integrate() {
    var footer = document.querySelector('#colophon');
    if (!footer) return;
    var staging = footer.querySelector('.rtp-footer-staging');
    var widgets = footer.querySelector('.footer-widgets');
    if (!staging || !widgets || widgets.classList.contains('rtp-footer-combined')) return;
    var columns = Array.prototype.filter.call(widgets.children, function (el) {
      return el.classList.contains('widget-column');
    });
    // Never assume that an unfamiliar theme has the ReThinkable footer structure.
    if (columns.length !== 4) return;
    var partnerGroup = staging.querySelector('.rt-partners__group--partner');
    var supporterGroup = staging.querySelector('.rt-partners__group--supporter');
    if (!partnerGroup) return;

    // Insert RT.5 partners immediately before the existing Links column.
    var partnerColumn = document.createElement('div');
    partnerColumn.className = 'widget-column rtp-footer-partners';
    partnerColumn.appendChild(partnerGroup);
    widgets.insertBefore(partnerColumn, columns[3]);

    // Add only *new* supporters to the historic sponsor column. Existing
    // Regione FVG, Io Sono FVG, GO!2025 and municipality logos are untouched.
    if (supporterGroup) {
      var existing = columns[1];
      var heading = document.createElement('h2');
      heading.className = 'rtp-footer-supporter-title';
      heading.textContent = (supporterGroup.querySelector('.rt-partners__heading') || {}).textContent || 'Supporters';
      existing.insertBefore(heading, existing.firstChild);
      supporterGroup.classList.add('rtp-footer-supporter-extra');
      var redundantHeading = supporterGroup.querySelector('.rt-partners__heading');
      if (redundantHeading) redundantHeading.remove();
      existing.appendChild(supporterGroup);
    }
    widgets.classList.add('rtp-footer-combined');
    staging.remove();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', integrate);
  else integrate();
})();
