<?php
/**
 * Plugin Name: ReThinkable Partners Manager
 * Description: Manage festival partners and supporters edition by edition, with a compact site-wide footer and reusable credits.
 * Version: 1.2.1
 * Author: ReThinkable
 * License: GPL-2.0-or-later
 * Text Domain: rethinkable-partners
 */
if (!defined('ABSPATH')) { exit; }

const RTP_EDITION_OPTION = 'rtp_editions_v1';
const RTP_ACTIVE_OPTION = 'rtp_active_edition_v1';

function rtp_defaults() {
    $rows = [
        ['Centro Volontari Cooperazione allo Sviluppo - CVCS', 'partner', '01-cvcs.png', 'https://www.cvcs.it/'],
        ['proDES FVG', 'partner', '02-prodes-fvg.png', 'https://rete-ries.it/organizzatore/prodes-fvg/'],
        ['ACCRI', 'partner', '03-accri.png', 'https://www.accri.it/'],
        ["Comune di Gradisca d'Isonzo", 'partner', '04-comune-gradisca-isonzo.png', 'https://www.comune.gradiscadisonzo.go.it/'],
        ['Università degli Studi di Trieste', 'partner', '05-universita-trieste.png', 'https://www.units.it/'],
        ['Xcenter GO!2025 Nova Gorica Gorizia', 'partner', '06-xcenter-go2025.png', 'https://xcenter.si/en/'],
        ['Regione Autonoma Friuli Venezia Giulia', 'supporter', '07-regione-fvg.png', 'https://www.regione.fvg.it/'],
        ['Io Sono Friuli Venezia Giulia', 'supporter', '08-io-sono-fvg.png', 'https://www.iosonofvg.it/'],
        ['Cassa Rurale FVG', 'supporter', '09-cassa-rurale-fvg.png', 'https://www.cassaruralefvg.it/'],
    ];
    $out = [];
    foreach ($rows as $index => $row) {
        $out[] = ['name'=>$row[0], 'role'=>$row[1], 'logo'=>plugins_url('assets/'.$row[2], __FILE__), 'url'=>$row[3], 'sort'=>$index+1, 'enabled'=>1];
    }
    return ['2026-27'=>['title'=>'RT.5 / 2026-27', 'rows'=>$out]];
}
function rtp_activate() {
    if (get_option(RTP_EDITION_OPTION, null) === null) add_option(RTP_EDITION_OPTION, rtp_defaults(), '', false);
    if (get_option(RTP_ACTIVE_OPTION, null) === null) add_option(RTP_ACTIVE_OPTION, '2026-27', '', false);
}
register_activation_hook(__FILE__, 'rtp_activate');

/** Verified organisation URLs. proDES links to its partner profile on the RIES network. */
function rtp_verified_links() {
    return [
        'Centro Volontari Cooperazione allo Sviluppo - CVCS'=>'https://www.cvcs.it/',
        'proDES FVG'=>'https://rete-ries.it/organizzatore/prodes-fvg/',
        'ACCRI'=>'https://www.accri.it/',
        "Comune di Gradisca d'Isonzo"=>'https://www.comune.gradiscadisonzo.go.it/',
        'Università degli Studi di Trieste'=>'https://www.units.it/',
        'Xcenter GO!2025 Nova Gorica Gorizia'=>'https://xcenter.si/en/',
        'Regione Autonoma Friuli Venezia Giulia'=>'https://www.regione.fvg.it/',
        'Io Sono Friuli Venezia Giulia'=>'https://www.iosonofvg.it/',
        'Cassa Rurale FVG'=>'https://www.cassaruralefvg.it/',
    ];
}
/** Upgrade existing 1.0.0 installs without resetting logos, roles, order or later editions. */
function rtp_upgrade_existing() {
    if (get_option('rtp_schema_version', '1.0.0') === '1.1.0') return;
    $editions = rtp_editions();
    $changed = false;
    $links = rtp_verified_links();
    if (isset($editions['2026-27']['rows']) && is_array($editions['2026-27']['rows'])) {
        foreach ($editions['2026-27']['rows'] as &$row) {
            if (!is_array($row) || !empty($row['url'])) continue;
            $name = $row['name'] ?? '';
            if (isset($links[$name])) {
                $row['url'] = esc_url_raw($links[$name]);
                $changed = true;
            }
        }
        unset($row);
    }
    if ($changed) update_option(RTP_EDITION_OPTION, $editions, false);
    update_option('rtp_schema_version','1.1.0',false);
}
add_action('init', 'rtp_upgrade_existing', 30);

function rtp_editions() { $data=get_option(RTP_EDITION_OPTION, []); return is_array($data)?$data:[]; }
function rtp_active() { return sanitize_text_field((string)get_option(RTP_ACTIVE_OPTION,'2026-27')); }
function rtp_language() {
    if (function_exists('qtranxf_getLanguage')) {
        $lang = qtranxf_getLanguage();
        if (in_array($lang, ['it','sl','en'], true)) return $lang;
    }
    $locale = determine_locale();
    return strpos($locale,'sl')===0 ? 'sl' : (strpos($locale,'en')===0 ? 'en' : 'it');
}
function rtp_labels() {
    $all = [
        'it'=>['partner'=>'Partner e organizzazioni', 'supporter'=>'Con il sostegno di', 'lead'=>'Questa edizione è realizzata con', 'supported'=>'Con il sostegno di'],
        'sl'=>['partner'=>'Partnerji in organizacije', 'supporter'=>'S podporo', 'lead'=>'To izdajo pripravljajo', 'supported'=>'S podporo'],
        'en'=>['partner'=>'Partners and organisations', 'supporter'=>'With the support of', 'lead'=>'This edition is organised with', 'supported'=>'With the support of'],
    ];
    return $all[rtp_language()];
}
function rtp_rows($edition='current') {
    $editions=rtp_editions();
    $key=($edition==='current')?rtp_active():sanitize_key($edition);
    $rows=$editions[$key]['rows']??[];
    if (!is_array($rows)) return [];
    $rows=array_values(array_filter($rows, static function($r){ return is_array($r) && !empty($r['enabled']) && !empty($r['name']); }));
    usort($rows, static function($a,$b){return (int)($a['sort']??0) <=> (int)($b['sort']??0);});
    return $rows;
}
/** Link partner names wherever they appear in an edition's credits. */
function rtp_linked_names($group) {
    return array_map(static function($row) {
        $label=esc_html($row['name']);
        $url=trim((string)($row['url']??''));
        if ($url==='' || !in_array(wp_parse_url($url,PHP_URL_SCHEME), ['https','http'], true)) return $label;
        return '<a href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer">'.$label.'</a>';
    }, $group);
}
function rtp_shortcodes($atts=[]) {
    $atts=shortcode_atts(['edition'=>'current','format'=>'logos','context'=>'public'], $atts, 'rt_partners');
    $rows=rtp_rows($atts['edition']);
    if (!$rows) return '';
    $groups=['partner'=>[],'supporter'=>[]];
    foreach($rows as $row) $groups[($row['role']??'')==='supporter'?'supporter':'partner'][]=$row;
    // The existing footer widgets already show these historical supporter logos.
    // Only suppress duplicates in the footer. Edition credits still list everyone.
    if ($atts['format']==='logos' && $atts['context']==='footer') {
        $already_in_footer = ['Regione Autonoma Friuli Venezia Giulia', 'Io Sono Friuli Venezia Giulia'];
        $groups['supporter'] = array_values(array_filter($groups['supporter'], static function($row) use ($already_in_footer) {
            return !in_array(trim((string)($row['name']??'')), $already_in_footer, true);
        }));
    }
    $labels=rtp_labels();
    if ($atts['format']==='list') {
        $out='';
        foreach($groups as $role=>$group) {
            if (!$group) continue;
            $names=rtp_linked_names($group);
            $out.='<li><strong>'.esc_html($role==='partner'?$labels['lead']:$labels['supported']).':</strong> '.implode(', ', $names).'.</li>';
        }
        return $out;
    }
    if ($atts['format']==='sentence') {
        $out='<div class="rt-partner-credits">';
        foreach($groups as $role=>$group) {
            if (!$group) continue;
            $names=rtp_linked_names($group);
            $out.='<p><strong>'.esc_html($role==='partner'?$labels['lead']:$labels['supported']).':</strong> '.implode(', ', $names).'.</p>';
        }
        return $out.'</div>';
    }
    $out='<section class="rt-partners" aria-label="'.esc_attr($labels['partner']).'">';
    foreach ($groups as $role=>$group) {
        if (!$group) continue;
        $out.='<div class="rt-partners__group rt-partners__group--'.esc_attr($role).'">';
        $out.='<h2 class="rt-partners__heading">'.esc_html($labels[$role]).'</h2>';
        $out.='<div class="rt-partners__grid rt-partners__grid--'.esc_attr($role).'">';
        foreach($group as $row) {
            $label=esc_attr($row['name']); $logo=esc_url($row['logo']??'');
            $out.='<div class="rt-partners__item">';
            if (!empty($row['url'])) $out.='<a href="'.esc_url($row['url']).'" aria-label="'.$label.'" target="_blank" rel="noopener noreferrer">';
            if ($logo) $out.='<img src="'.$logo.'" alt="'.$label.'" loading="lazy" decoding="async">';
            else $out.='<span>'.esc_html($row['name']).'</span>';
            if (!empty($row['url'])) $out.='</a>';
            $out.='</div>';
        }
        $out.='</div></div>';
    }
    return $out.'</section>';
}
add_shortcode('rt_partners','rtp_shortcodes');

// Replace marked static credit text, leaving a readable fallback if the plugin is deactivated.
function rtp_dynamic_page_credits($content) {
    if (is_admin() || strpos($content, 'rtp-partner-credits:start')===false) return $content;
    return preg_replace_callback('/<!--\s*rtp-partner-credits:start(?::(list))?(?::([0-9]{4}-[0-9]{2}))?\s*-->.*?<!--\s*rtp-partner-credits:end\s*-->/s', static function($match) {
        return rtp_shortcodes(['edition'=>!empty($match[2])?$match[2]:'current', 'format'=>!empty($match[1])?'list':'sentence']);
    }, $content);
}
add_filter('the_content','rtp_dynamic_page_credits',12);

// Output within Inspiro's existing footer wrapper, before site-info; no theme files changed.
function rtp_footer($slug, $name='') {
    static $done=false;
    if ($done || is_admin() || $name!=='info' || $slug!=='template-parts/footer/site') return;
    $done=true;
    // Stage the edition logos invisibly. A tiny frontend script places them *inside*
    // the existing four-column footer widget row, without adding another section.
    // If the theme changes and its columns cannot be found, leave them hidden.
    echo '<div class="rtp-footer-staging" hidden>';
    echo rtp_shortcodes(['edition'=>'current','format'=>'logos','context'=>'footer']); // Escaped by renderer.
    echo '</div>';
}
add_action('get_template_part_template-parts/footer/site', 'rtp_footer', 10, 2);

function rtp_enqueue_public() {
    wp_enqueue_style('rtp-partners', plugins_url('assets/partners.css',__FILE__),[], '1.2.1');
    wp_enqueue_script('rtp-footer-integration', plugins_url('assets/footer-integration.js',__FILE__), [], '1.2.1', true);
}
add_action('wp_enqueue_scripts','rtp_enqueue_public', 20);

/** Partners & Supporters: standalone top-level WordPress admin screen. */
function rtp_admin_menu() {
    add_menu_page('ReThinkable Partners & Supporters', 'Partners & Supporters',
        'edit_pages', 'rtp-partners', 'rtp_admin_screen', 'dashicons-groups', 31);
    add_submenu_page('rtp-partners','Manage partners','Manage partners','edit_pages',
        'rtp-partners','rtp_admin_screen');
    add_submenu_page('rtp-partners','Guide & documentation','Documentation','edit_pages',
        'rt-help','rtp_help_screen');
}
add_action('admin_menu','rtp_admin_menu',80);
function rtp_plugin_active($slug) {
    if (function_exists('is_plugin_active')) return is_plugin_active($slug);
    return in_array($slug,(array)get_option('active_plugins',[]),true);
}
function rtp_help_screen() {
    if (!current_user_can('edit_pages')) return;
    echo '<div class="wrap"><h1>ReThinkable - Guide</h1>';
    echo '<p><a class="button button-primary" href="'.esc_url(admin_url('post.php?post=12521&action=edit')).'">Open internal handbook</a></p>';
    echo '<p>The public source and installation notes are kept in the website repository. The handbook is a WordPress draft: keep it unpublished.</p>';
    echo '<p><a href="https://github.com/cardopoli/enricopolicardo.com/tree/main/docs/rethinkable-wordpress-admin" target="_blank" rel="noopener noreferrer">Source, releases and dependencies (GitHub)</a></p>';
    echo '<p>Partner links, names and logos: <a href="'.esc_url(admin_url('admin.php?page=rtp-partners')).'">Partners Manager</a>. Create new edition first, then select Publish when approved.</p></div>';
}
function rtp_admin_assets($hook) {
    if (!isset($_GET['page']) || sanitize_key(wp_unslash($_GET['page']))!=='rtp-partners') return;
    wp_enqueue_media();
    wp_enqueue_script('rtp-partners-admin', plugins_url('assets/admin.js',__FILE__),['jquery'], '1.2.1', true);
    wp_enqueue_style('rtp-partners-admin',plugins_url('assets/admin.css',__FILE__),[], '1.2.1');
}
add_action('admin_enqueue_scripts','rtp_admin_assets');

function rtp_admin_save() {
    if (!current_user_can('edit_pages')) wp_die('Not authorised');
    check_admin_referer('rtp_save','rtp_nonce');
    $editions=rtp_editions();
    $active=rtp_active();
    $action=isset($_POST['rtp_action'])?sanitize_key(wp_unslash($_POST['rtp_action'])):'save';
    $edit_key=$active;
    if ($action==='copy') {
        $new=isset($_POST['rtp_new_key'])?sanitize_text_field(wp_unslash($_POST['rtp_new_key'])):'';
        if (!preg_match('/^20[0-9]{2}-[0-9]{2}$/',$new) || isset($editions[$new])) {
            wp_safe_redirect(add_query_arg(['page'=>'rtp-partners','error'=>'invalid'], admin_url('admin.php')));exit;
        }
        $title=isset($_POST['rtp_new_title'])?sanitize_text_field(wp_unslash($_POST['rtp_new_title'])):$new;
        $source=isset($_POST['rtp_source'])?sanitize_text_field(wp_unslash($_POST['rtp_source'])):$active;
        if (!isset($editions[$source])) $source=$active;
        $editions[$new]=['title'=>$title ?: $new, 'rows'=>$editions[$source]['rows']??[]];
        update_option(RTP_EDITION_OPTION,$editions,false);
        $edit_key=$new;
    } elseif ($action==='switch') {
        if (!current_user_can('manage_options')) wp_die('Only an administrator can publish an edition.');
        $chosen=isset($_POST['rtp_current'])?sanitize_text_field(wp_unslash($_POST['rtp_current'])):'';
        if (array_key_exists($chosen,$editions)) {
            update_option(RTP_ACTIVE_OPTION,$chosen,false);
            $edit_key=$chosen;
        }
    } else {
        $current=isset($_POST['rtp_edit'])?sanitize_text_field(wp_unslash($_POST['rtp_edit'])):$active;
        if (!array_key_exists($current,$editions)) $current=$active;
        $edit_key=$current;
        $raw=isset($_POST['partners']) && is_array($_POST['partners']) ? wp_unslash($_POST['partners']) : [];
        $clean=[];
        foreach(array_slice($raw,0,60) as $item) {
            if (!is_array($item)) continue;
            $name=isset($item['name'])?sanitize_text_field($item['name']):'';
            if ($name==='') continue;
            $logo=isset($item['logo'])?esc_url_raw($item['logo']):'';
            $url=isset($item['url'])?esc_url_raw($item['url']):'';
            $role=($item['role']??'partner')==='supporter'?'supporter':'partner';
            $sort=isset($item['sort'])?max(0,min(999,(int)$item['sort'])):count($clean)+1;
            $clean[]=['name'=>$name,'logo'=>$logo,'url'=>$url,'role'=>$role,'sort'=>$sort,'enabled'=>!empty($item['enabled'])?1:0];
        }
        $editions[$current]['rows']=$clean;
        update_option(RTP_EDITION_OPTION,$editions,false);
    }
    wp_safe_redirect(add_query_arg(['page'=>'rtp-partners','edit'=>$edit_key,'updated'=>'1'],admin_url('admin.php')));exit;
}
add_action('admin_post_rtp_save','rtp_admin_save');

function rtp_admin_screen() {
    if (!current_user_can('edit_pages')) return;
    $editions=rtp_editions(); $active=rtp_active();
    if (!isset($editions[$active])) {echo '<div class="wrap"><h1>Partner data unavailable</h1></div>';return;}
    $edit_key=isset($_GET['edit'])?sanitize_text_field(wp_unslash($_GET['edit'])):$active;
    if (!isset($editions[$edit_key])) $edit_key=$active;
    $rows=$editions[$edit_key]['rows']??[];
    ?>
    <div class="wrap rtp-admin">
      <h1>ReThinkable - Partners</h1>
      <p>The published edition is <strong><?php echo esc_html($editions[$active]['title']??$active); ?></strong>. Edit a draft edition below without affecting the live footer.</p>
      <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
        <input type="hidden" name="page" value="rtp-partners"><label><strong>Edit edition </strong>
        <select name="edit">
          <?php foreach($editions as $key=>$edition): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($key,$edit_key); ?>><?php echo esc_html($edition['title']??$key); ?></option><?php endforeach; ?>
        </select></label> <button class="button" type="submit">Open edition</button>
      </form>
      <?php if (!empty($_GET['updated'])) echo '<div class="notice notice-success is-dismissible"><p>Partners saved.</p></div>'; ?>
      <?php if (!empty($_GET['error'])) echo '<div class="notice notice-error"><p>Edition already exists or has an invalid identifier.</p></div>'; ?>
      <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" id="rtp-form">
        <input type="hidden" name="action" value="rtp_save"><input type="hidden" name="rtp_action" value="save"><input type="hidden" name="rtp_edit" value="<?php echo esc_attr($edit_key); ?>">
        <?php wp_nonce_field('rtp_save','rtp_nonce'); ?>
        <p><strong>Editing edition:</strong> <?php echo esc_html($editions[$edit_key]['title']??$edit_key); ?><?php if($edit_key!==$active) echo ' <em>(not published)</em>'; ?></p>
        <table class="widefat striped" id="rtp-table"><thead><tr><th style="width:50px">Order</th><th>Organisation</th><th>Group</th><th>Logo</th><th>Website</th><th>Show</th><th></th></tr></thead><tbody>
        <?php foreach($rows as $index=>$row): rtp_admin_row($index,$row); endforeach; ?>
        </tbody></table>
        <p><button type="button" class="button" id="rtp-add">Add organisation</button> <?php submit_button('Save partners','primary','submit',false); ?></p>
      </form>
      <?php if (current_user_can('manage_options')): ?><hr><h2>Publish an edition</h2>
      <p>When the new logos and credits are ready, publish that edition to update the footer. Other editions remain saved.</p>
      <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
        <input type="hidden" name="action" value="rtp_save"><input type="hidden" name="rtp_action" value="switch">
        <?php wp_nonce_field('rtp_save','rtp_nonce'); ?>
        <select name="rtp_current" aria-label="Edition to make current">
          <?php foreach($editions as $key=>$edition): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($key,$active); ?>><?php echo esc_html($edition['title']??$key); ?></option><?php endforeach; ?>
        </select>
        <?php submit_button('Publish selected edition','secondary','submit',false); ?>
      </form>
      <?php endif; ?><hr><h2>Next edition</h2>
      <p>Copy the edition you are editing, update its partners and publish it when ready. The current footer will not change during preparation.</p>
      <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
        <input type="hidden" name="action" value="rtp_save"><input type="hidden" name="rtp_action" value="copy"><input type="hidden" name="rtp_source" value="<?php echo esc_attr($edit_key); ?>">
        <?php wp_nonce_field('rtp_save','rtp_nonce'); ?>
        <p><label>Edition ID <input type="text" name="rtp_new_key" placeholder="2027-28" pattern="20[0-9]{2}-[0-9]{2}" required></label>
        <label>Display title <input type="text" name="rtp_new_title" placeholder="RT.6 / 2027-28" required></label>
        <?php submit_button('Copy to new edition','secondary','submit',false); ?></p>
      </form>
      <p class="description">Logo uploads: use the Media Library picker. Upload PNG/WebP/JPEG; SVG files require a separately vetted, secure upload workflow.</p>
      <p class="description">Footer: RT.5 partners are displayed alongside the original logos, in the original footer widget area. Regione FVG and Io Sono FVG are not duplicated.</p>
    </div>
    <?php
}
function rtp_admin_row($i,$row) {
    $name='partners['.$i.']';
    $nm=esc_attr($row['name']??''); $url=esc_attr($row['url']??''); $logo=esc_attr($row['logo']??'');
    $role=$row['role']??'partner';$sort=(int)($row['sort']??($i+1));$enabled=!empty($row['enabled']);
    echo '<tr class="rtp-row">';
    echo '<td><input type="number" class="small-text" min="0" max="999" name="'.$name.'[sort]" value="'.$sort.'"></td>';
    echo '<td><input class="regular-text" name="'.$name.'[name]" value="'.$nm.'" aria-label="Organisation name" required></td>';
    echo '<td><select name="'.$name.'[role]"><option value="partner" '.selected($role,'partner',false).'>Partner</option><option value="supporter" '.selected($role,'supporter',false).'>Supporter</option></select></td>';
    echo '<td><input name="'.$name.'[logo]" value="'.$logo.'" class="rtp-logo-url" aria-label="Logo image URL"><button class="button rtp-pick" type="button">Media</button></td>';
    echo '<td><input type="url" name="'.$name.'[url]" value="'.$url.'" placeholder="https://" aria-label="Website URL"></td>';
    echo '<td><input type="checkbox" name="'.$name.'[enabled]" value="1" '.checked($enabled,true,false).' aria-label="Visible"></td>';
    echo '<td><button class="button-link-delete rtp-remove" type="button">Remove</button></td></tr>';
}
