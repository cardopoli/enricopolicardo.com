# MCP client compatibility (beta 0.6.4)

**Universal protocol, not universal guaranteed client support.** Every AI assistant needs explicit support for remote MCP (or an intermediary adapter). Claude is the intended integration target; a verified end-to-end test is still required before describing it as certified.

| Client | Connection route | Known considerations | Status |
| --- | --- | --- | --- |
| Claude / Claude Desktop remote | Custom connector + **Register automatically** (OAuth DCR) | Add `claude.ai` to allowlist; Claude's published identity / CIMD is not implemented | Not yet end-to-end tested |
| Claude Code and other desktop MCP hosts | Remote Streamable HTTP with OAuth DCR or a compatible HTTP adapter | Desktop loopback callback may require opt-in and client-specific OAuth setup | Not yet tested |
| Cursor / VS Code / other MCP-compatible clients | Remote MCP endpoint with appropriate OAuth support | Client capabilities and callback domains vary; confirm from vendor docs | Not yet tested |
| AI services without MCP support | Not directly compatible | Would need an adapter | Not supported |

## WordPress installation

1. Back up WordPress and database, ideally verify restore on staging.
2. Install the ZIP under **Plugins > Add New > Upload Plugin**.
3. Set up **HTTPS** and open **Settings > Universal MCP Bridge**.
4. Enable connections. Keep write, maintenance and theme-code tools off until necessary.
5. Copy the **MCP server URL** shown on this settings screen. It resembles `https://example.org/wp-json/universal-mcp/v1/mcp`, but the precise value must be copied from the installation.
6. Add the **exact OAuth callback hostname** of your MCP client to the allowlist; defaults only apply to new installs. For Claude this is `claude.ai`.
7. In the client, configure a remote MCP server with its URL and OAuth DCR, then authenticate with a WordPress administrator and approve the consent screen.
8. Test read-only operations first. Keep write privileges off until approvals and rollback are tested.

## Security limitations

- New connections require a logged-in WordPress administrator and explicit consent; all MCP tools run with high privilege. Do not connect untrusted AI clients.
- Authorisation uses OAuth PKCE S256, bearer tokens and per-client redirect-host allowlists; it is **not** a WordPress security audit or firewall.
- There is no wildcard domain support; do not add broad or uncontrolled domains.
- Do not publish credentials, private database dumps, access tokens or live settings with source code.
- Before public release, commission an independent security review, automated tests and WordPress integration tests.

## Optional donation support

Source code is freely available under GPL-2.0-or-later. Donations are voluntary and do not determine whether users can access or exercise the licence rights. Paid setup, site maintenance, hosting, priority assistance or security audits may be offered separately.
