# Licence

Universal WordPress MCP Bridge is offered under GPL-2.0-or-later, as declared in the WordPress plugin header and readme.txt. The GNU GPL provides the recipients' rights to use, study, modify, and redistribute this source and derivative distributions, provided applicable licence requirements are respected.

The plugin's original contribution ownership should be verified before publishing. No third-party branding implies endorsement.
