# Security policy

This is **beta** software with access to privileged WordPress functions. Install on a staging site before production. The plugin has not undergone an independent security audit.

- Minimum operational rule: use HTTPS and backups, revoke unused OAuth clients, and restrict admin accounts and callback hosts.
- Sensitive write capabilities are off by default and some actions require a separate admin confirmation.
- Never expose real WordPress credentials, OAuth access/refresh tokens, database dumps, or backups in public issues.
- For vulnerabilities, contact the project maintainer privately rather than posting exploit details publicly. Add a dedicated disclosure email or GitHub private vulnerability reporting process before broad distribution.
