/* Universal MCP Bridge - progressive navigation enhancement v0.5
 * Native Inspiro drawer controls are preserved. No jQuery dependency.
 * Operates solely on the existing sidebar widget menu, never the header socials
 * or the qTranslate-XT language switcher.
 */
(function () {
  'use strict';

  function onReady(callback) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', callback, { once: true });
    } else {
      callback();
    }
  }

  onReady(function () {
    const drawer = document.getElementById('side-nav');
    if (!drawer || drawer.dataset.uwmcpNavigationReady === '1') return;
    const widgetMenu = drawer.querySelector('.widget_nav_menu ul.menu');
    if (!widgetMenu) return;

    drawer.dataset.uwmcpNavigationReady = '1';
    const lang = (document.documentElement.lang || 'en').toLowerCase();
    const words = lang.startsWith('it')
      ? { expand: 'Espandi', collapse: 'Comprimi' }
      : lang.startsWith('sl')
        ? { expand: 'Razširi', collapse: 'Strni' }
        : { expand: 'Expand', collapse: 'Collapse' };

    let ordinal = 0;
    const items = [];

    function directChild(element, selector) {
      for (const child of element.children) {
        if (child.matches(selector)) return child;
      }
      return null;
    }

    function buttonFor(li) {
      return directChild(li, 'button.rt-nav-disclosure');
    }

    function submenuFor(li) {
      return directChild(li, 'ul.sub-menu');
    }

    function setOpen(item, open) {
      const submenu = submenuFor(item);
      const button = buttonFor(item);
      if (!submenu || !button) return;
      if (!open && submenu.contains(document.activeElement)) button.focus();
      submenu.hidden = !open;
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
      button.setAttribute('aria-label', (open ? words.collapse : words.expand) + ': ' + button.dataset.label);
      item.classList.toggle('rt-nav-expanded', open);
    }

    function initTree(menu) {
      const siblings = Array.from(menu.children).filter(function (el) {
        return el.tagName === 'LI';
      });
      siblings.forEach(function (li) {
        if (li.classList.contains('qtranxs-lang-menu') || li.closest('.qtranxs-lang-menu')) return;
        const submenu = submenuFor(li);
        const anchor = directChild(li, 'a');
        if (!submenu || !anchor) return;

        // Initialise nested menus first. If JavaScript fails, server HTML remains readable.
        initTree(submenu);
        const label = anchor.textContent.trim().replace(/\s+/g, ' ') || 'Section';
        let id = submenu.id;
        if (!id || document.querySelectorAll('#' + CSS.escape(id)).length > 1) {
          id = 'uwmcp-submenu-' + (++ordinal);
          submenu.id = id;
        }
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'rt-nav-disclosure';
        button.setAttribute('aria-controls', id);
        button.dataset.label = label;
        button.setAttribute('aria-label', words.expand + ': ' + label);
        li.insertBefore(button, submenu);
        li.classList.add('rt-has-disclosure');
        items.push(li);

        const active = li.classList.contains('current-menu-ancestor') ||
          li.classList.contains('current-menu-parent') ||
          li.classList.contains('current-menu-item') ||
          Boolean(submenu.querySelector('.current-menu-item, .current_page_item, [aria-current="page"]'));
        setOpen(li, active);

        button.addEventListener('click', function (event) {
          event.preventDefault();
          event.stopPropagation();
          const expanding = button.getAttribute('aria-expanded') !== 'true';
          if (expanding) {
            siblings.forEach(function (sibling) {
              if (sibling !== li && buttonFor(sibling)) setOpen(sibling, false);
            });
          }
          setOpen(li, expanding);
        });
      });
    }

    initTree(widgetMenu);

    // Reflect Inspiro's existing open/close state, without adding a second
    // click handler (which would conflict with the theme's click/touchend logic).
    const openButton = document.querySelector('#site-navigation .navbar-toggle');
    const closeButton = drawer.querySelector('.side-nav__close-button .navbar-toggle');
    const navButtons = [openButton, closeButton].filter(Boolean);

    function syncDrawerState() {
      const expanded = document.body.classList.contains('side-nav-open');
      navButtons.forEach(function (button) {
        button.setAttribute('aria-controls', drawer.id);
        button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      });
      if (!expanded && drawer.contains(document.activeElement) && openButton) {
        openButton.focus({ preventScroll: true });
      }
    }
    syncDrawerState();
    if (navButtons.length && typeof MutationObserver !== 'undefined') {
      const observer = new MutationObserver(syncDrawerState);
      observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    }
  });
})();
