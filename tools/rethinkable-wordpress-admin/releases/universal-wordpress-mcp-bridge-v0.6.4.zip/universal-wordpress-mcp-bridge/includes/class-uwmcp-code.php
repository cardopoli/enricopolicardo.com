<?php
if (!defined('ABSPATH')) exit;

/**
 * Narrow, administrator-approved code patches to existing PHP/JS files in the
 * ACTIVE theme only. Never writes WordPress core, plugins, uploads or wp-config.
 * No shell commands, remote URLs, file creation, arbitrary paths or eval.
 */
class UWMCP_Code {
    const HISTORY = 'uwmcp_theme_code_history';
    const MAX_BYTES = 196608; // 192 KiB per existing file
    const MAX_LIST = 150;

    private static function settings_enabled() {
        return !empty(uwmcp_settings()['allow_code_edits']);
    }
    private static function is_admin() {
        return current_user_can('manage_options') && current_user_can('edit_themes');
    }
    private static function can_modify() {
        if (!self::settings_enabled()) return new WP_Error('code_disabled', 'Theme code editing is disabled in Universal MCP Bridge settings.');
        if (!self::is_admin()) return new WP_Error('forbidden', 'Administrator with edit_themes capability required.');
        if ((defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS))
            return new WP_Error('wordpress_disabled', 'WordPress has disabled file modifications. The bridge will respect this security setting.');
        if (function_exists('wp_is_file_mod_allowed') && !wp_is_file_mod_allowed('theme_editor'))
            return new WP_Error('wordpress_disabled', 'WordPress has denied theme file editing.');
        return true;
    }
    private static function can_read() {
        if (!self::settings_enabled()) return new WP_Error('code_disabled', 'Theme code access is disabled in Bridge settings.');
        if (!self::is_admin()) return new WP_Error('forbidden', 'Administrator with edit_themes capability required.');
        return true;
    }
    private static function root() {
        $directory = realpath(get_stylesheet_directory());
        if (!$directory || !is_dir($directory)) return new WP_Error('theme_missing', 'Active theme directory cannot be resolved.');
        return rtrim($directory, DIRECTORY_SEPARATOR);
    }
    private static function filename($relative) {
        if (!is_string($relative) || strlen($relative) > 220 ||
            !preg_match('~^(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*\.(?:php|js)$~D', $relative))
            return new WP_Error('bad_path', 'Use an existing relative .php or .js file path inside the active theme (no dot-directories or traversal).');
        if (strtolower(basename($relative)) === 'wp-config.php') return new WP_Error('protected_file', 'Configuration files are not accessible.');
        $root = self::root();
        if (is_wp_error($root)) return $root;
        $cursor = $root;
        foreach (explode('/', $relative) as $part) {
            $cursor .= DIRECTORY_SEPARATOR . $part;
            if (is_link($cursor)) return new WP_Error('symlink', 'Symbolic links cannot be read or edited.');
        }
        $absolute = realpath($cursor);
        if (!$absolute || strpos($absolute, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($absolute))
            return new WP_Error('not_found', 'The requested existing theme file was not found.');
        if (!is_readable($absolute)) return new WP_Error('unreadable', 'The theme file cannot be read.');
        $size = filesize($absolute);
        if ($size === false || $size > self::MAX_BYTES) return new WP_Error('too_large', 'Only existing theme code files up to 192 KiB are supported.');
        return $absolute;
    }
    private static function contents($absolute) {
        $contents = file_get_contents($absolute);
        return is_string($contents) ? $contents : new WP_Error('read_failed', 'The theme file could not be read.');
    }
    private static function path_relative($absolute) {
        $root = self::root();
        if (is_wp_error($root)) return '';
        return ltrim(substr($absolute, strlen($root)), DIRECTORY_SEPARATOR);
    }
    public static function list_files() {
        $access = self::can_read();
        if (is_wp_error($access)) return $access;
        $root = self::root();
        if (is_wp_error($root)) return $root;
        $files = array();
        $visited = 0;
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveCallbackFilterIterator(
                    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
                    function ($item) {
                        if ($item->isLink()) return false;
                        if ($item->isDir() && in_array($item->getFilename(), array('node_modules', 'vendor', '.git', '.svn'), true)) return false;
                        return true;
                    }
                ), RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($it as $entry) {
                if (++$visited > 4000 || count($files) >= self::MAX_LIST) break;
                if (!$entry->isFile()) continue;
                $path = self::path_relative($entry->getPathname());
                if (is_wp_error(self::filename($path))) continue;
                $files[] = array('path'=>$path, 'bytes'=>$entry->getSize());
            }
        } catch (Throwable $e) {
            return new WP_Error('listing_failed', 'Active theme source could not be enumerated.');
        }
        usort($files, function($a,$b){ return strcmp($a['path'],$b['path']); });
        return array('theme'=>get_stylesheet(), 'scope'=>'active_theme_only', 'files'=>$files,
            'truncated'=>($visited > 4000 || count($files) >= self::MAX_LIST),
            'note'=>'Read-only listing. No plugin, WordPress core or upload files are included.');
    }
    public static function read_file($args) {
        $access = self::can_read();
        if (is_wp_error($access)) return $access;
        $path = (string)($args['path']??'');
        $file = self::filename($path);
        if (is_wp_error($file)) return $file;
        $contents = self::contents($file);
        if (is_wp_error($contents)) return $contents;
        $lines = explode("\n", $contents);
        $start = max(1, min(count($lines), (int)($args['start_line']??1)));
        $max = max(1, min(120, (int)($args['max_lines']??80)));
        $window = array();
        $total_bytes = 0;
        for ($i=$start-1; $i<min(count($lines),$start-1+$max); $i++) {
            $line = rtrim($lines[$i], "\r");
            if ($total_bytes + strlen($line) > 26000) break;
            $window[] = array('number'=>$i+1, 'text'=>$line);
            $total_bytes += strlen($line);
        }
        return array('path'=>$path,'sha256'=>hash('sha256',$contents),'bytes'=>strlen($contents),
            'total_lines'=>count($lines),'lines'=>$window,
            'next_start_line'=>($start-1+count($window)<count($lines))?($start+count($window)):null,
            'note'=>'Source is read-only. For a patch, supply this sha256 and an exact uniquely occurring old_text.');
    }
    private static function check_source($path, $contents) {
        if (!is_string($contents) || strlen($contents) > self::MAX_BYTES || strpos($contents,"\0")!==false)
            return new WP_Error('bad_source', 'The updated source must be text, at most 192 KiB, without NUL bytes.');
        if (strtolower(substr($path, -4)) === '.php') {
            if (!preg_match('/<\?(?:php|=)/i', $contents)) return new WP_Error('php_tag', 'A PHP theme file must contain a PHP opening tag.');
            try { token_get_all($contents, TOKEN_PARSE); }
            catch (ParseError $e) { return new WP_Error('php_syntax', 'PHP parser rejected this edit: ' . $e->getMessage()); }
        } elseif (preg_match('/<\?(?:php|=)/i', $contents)) {
            return new WP_Error('php_in_js', 'PHP fragments are not permitted in JavaScript files.');
        }
        return true;
    }
    private static function history() {
        $rows=get_option(self::HISTORY,array());
        return is_array($rows)?$rows:array();
    }
    public static function list_revisions() {
        $access=self::can_read();
        if (is_wp_error($access)) return $access;
        $out=array();
        foreach(self::history() as $entry) {
            $out[]=array('revision_id'=>$entry['revision_id'],'path'=>$entry['path'],
                'saved_at'=>$entry['time'],'previous_sha256'=>$entry['sha256'],
                'bytes'=>strlen($entry['contents']));
        }
        return array('revisions'=>$out, 'note'=>'Previous file versions are stored in a protected WordPress option, not web-accessible uploads. The five most recent versions are retained.');
    }
    public static function request_patch($args) {
        $access=self::can_modify();
        if (is_wp_error($access)) return $access;
        $path=(string)($args['path']??'');
        $file=self::filename($path);
        if (is_wp_error($file)) return $file;
        if (!is_writable($file) || !is_writable(dirname($file))) return new WP_Error('not_writable', 'The existing file and its directory must be writable for a safe atomic replacement.');
        $before=self::contents($file);
        if (is_wp_error($before)) return $before;
        $expected=(string)($args['expected_sha256']??'');
        if (!preg_match('/^[a-f0-9]{64}$/D',$expected) || !hash_equals(hash('sha256',$before),$expected))
            return new WP_Error('stale_file', 'Theme file changed. Re-read it to obtain the current sha256.');
        $old=$args['old_text']??null;$new=$args['new_text']??null;
        if (!is_string($old) || $old==='' || strlen($old)>16000 || !is_string($new) || strlen($new)>24000)
            return new WP_Error('invalid_patch', 'An exact, nonempty old_text (<=16 KB) and new_text (<=24 KB) are required.');
        if (substr_count($before,$old)!==1) return new WP_Error('ambiguous_patch', 'The exact old_text must occur once in the file.');
        $after=str_replace($old,$new,$before);
        if ($after===$before) return new WP_Error('no_change', 'The replacement does not change the file.');
        $syntax=self::check_source($path,$after);
        if (is_wp_error($syntax)) return $syntax;
        return self::prepare($path,$before,$after,'patch',$old,$new);
    }
    public static function request_rollback($args) {
        $access=self::can_modify();
        if (is_wp_error($access)) return $access;
        $revision=(string)($args['revision_id']??'');
        if (!preg_match('/^[a-f0-9]{20}$/D',$revision)) return new WP_Error('invalid_revision','Use a revision ID from list_theme_code_revisions.');
        foreach(self::history() as $entry) {
            if ($entry['revision_id']!==$revision) continue;
            $file=self::filename($entry['path']);
            if (is_wp_error($file)) return $file;
            if (!is_writable($file) || !is_writable(dirname($file))) return new WP_Error('not_writable','File is not writable.');
            $before=self::contents($file);
            if (is_wp_error($before)) return $before;
            $after=$entry['contents'];
            if ($before===$after) return new WP_Error('no_change','That revision is identical to the live file.');
            $syntax=self::check_source($entry['path'],$after);
            if (is_wp_error($syntax)) return $syntax;
            return self::prepare($entry['path'],$before,$after,'rollback','','');
        }
        return new WP_Error('missing_revision','Revision is no longer available.');
    }
    private static function prepare($path,$before,$after,$kind,$old,$new) {
        $token=rtrim(strtr(base64_encode(random_bytes(24)),'+/','-_'),'=');
        $key='uwmcp_code_'.hash('sha256',$token);
        set_transient($key,array('user_id'=>get_current_user_id(),'path'=>$path,
            'before_sha'=>hash('sha256',$before),'after'=>$after,
            'after_sha'=>hash('sha256',$after),'kind'=>$kind,
            'old_text'=>$old,'new_text'=>$new,'before_size'=>strlen($before)),600);
        return array('applied'=>false,'action'=>$kind==='patch'?'patch_existing_theme_code':'restore_theme_code_revision',
            'path'=>$path,'before_sha256'=>hash('sha256',$before),'after_sha256'=>hash('sha256',$after),
            'before_bytes'=>strlen($before),'after_bytes'=>strlen($after),'php_syntax_checked'=>substr($path,-4)==='.php',
            'js_syntax_checked'=>false,
            'review_url'=>add_query_arg(array('action'=>'uwmcp_confirm_theme_code','approval'=>$token),admin_url('admin-post.php')),
            'expires_in'=>600,'note'=>'No file was changed. The same WordPress administrator must approve, and a pre-edit rollback revision will be saved. JavaScript syntax is not parsed by this plugin.');
    }
    public static function confirm() {
        $token=isset($_REQUEST['approval'])&&is_string($_REQUEST['approval'])?wp_unslash($_REQUEST['approval']):'';
        if (!preg_match('/^[A-Za-z0-9_-]{20,64}$/D',$token)) wp_die('Invalid code editing approval token.');
        $destination=add_query_arg(array('action'=>'uwmcp_confirm_theme_code','approval'=>$token),admin_url('admin-post.php'));
        if (!is_user_logged_in()) { wp_safe_redirect(wp_login_url($destination));exit; }
        $key='uwmcp_code_'.hash('sha256',$token);
        $pending=get_transient($key);
        if (!is_array($pending)) wp_die('Code editing request expired or already used.');
        $access=self::can_modify();
        if (is_wp_error($access) || get_current_user_id()!==(int)$pending['user_id']) wp_die('You cannot approve this request. Use the same authorised WordPress administrator.');
        $file=self::filename($pending['path']);
        if (is_wp_error($file)) wp_die('Active theme file is no longer available.');
        $before=self::contents($file);
        if (is_wp_error($before) || !hash_equals(hash('sha256',$before),(string)$pending['before_sha']))
            wp_die('The live file changed after the request. No changes were applied.');
        if (!hash_equals(hash('sha256',$pending['after']),(string)$pending['after_sha']) ||
            is_wp_error(self::check_source($pending['path'],$pending['after'])))
            wp_die('The proposed code failed its integrity or syntax check.');
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            check_admin_referer('uwmcp_theme_code_'.$token);
            if (empty($_POST['uwmcp_confirm']) || empty($_POST['uwmcp_backup_confirmed'])) wp_die('Code change not approved. Confirm you have a restorable site backup.');
            if (!is_writable($file) || !is_writable(dirname($file))) wp_die('The file or directory is not writable.');
            $mode=fileperms($file);
            $temp=tempnam(dirname($file), '.uwmcp-code-');
            if ($temp===false) wp_die('Failed to allocate a safe temporary file.');
            $written=file_put_contents($temp,$pending['after'],LOCK_EX);
            if ($written===false || $written!==strlen($pending['after'])) {
                @unlink($temp); wp_die('Unable to stage the updated file. No changes applied.');
            }
            if ($mode!==false) @chmod($temp,($mode & 0777));
            // Check the actual staged bytes before replacing the original.
            if (!hash_equals(hash('sha256',$pending['after']),hash_file('sha256',$temp))) {
                @unlink($temp);wp_die('Staged file integrity check failed.');
            }
            // Save the previous complete source in WordPress DB for an approved rollback.
            $history=self::history();
            $revision_id=bin2hex(random_bytes(10));
            array_unshift($history,array('revision_id'=>$revision_id,
                'time'=>gmdate('c'),'user_id'=>get_current_user_id(),
                'path'=>$pending['path'],'sha256'=>hash('sha256',$before),'contents'=>$before));
            update_option(self::HISTORY,array_slice($history,0,5),false);
            $saved=self::history();
            if (!$saved || !isset($saved[0]['revision_id']) || $saved[0]['revision_id']!==$revision_id) {
                @unlink($temp);wp_die('Could not verify rollback history. No changes applied.');
            }
            // Recheck just before rename; request must never overwrite a different edit.
            clearstatcache(true,$file);
            if (!hash_equals(hash('sha256',$before),(string)$pending['before_sha']) ||
                !hash_equals(hash_file('sha256',$file),(string)$pending['before_sha'])) {
                @unlink($temp);wp_die('Original file changed before save. No changes applied.');
            }
            if (!@rename($temp,$file)) { @unlink($temp);wp_die('Atomic file replacement failed. The original is unchanged.'); }
            if (function_exists('opcache_invalidate')) @opcache_invalidate($file,true);
            delete_transient($key);
            uwmcp_log('theme_code_approved','ok',get_current_user_id());
            wp_safe_redirect(admin_url('options-general.php?page=universal-mcp-bridge&uwmcp_code=completed'));exit;
        }
        nocache_headers();
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Review code change</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:900px;margin:32px auto;padding:20px}button{padding:12px 20px;background:#17202b;color:#fff;border:0;border-radius:5px}pre{background:#f6f6f6;padding:16px;white-space:pre-wrap;overflow:auto;max-height:260px;font-size:12px}</style></head><body>';
        echo '<h1>Approve active-theme code change?</h1><p><strong>File:</strong> <code>'.esc_html($pending['path']).'</code></p>';
        echo '<p><strong>Operation:</strong> '.esc_html($pending['kind']).'. Before: '.intval($pending['before_size']).' bytes; after: '.intval(strlen($pending['after'])).' bytes.</p>';
        echo '<p><strong>Security:</strong> PHP syntax was parsed locally where applicable. JavaScript syntax and runtime behaviour have NOT been tested. Editing theme code can make a site unavailable even when syntax is valid.</p>';
        if ($pending['kind']==='patch') {
            echo '<h2>Replace exact source</h2><pre>'.esc_html($pending['old_text']).'</pre><h2>With</h2><pre>'.esc_html($pending['new_text']).'</pre>';
        } else echo '<p>This restores a previous code revision for this file.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uwmcp_confirm_theme_code"><input type="hidden" name="approval" value="'.esc_attr($token).'">';
        wp_nonce_field('uwmcp_theme_code_'.$token);
        echo '<p><label><input type="checkbox" name="uwmcp_backup_confirmed" value="1" required> I have independently verified a restorable backup and can recover the site via hosting access if this edit causes a fatal error.</label></p>';
        echo '<button type="submit" name="uwmcp_confirm" value="1">Approve code change</button></form>';
        echo '<p><a href="'.esc_url(admin_url('options-general.php?page=universal-mcp-bridge')).'">Cancel</a></p></body></html>';exit;
    }
}
