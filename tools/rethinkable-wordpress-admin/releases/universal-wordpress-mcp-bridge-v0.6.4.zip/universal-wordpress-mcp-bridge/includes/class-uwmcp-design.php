<?php
if (!defined('ABSPATH')) exit;

/** Administrator-approved, version-checked stylesheet overrides. Never writes to theme files. */
class UWMCP_Design {
    const OPTION = 'uwmcp_design_css';
    const HISTORY = 'uwmcp_design_css_history';
    const LIMIT = 30000;

    public static function current_css() {
        $value = get_option(self::OPTION, '');
        return is_string($value) ? $value : '';
    }
    public static function revision_hash($css = null) {
        return hash('sha256', $css === null ? self::current_css() : (string)$css);
    }
    public static function inspect() {
        if (!current_user_can('manage_options')) return new WP_Error('forbidden', 'Administrator permission required.');
        $css = self::current_css();
        return array('css'=>$css, 'bytes'=>strlen($css), 'sha256'=>self::revision_hash($css), 'active'=>($css !== ''), 'history_revisions'=>count((array)get_option(self::HISTORY, array())), 'note'=>'WordPress-managed overrides. No theme files or plugin CSS are changed.');
    }
    public static function validate_css($css) {
        if (!is_string($css) || strlen($css) > self::LIMIT) return new WP_Error('css_size', 'Stylesheet must be text and no larger than 30000 bytes.');
        if (strpos($css, '<') !== false || strpos($css, chr(0)) !== false || preg_match('/@import\b|@charset\b|expression\s*\(|(?:^|[;{])\s*behavior\s*:|url\s*\(|-moz-binding|\\[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/i', $css))
            return new WP_Error('css_unsafe', 'CSS may not contain HTML, control characters, imports, URLs or browser scripting constructs.');
        if (substr_count($css, '{') !== substr_count($css, '}') || substr_count($css, '/*') !== substr_count($css, '*/'))
            return new WP_Error('css_unbalanced', 'CSS rules or comments appear unbalanced.');
        return true;
    }
    public static function request($args) {
        if (empty(uwmcp_settings()['allow_maintenance'])) return new WP_Error('disabled', 'Controlled maintenance must be enabled in WordPress.');
        if (!current_user_can('manage_options') || !current_user_can('edit_theme_options')) return new WP_Error('forbidden', 'Administrator theme editing permission required.');
        $css = $args['css'] ?? null;
        $valid = self::validate_css($css);
        if (is_wp_error($valid)) return $valid;
        $expected = (string)($args['expected_sha256'] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/D', $expected) || !hash_equals(self::revision_hash(), $expected))
            return new WP_Error('changed', 'The managed stylesheet has changed. Inspect its current content and SHA-256 before preparing a new review.');
        if (hash_equals(self::revision_hash(), self::revision_hash($css))) return new WP_Error('unchanged', 'The stylesheet is unchanged.');
        $token = rtrim(strtr(base64_encode(random_bytes(24)), '+/', '-_'), '=');
        $key = 'uwmcp_design_' . hash('sha256', $token);
        set_transient($key, array('user_id'=>get_current_user_id(), 'css'=>$css, 'before_hash'=>$expected, 'after_hash'=>self::revision_hash($css), 'before_bytes'=>strlen(self::current_css()), 'after_bytes'=>strlen($css)), 600);
        return array('applied'=>false, 'action'=>'replace_managed_design_css', 'before_sha256'=>$expected, 'after_sha256'=>self::revision_hash($css), 'before_bytes'=>strlen(self::current_css()), 'after_bytes'=>strlen($css), 'review_url'=>add_query_arg(array('action'=>'uwmcp_confirm_design_css','approval'=>$token),admin_url('admin-post.php')), 'expires_in'=>600, 'note'=>'No change is applied until the same administrator reviews and confirms in WordPress.');
    }
    public static function output_css() {
        $css = self::current_css();
        if ($css === '') return;
        // validate again in case WordPress options have been altered outside this plugin.
        if (is_wp_error(self::validate_css($css))) return;
        echo "\n<style id=\"uwmcp-managed-design-css\">\n" . $css . "\n</style>\n";
    }
    public static function confirm() {
        if (empty(uwmcp_settings()['allow_maintenance'])) wp_die('Maintenance has been disabled.');
        $token = isset($_REQUEST['approval']) && is_string($_REQUEST['approval']) ? wp_unslash($_REQUEST['approval']) : '';
        if (!preg_match('/^[A-Za-z0-9_-]{20,64}$/D', $token)) wp_die('Invalid approval token.');
        $destination = add_query_arg(array('action'=>'uwmcp_confirm_design_css','approval'=>$token), admin_url('admin-post.php'));
        if (!is_user_logged_in()) { wp_safe_redirect(wp_login_url($destination)); exit; }
        $key = 'uwmcp_design_' . hash('sha256', $token);
        $pending = get_transient($key);
        if (!is_array($pending)) wp_die('This approval has expired or was already used.');
        if (!current_user_can('manage_options') || !current_user_can('edit_theme_options') || get_current_user_id() !== (int)$pending['user_id']) wp_die('This approval belongs to another administrator.');
        if (!hash_equals(self::revision_hash(), (string)$pending['before_hash'])) wp_die('The live CSS changed after the request was prepared. Request a new review.');
        $valid = self::validate_css($pending['css']);
        if (is_wp_error($valid)) wp_die('The proposed CSS failed safety validation.');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            check_admin_referer('uwmcp_design_css_'.$token);
            if (empty($_POST['uwmcp_confirm'])) wp_die('Cancelled.');
            delete_transient($key);
            $history = get_option(self::HISTORY, array());
            if (!is_array($history)) $history = array();
            array_unshift($history, array('time'=>gmdate('c'), 'by'=>get_current_user_id(), 'sha256'=>self::revision_hash(), 'css'=>self::current_css()));
            update_option(self::HISTORY, array_slice($history, 0, 5), false);
            update_option(self::OPTION, (string)$pending['css'], false);
            uwmcp_log('design_css_approved', 'ok', get_current_user_id());
            wp_safe_redirect(admin_url('options-general.php?page=universal-mcp-bridge&uwmcp_design=completed')); exit;
        }
        nocache_headers();
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Approve stylesheet</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:780px;margin:32px auto;padding:20px}button{padding:12px 20px;background:#17202b;color:white;border:0;border-radius:5px}pre{white-space:pre-wrap;word-break:break-word;max-height:48vh;overflow:auto;background:#f6f6f6;padding:16px;font-size:12px}</style></head><body><h1>Review website design CSS</h1>';
        echo '<p>The change affects the entire public site, including all languages. It does not modify the theme, content or WordPress menus. You can reverse it by requesting the previous CSS.</p>';
        echo '<p>Previous size: '.intval($pending['before_bytes']).' bytes. New size: '.intval($pending['after_bytes']).' bytes.</p><h2>Proposed stylesheet</h2><pre>'.esc_html($pending['css']).'</pre>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uwmcp_confirm_design_css"><input type="hidden" name="approval" value="'.esc_attr($token).'">';
        wp_nonce_field('uwmcp_design_css_'.$token);
        echo '<button type="submit" name="uwmcp_confirm" value="1">Approve CSS change</button></form><p><a href="'.esc_url(admin_url('options-general.php?page=universal-mcp-bridge')).'">Cancel</a></p></body></html>'; exit;
    }
}
