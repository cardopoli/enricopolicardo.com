<?php
if (!defined('ABSPATH')) exit;

/** Read-only, bounded database and backup checks. Never returns backup credentials or row contents. */
class UWMCP_Diagnostics {
    const MAX_EXACT_MB = 256;

    private static function table_name($table) {
        global $wpdb;
        $table = (string)$table;
        $prefix = (string)$wpdb->prefix;
        if (strlen($table) < strlen($prefix) + 2 || strlen($table) > 150 ||
            !preg_match('/^[A-Za-z0-9_]+$/D', $table) || strpos($table, $prefix) !== 0) {
            return new WP_Error('bad_table', 'Specify a valid table belonging to this WordPress site, exactly as listed in site_diagnostics.');
        }
        return $table;
    }

    public static function table_status($table) {
        global $wpdb;
        $table = self::table_name($table);
        if (is_wp_error($table)) return $table;
        // The validated table name is an identifier; LIKE receives an escaped, exact literal.
        $rows = $wpdb->get_results($wpdb->prepare('SHOW TABLE STATUS LIKE %s', $wpdb->esc_like($table)), ARRAY_A);
        if (!is_array($rows)) return new WP_Error('database_unavailable', 'Could not read the database table metadata.');
        foreach ($rows as $row) {
            if (isset($row['Name']) && $row['Name'] === $table) return $row;
        }
        return new WP_Error('table_missing', 'No matching database table exists.');
    }

    public static function inspect_table($args) {
        global $wpdb;
        if (!current_user_can('manage_options')) return new WP_Error('forbidden', 'Administrator access required.');
        $table = self::table_name($args['table'] ?? '');
        if (is_wp_error($table)) return $table;
        $s = self::table_status($table);
        if (is_wp_error($s)) return $s;
        $bytes = max(0, (int)($s['Data_length'] ?? 0)) + max(0, (int)($s['Index_length'] ?? 0));
        $result = array(
            'table' => $table,
            'storage_engine' => (string)($s['Engine'] ?? 'unknown'),
            'estimated_rows' => isset($s['Rows']) ? (int)$s['Rows'] : null,
            'estimated_row_count_is_exact' => false,
            'data_mb' => round(max(0, (int)($s['Data_length'] ?? 0)) / 1048576, 2),
            'index_mb' => round(max(0, (int)($s['Index_length'] ?? 0)) / 1048576, 2),
            'allocated_mb' => round($bytes / 1048576, 2),
            'reported_free_mb' => round(max(0, (int)($s['Data_free'] ?? 0)) / 1048576, 2),
            'last_table_rebuild' => (string)($s['Create_time'] ?? ''),
            'source' => 'SHOW TABLE STATUS; InnoDB rows are estimates and allocated size does not equal useful row data.',
        );
        if (empty($args['exact_count'])) {
            $result['exact_count'] = null;
            $result['exact_count_note'] = 'Set exact_count=true to run one bounded COUNT(*) check (tables over 256 MB excluded).';
            return $result;
        }
        if ($bytes > self::MAX_EXACT_MB * 1048576) {
            $result['exact_count'] = null;
            $result['exact_count_note'] = 'Exact count refused: table exceeds the 256 MB safety threshold.';
            return $result;
        }
        // Read-only count on ONE validated, site-owned table; never returns record contents.
        $count = $wpdb->get_var('SELECT COUNT(*) FROM `' . $table . '`');
        if ($count === null) return new WP_Error('count_failed', 'Exact row count could not be read.');
        $result['exact_count'] = (int)$count;
        $result['exact_count_note'] = 'Exact SELECT COUNT(*) at query time; does not alter the table.';
        if ($result['estimated_rows'] !== null && $result['exact_count'] > 0) {
            $result['estimate_to_exact_ratio'] = round($result['estimated_rows'] / $result['exact_count'], 2);
            $result['statistics_may_be_stale'] = abs($result['estimated_rows'] - $result['exact_count']) > max(100, $result['exact_count'] * 0.25);
        }
        if ($table === $wpdb->prefix . 'irrp_redirection_logs') {
            $cutoff = time() - 30 * DAY_IN_SECONDS;
            $old = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM `' . $table . '` WHERE `request_timestamp` < %d', $cutoff));
            $result['request_logs_over_30_days'] = $old === null ? null : (int)$old;
        }
        return $result;
    }

    public static function backup_health() {
        if (!current_user_can('manage_options')) return new WP_Error('forbidden', 'Administrator access required.');
        $installed = defined('UPDRAFTPLUS_VERSION') || (bool)get_option('updraft_version', false) || (bool)get_option('updraft_interval', false);
        $remote = get_option('updraft_service', '');
        // Never return any Dropbox/Google Drive tokens or other UpdraftPlus connection options.
        $dest = is_array($remote) ? array_values(array_filter(array_map('sanitize_key', array_filter($remote, 'is_string')))) : array_values(array_filter(array_map('sanitize_key', preg_split('/[,\s]+/', (string)$remote))));
        $history = get_option('updraft_backup_history', array());
        $latest = null;
        $record_count = 0;
        if (is_array($history)) {
            $record_count = count($history);
            foreach (array_keys($history) as $key) {
                if ((is_int($key) || ctype_digit((string)$key)) && (int)$key > 0 && (int)$key < time() + DAY_IN_SECONDS) {
                    $latest = max((int)$key, (int)$latest);
                }
            }
        }
        $file_schedule = (string)get_option('updraft_interval', 'manual');
        $db_schedule = (string)get_option('updraft_interval_database', 'manual');
        $next_files = function_exists('wp_next_scheduled') ? wp_next_scheduled('updraft_backup') : false;
        $next_db = function_exists('wp_next_scheduled') ? wp_next_scheduled('updraft_backup_database') : false;
        return array(
            'updraftplus_detected' => $installed,
            'files_schedule' => $file_schedule,
            'database_schedule' => $db_schedule,
            'uploads_included' => (bool)get_option('updraft_include_uploads', false),
            'plugins_included' => (bool)get_option('updraft_include_plugins', false),
            'themes_included' => (bool)get_option('updraft_include_themes', false),
            'other_files_included' => (bool)get_option('updraft_include_others', false),
            'remote_destination_configured' => count($dest) > 0,
            'remote_destination_types' => $dest,
            'next_file_backup_gmt' => $next_files ? gmdate('c', $next_files) : null,
            'next_database_backup_gmt' => $next_db ? gmdate('c', $next_db) : null,
            'backup_history_records' => $record_count,
            'latest_recorded_backup_gmt' => $latest ? gmdate('c', $latest) : null,
            'verification_note' => 'Configuration and history only. This does NOT confirm that an off-site backup completed or that restoration works. Inspect UpdraftPlus logs and test a restore.',
            'warning' => count($dest) ? null : 'No remote backup destination configured in UpdraftPlus. Backups may remain on the same server.',
        );
    }
}
