<?php
if (!defined('ABSPATH')) exit;

/**
 * Deliberately limited maintenance operations. A tool call only prepares a request.
 * The same WordPress administrator must approve the exact action in wp-admin.
 * No arbitrary SQL, shell, filesystem editing or permanent post deletion.
 */
class UWMCP_Maintenance {
    const TTL = 600;
    const LOG_BATCH = 25000;
    const MAX_CRON_EVENTS = 25;

    private static function admin() {
        return current_user_can('manage_options');
    }

    private static function pending($type, $data, $summary, $warning) {
        if (!self::admin()) return new WP_Error('forbidden', 'WordPress administrator access required.');
        $token = rtrim(strtr(base64_encode(random_bytes(24)), '+/', '-_'), '=');
        $key = 'uwmcp_maint_' . hash('sha256', $token);
        $request = array('type' => $type, 'data' => $data, 'summary' => $summary,
            'warning' => $warning, 'user_id' => get_current_user_id());
        set_transient($key, $request, self::TTL);
        uwmcp_log('maintenance_requested', 'review', get_current_user_id());
        return array('executed' => false, 'action' => $type, 'summary' => $summary,
            'review_url' => add_query_arg(array('action' => 'uwmcp_confirm_maintenance', 'approval' => $token), admin_url('admin-post.php')),
            'expires_in' => self::TTL,
            'instruction' => 'Open the review link as the authorising WordPress administrator. This tool call does not perform the operation.');
    }

    public static function request_trash_content($args) {
        if (!self::admin()) return new WP_Error('forbidden', 'Administrator access required.');
        $id = absint($args['id'] ?? 0);
        $post = get_post($id);
        if (!$post || !in_array($post->post_type, array('post', 'page'), true))
            return new WP_Error('bad_post', 'Only ordinary WordPress posts and pages can be moved to Trash.');
        if (!current_user_can('delete_post', $id)) return new WP_Error('forbidden', 'You cannot trash this item.');
        if (in_array($post->post_status, array('trash', 'auto-draft', 'inherit'), true))
            return new WP_Error('bad_status', 'This item cannot be moved to Trash.');
        if (defined('EMPTY_TRASH_DAYS') && (int) EMPTY_TRASH_DAYS === 0)
            return new WP_Error('trash_disabled', 'WordPress Trash is disabled. Refusing an operation that might delete permanently.');
        if (in_array($id, array((int)get_option('page_on_front'), (int)get_option('page_for_posts')), true))
            return new WP_Error('special_page', 'This is the configured homepage or posts index. Change the site settings manually first.');
        $data = array('id' => $id, 'status' => $post->post_status, 'post_type' => $post->post_type,
            'modified_gmt' => $post->post_modified_gmt, 'content_hash' => hash('sha256', $post->post_content),
            'title_hash' => hash('sha256', $post->post_title));
        return self::pending('trash_content', $data,
            sprintf('Move %s #%d (%s) to WordPress Trash', $post->post_type, $id, wp_strip_all_tags($post->post_title)),
            'Moving published content to Trash removes it from the public website. It can usually be restored from the WordPress Trash. Check menus, translations and links.');
    }

    private static function cron_snapshot($hook) {
        $cron = function_exists('_get_cron_array') ? _get_cron_array() : array();
        $events = array();
        foreach ((array)$cron as $timestamp => $hooks) {
            if (!isset($hooks[$hook]) || !is_array($hooks[$hook])) continue;
            foreach ($hooks[$hook] as $event) {
                $events[] = array('timestamp' => (int)$timestamp,
                    'args' => isset($event['args']) && is_array($event['args']) ? $event['args'] : array(),
                    'schedule' => $event['schedule'] ?? false);
            }
        }
        return $events;
    }

    private static function protected_cron_hook($hook) {
        // Restrict high-risk known core/security/backup/system hooks even with administrator approval.
        return (bool)preg_match('/^(wp_|_wp_|core_|delete_|updraft|wordfence|wf_|action_scheduler|woocommerce_|uwmcp_|recovery_mode|wp_privacy)/i', $hook);
    }

    public static function request_cron_removal($args) {
        if (!self::admin()) return new WP_Error('forbidden', 'Administrator access required.');
        $hook = (string)($args['hook'] ?? '');
        if (strlen($hook) < 2 || strlen($hook) > 140 || !preg_match('#^[A-Za-z0-9_./:-]+$#D', $hook))
            return new WP_Error('bad_hook', 'Specify the exact existing cron hook name (2 to 140 safe characters).');
        if (self::protected_cron_hook($hook))
            return new WP_Error('protected_hook', 'Core, backup and security hooks are protected from this tool.');
        if (function_exists('has_action') && has_action($hook) !== false)
            return new WP_Error('active_hook', 'A callback is registered for this cron hook. It may still be in use; this tool only clears apparently orphaned hooks.');
        $events = self::cron_snapshot($hook);
        if (!$events) return new WP_Error('not_found', 'No scheduled events were found for the named hook.');
        if (count($events) > self::MAX_CRON_EVENTS)
            return new WP_Error('too_many', 'More than 25 events match this hook. Review and clean it manually.');
        return self::pending('remove_cron_hook', array('hook' => $hook, 'snapshot' => hash('sha256', serialize($events)), 'count' => count($events)),
            sprintf('Unschedule %d occurrence(s) of cron hook %s', count($events), $hook),
            'This stops the listed scheduled jobs from running. Some plugins may recreate them. If a plugin still uses this hook, removing it may disable essential background tasks.');
    }

    private static function redirection_table() {
        global $wpdb;
        $table = $wpdb->prefix . 'irrp_redirection_logs';
        // Table name is derived entirely from the trusted WordPress prefix plus one hard-coded suffix.
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $table)) return false;
        $matches = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        return $matches === $table ? $table : false;
    }

    public static function request_redirect_log_cleanup($args) {
        if (!self::admin()) return new WP_Error('forbidden', 'Administrator access required.');
        global $wpdb;
        $days = (int)($args['older_than_days'] ?? 30);
        if ($days < 30 || $days > 3650)
            return new WP_Error('bad_days', 'The retention period must be between 30 and 3650 days.');
        $table = self::redirection_table();
        if (!$table) return new WP_Error('no_table', 'Redirect Redirection log table not found. This tool will not modify any other table.');
        $cutoff = time() - $days * DAY_IN_SECONDS;
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$table}` WHERE `request_timestamp` < %d", $cutoff));
        if ($count === null) return new WP_Error('db_read', 'The log table could not be inspected. Nothing was changed.');
        if ((int)$count === 0) return array('executed' => false, 'matching_rows' => 0, 'message' => 'No logs older than the selected retention period.');
        $batch = min((int)$count, self::LOG_BATCH);
        $request = self::pending('purge_redirect_logs', array('cutoff' => $cutoff, 'days' => $days, 'max_rows' => $batch),
            sprintf('Delete up to %s Redirect Redirection request-log rows older than %d days', number_format_i18n($batch), $days),
            'This permanently deletes request HISTORY only, not redirect rules. It cannot be undone without a database backup. Each approval deletes at most 25,000 rows; repeat to clear a larger backlog. The database file may not shrink immediately.');
        if (is_wp_error($request)) return $request;
        $request['matching_rows'] = (int)$count;
        $request['max_rows_this_approval'] = $batch;
        return $request;
    }

    /** Optional single-table optimisation, not arbitrary SQL and not automatic. */
    public static function request_log_table_optimisation($args = array()) {
        if (!self::admin()) return new WP_Error('forbidden', 'Administrator access required.');
        global $wpdb;
        $table = self::redirection_table();
        if (!$table) return new WP_Error('no_table', 'Redirect Redirection request-log table not found.');
        if (time() - (int)get_option('uwmcp_last_log_optimisation', 0) < 7 * DAY_IN_SECONDS)
            return new WP_Error('cooldown', 'This table has been optimised by the bridge within the last seven days. Do not repeat it.');
        $status = UWMCP_Diagnostics::table_status($table);
        if (is_wp_error($status)) return $status;
        $bytes = (int)($status['Data_length'] ?? 0) + (int)($status['Index_length'] ?? 0);
        if ($bytes < 1 || $bytes > 256 * 1048576)
            return new WP_Error('table_size', 'This table is empty, unavailable or larger than 256 MB. Use your host database tools with a verified backup.');
        if (!in_array(strtolower((string)($status['Engine'] ?? '')), array('innodb','myisam'), true))
            return new WP_Error('engine', 'The table engine is not permitted for this maintenance operation.');
        return self::pending('optimise_redirect_logs', array('table' => $table, 'engine' => (string)$status['Engine'], 'max_bytes'=>256*1048576),
            'Optimise the Redirect Redirection request-log table (currently about ' . round($bytes/1048576, 1) . ' MB allocated)',
            'OPTIMIZE TABLE can rebuild and briefly lock a busy table and may temporarily require substantial free disk space. It does NOT guarantee a reduction in reported size. Verify a recent independent database backup first. This affects the request-log table only, never the eight redirect rules.');
    }

    public static function confirm() {
        if (empty(uwmcp_settings()['allow_maintenance'])) wp_die('Maintenance requests have been disabled in the bridge settings.');
        $token = isset($_REQUEST['approval']) && is_string($_REQUEST['approval']) ? wp_unslash($_REQUEST['approval']) : '';
        if (!preg_match('/^[A-Za-z0-9_-]{20,64}$/D', $token)) wp_die('Invalid maintenance approval.');
        if (!is_user_logged_in()) {
            $to = add_query_arg(array('action' => 'uwmcp_confirm_maintenance', 'approval' => $token), admin_url('admin-post.php'));
            wp_safe_redirect(wp_login_url($to)); exit;
        }
        $key = 'uwmcp_maint_' . hash('sha256', $token);
        $pending = get_transient($key);
        if (!is_array($pending)) wp_die('Approval request expired or already used.');
        if (!self::admin() || (int)$pending['user_id'] !== get_current_user_id()) wp_die('You cannot approve this request.');
        $type = (string)$pending['type'];
        $data = $pending['data'];
        if (!in_array($type, array('trash_content', 'remove_cron_hook', 'purge_redirect_logs', 'optimise_redirect_logs'), true)) wp_die('Unrecognised operation.');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            check_admin_referer('uwmcp_maintenance_' . $token);
            if (empty($_POST['uwmcp_confirm'])) wp_die('Operation cancelled.');
            if ($type === 'optimise_redirect_logs' && empty($_POST['uwmcp_backup_checked'])) wp_die('Confirm that you have verified a separate, recoverable database backup before optimising.');
            // Recheck the exact object and permissions immediately before executing anything.
            $verified = self::verify($type, $data);
            if (is_wp_error($verified)) wp_die(esc_html($verified->get_error_message()));
            delete_transient($key); // one-time action, even if part of execution later fails
            $result = self::execute($type, $data);
            if (is_wp_error($result)) {
                uwmcp_log($type, 'error', get_current_user_id());
                wp_die(esc_html($result->get_error_message()));
            }
            uwmcp_log($type, 'approved', get_current_user_id());
            wp_safe_redirect(add_query_arg('uwmcp_maintenance', 'completed', admin_url('options-general.php?page=universal-mcp-bridge'))); exit;
        }
        nocache_headers();
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WordPress maintenance approval</title>';
        echo '<style>body{font:16px/1.55 system-ui,sans-serif;max-width:680px;margin:7vh auto;padding:20px;color:#20252b}main{border:1px solid #ddd;padding:26px;border-radius:10px}button{background:#20252b;color:#fff;padding:12px 20px;border:0;border-radius:6px;cursor:pointer}</style></head><body><main><h1>Review maintenance operation</h1>';
        echo '<p><strong>' . esc_html($pending['summary']) . '</strong></p><p>' . esc_html($pending['warning']) . '</p>';
        echo '<p><strong>Nothing has been changed yet.</strong> This request expires after ten minutes.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="uwmcp_confirm_maintenance"><input type="hidden" name="approval" value="' . esc_attr($token) . '">';
        wp_nonce_field('uwmcp_maintenance_' . $token);
        if ($type === 'optimise_redirect_logs') echo '<p><label><input type="checkbox" name="uwmcp_backup_checked" value="1" required> I have verified a recent, independently stored, recoverable database backup.</label></p>';
        echo '<button type="submit" name="uwmcp_confirm" value="1">Approve this operation</button></form>';
        echo '<p><a href="' . esc_url(admin_url('options-general.php?page=universal-mcp-bridge')) . '">Cancel and return to settings</a></p></main></body></html>'; exit;
    }

    private static function verify($type, $d) {
        if ($type === 'trash_content') {
            $id = (int)$d['id']; $post = get_post($id);
            if (!$post || !in_array($post->post_type, array('post', 'page'), true) ||
                !current_user_can('delete_post', $id) ||
                $post->post_status !== $d['status'] || $post->post_type !== $d['post_type'] ||
                $post->post_modified_gmt !== $d['modified_gmt'] ||
                hash('sha256', $post->post_content) !== $d['content_hash'] ||
                hash('sha256', $post->post_title) !== $d['title_hash'])
                return new WP_Error('changed', 'The content or your permissions have changed. Prepare a fresh approval.');
            if (in_array($id, array((int)get_option('page_on_front'), (int)get_option('page_for_posts')), true))
                return new WP_Error('special_page', 'Homepage or posts index cannot be trashed through this tool.');
            if (defined('EMPTY_TRASH_DAYS') && (int)EMPTY_TRASH_DAYS === 0)
                return new WP_Error('trash_disabled', 'WordPress Trash is disabled.');
        } elseif ($type === 'remove_cron_hook') {
            $hook = $d['hook'];
            if (self::protected_cron_hook($hook) || (function_exists('has_action') && has_action($hook) !== false))
                return new WP_Error('active_hook', 'This hook is protected or now has a registered callback.');
            $events = self::cron_snapshot($hook);
            if (!$events || count($events) !== (int)$d['count'] || hash('sha256', serialize($events)) !== $d['snapshot'])
                return new WP_Error('changed', 'Scheduled events changed since the review was prepared. Nothing removed.');
        } elseif ($type === 'optimise_redirect_logs') {
            global $wpdb;
            $table = self::redirection_table();
            if (!$table || $table !== ($d['table'] ?? '')) return new WP_Error('changed', 'Log table was renamed or removed.');
            if (time() - (int)get_option('uwmcp_last_log_optimisation', 0) < 7 * DAY_IN_SECONDS)
                return new WP_Error('cooldown', 'Optimisation has been performed in the last seven days.');
            $status = UWMCP_Diagnostics::table_status($table);
            if (is_wp_error($status)) return $status;
            $bytes = (int)($status['Data_length'] ?? 0) + (int)($status['Index_length'] ?? 0);
            if ($bytes < 1 || $bytes > 256 * 1048576 ||
                (string)($status['Engine'] ?? '') !== (string)($d['engine'] ?? ''))
                return new WP_Error('changed', 'Log table engine or size changed. Prepare a fresh approval.');
        } elseif ($type === 'purge_redirect_logs') {
            if (!self::redirection_table()) return new WP_Error('no_table', 'The expected redirect-log table is no longer available.');
            if ((int)$d['max_rows'] < 1 || (int)$d['max_rows'] > self::LOG_BATCH ||
                (int)$d['cutoff'] > time() - 30 * DAY_IN_SECONDS)
                return new WP_Error('invalid_request', 'The cleanup retention period is invalid.');
        }
        return true;
    }

    private static function execute($type, $d) {
        if ($type === 'trash_content') {
            $result = wp_trash_post((int)$d['id']);
            return $result ? array('trashed_post' => (int)$d['id']) : new WP_Error('trash_failed', 'WordPress did not move the content to Trash.');
        }
        if ($type === 'remove_cron_hook') {
            $events = self::cron_snapshot($d['hook']);
            $removed = 0;
            foreach ($events as $event) {
                $result = wp_unschedule_event($event['timestamp'], $d['hook'], $event['args'], true);
                if (is_wp_error($result) || $result !== true) {
                    return new WP_Error('cron_partial', sprintf('Removed %d event(s), then encountered a scheduling failure. Check the remaining jobs manually.', $removed));
                }
                $removed++;
            }
            return array('removed' => $removed);
        }
        if ($type === 'optimise_redirect_logs') {
            global $wpdb;
            $table = self::redirection_table();
            if (!$table || $table !== ($d['table'] ?? '')) return new WP_Error('changed', 'The table changed.');
            $result = $wpdb->query('OPTIMIZE TABLE `' . $table . '`');
            if ($result === false) return new WP_Error('optimise_failed', 'Database reported an error during OPTIMIZE TABLE. Inspect host logs.');
            update_option('uwmcp_last_log_optimisation', time(), false);
            return array('table'=>$table, 'optimisation_executed'=>true,
                'note'=>'Table was optimised, but disk space reclamation is not guaranteed. Inspect the table separately.');
        }
        if ($type === 'purge_redirect_logs') {
            global $wpdb;
            $table = self::redirection_table();
            if (!$table) return new WP_Error('no_table', 'Redirect-log table missing.');
            $cutoff = (int)$d['cutoff']; $max = min(self::LOG_BATCH, max(1, (int)$d['max_rows']));
            $sql = $wpdb->prepare("DELETE FROM `{$table}` WHERE `request_timestamp` < %d LIMIT %d", $cutoff, $max);
            $deleted = $wpdb->query($sql);
            if ($deleted === false) return new WP_Error('db_write', 'WordPress could not delete the log records. Check the database error log.');
            return array('deleted_rows' => (int)$deleted);
        }
        return new WP_Error('unknown', 'Unsupported operation.');
    }
}
