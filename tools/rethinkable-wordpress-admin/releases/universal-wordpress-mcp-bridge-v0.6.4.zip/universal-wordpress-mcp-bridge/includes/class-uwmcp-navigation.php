<?php
if (!defined('ABSPATH')) exit;

/** Optional navigation enhancement. No menu database edits and no extra plugin. */
class UWMCP_Navigation {
    public static function preview_requested() {
        // Admin-only preview; no change for visitors before the setting is enabled.
        return isset($_GET['uwmcp_nav_preview'])
            && is_string($_GET['uwmcp_nav_preview'])
            && $_GET['uwmcp_nav_preview'] === '1'
            && is_user_logged_in()
            && current_user_can('manage_options');
    }
    public static function enabled() {
        return !empty(uwmcp_settings()['nav_enhanced']) || self::preview_requested();
    }
    public static function enqueue() {
        if (is_admin() || !self::enabled()) return;
        wp_enqueue_style('uwmcp-navigation', plugins_url('assets/css/navigation.css', UWMCP_FILE), array(), UWMCP_VERSION);
        wp_enqueue_script('uwmcp-navigation', plugins_url('assets/js/navigation.js', UWMCP_FILE), array(), UWMCP_VERSION, true);
    }
}
