<?php
if (!defined('ABSPATH')) exit;

class UWMCP_OAuth {
    const VERSION = '0.2.0';
    const TOKEN_TTL = 3600;
    const REFRESH_TTL = 2592000;
    private static function random_token($bytes = 32) { return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '='); }
    private static function hash($token) { return hash('sha256', (string)$token); }
    private static function enabled() { $s=uwmcp_settings(); return !empty($s['enabled']) && uwmcp_is_https(); }
    public static function metadata_url() { return uwmcp_wellknown_url('protected'); }
    public static function resource_metadata() {
        return array('resource'=>uwmcp_url(), 'authorization_servers'=>array(uwmcp_issuer()), 'scopes_supported'=>array('wp.read','wp.write','offline_access'));
    }
    public static function server_metadata() {
        return array(
            'issuer'=>uwmcp_issuer(),
            'authorization_endpoint'=>admin_url('admin-post.php?action=uwmcp_authorize'),
            'token_endpoint'=>uwmcp_rest_endpoint('oauth/token'),
            'registration_endpoint'=>uwmcp_rest_endpoint('oauth/register'),
            'response_types_supported'=>array('code'),
            'grant_types_supported'=>array('authorization_code','refresh_token'),
            'token_endpoint_auth_methods_supported'=>array('none'),
            'code_challenge_methods_supported'=>array('S256'),
            'scopes_supported'=>array('wp.read','wp.write','offline_access'),
            'authorization_response_iss_parameter_supported'=>true,
            'client_id_metadata_document_supported'=>false,
        );
    }
    public static function metadata_route($req) {
        $type=(string)$req['document'];
        return rest_ensure_response($type==='resource'?self::resource_metadata():self::server_metadata());
    }
    private static function fail($error, $description, $status=400) {
        return new WP_REST_Response(array('error'=>$error,'error_description'=>$description), $status, array('Cache-Control'=>'no-store'));
    }
    private static function allowed_redirect($url) {
        if (!is_string($url) || strlen($url)>1200) return false;
        $p=wp_parse_url($url);
        if (!$p || empty($p['host']) || empty($p['scheme']) || isset($p['user']) || isset($p['pass']) || isset($p['fragment'])) return false;
        $host=strtolower(rtrim($p['host'],'.'));
        $scheme=strtolower($p['scheme']);
        $settings=uwmcp_settings();
        $allowed=array_map('strtolower',preg_split('/[\s,]+/',(string)$settings['redirect_hosts'], -1, PREG_SPLIT_NO_EMPTY));
        if ($scheme==='https' && in_array($host,$allowed,true)) return true;
        // Loopback redirects may be enabled for an optional desktop client.
        return $scheme==='http' && in_array($host,array('localhost','127.0.0.1','::1'),true) && !empty($settings['allow_loopback']);
    }
    public static function register_client($req) {
        if (!self::enabled()) return self::fail('temporarily_unavailable','Enable the bridge under Settings and use HTTPS.',503);
        $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
        $rate='uwmcp_reg_'.substr(self::hash($ip),0,32);
        $count=(int)get_transient($rate);
        if ($count>=12) return self::fail('slow_down','Too many registration requests.',429);
        set_transient($rate,$count+1,HOUR_IN_SECONDS);
        $params=$req->get_json_params();
        if (!is_array($params)) return self::fail('invalid_client_metadata','Expected JSON client metadata.');
        $uris=$params['redirect_uris']??null;
        if (!is_array($uris) || count($uris)<1 || count($uris)>5) return self::fail('invalid_redirect_uri','1 to 5 redirect URIs required.');
        foreach($uris as $uri) if (!self::allowed_redirect($uri)) return self::fail('invalid_redirect_uri','The redirect host is not in the WordPress allowlist.');
        $methods=$params['token_endpoint_auth_method']??'none';
        if ($methods!=='none') return self::fail('invalid_client_metadata','Only public OAuth clients with PKCE are supported.');
        $grants=$params['grant_types']??array('authorization_code','refresh_token');
        if (!is_array($grants) || array_diff($grants,array('authorization_code','refresh_token'))) return self::fail('invalid_client_metadata','Unsupported grant type.');
        $clients=get_option('uwmcp_clients',array());
        if (!is_array($clients)) $clients=array();
        if (count($clients)>=40) return self::fail('server_error','Registered client limit reached. Revoke old clients in WordPress settings.',503);
        $id='uwmcp_'.self::random_token(24);
        $name=sanitize_text_field((string)($params['client_name']??'MCP client'));
        $clients[$id]=array('name'=>substr($name,0,100),'uris'=>array_values($uris),'created'=>time());
        update_option('uwmcp_clients',$clients,false);
        return new WP_REST_Response(array('client_id'=>$id,'client_name'=>$clients[$id]['name'],'redirect_uris'=>array_values($uris),'token_endpoint_auth_method'=>'none','grant_types'=>array('authorization_code','refresh_token'),'response_types'=>array('code'),'client_id_issued_at'=>time()),201,array('Cache-Control'=>'no-store'));
    }
    private static function request_array() {
        // Explicitly select the relevant protocol parameters; don't pass arbitrary query params to the callback.
        $keys=array('client_id','redirect_uri','response_type','scope','state','code_challenge','code_challenge_method','resource');
        $out=array();
        foreach($keys as $k) if(isset($_REQUEST[$k]) && is_string($_REQUEST[$k])) $out[$k]=wp_unslash($_REQUEST[$k]);
        return $out;
    }
    private static function redirect_auth_error($uri,$error,$state='') {
        $args=array('error'=>$error,'iss'=>uwmcp_issuer());
        if ($state!=='') $args['state']=$state;
        wp_redirect(add_query_arg($args,$uri),302,'Universal WordPress MCP Bridge');
        exit;
    }
    public static function authorize() {
        if (!self::enabled()) wp_die('MCP bridge is disabled or HTTPS is unavailable.', 'MCP authorisation', array('response'=>503));
        $p=self::request_array();
        $clients=get_option('uwmcp_clients',array());
        $client=$clients[$p['client_id']??'']??null;
        $uri=$p['redirect_uri']??'';
        if (!$client || !in_array($uri,$client['uris'],true) || !self::allowed_redirect($uri)) wp_die('Unknown client or redirect URI.', 'MCP authorisation',array('response'=>400));
        $state=(string)($p['state']??'');
        if (($p['response_type']??'')!=='code') self::redirect_auth_error($uri,'unsupported_response_type',$state);
        if (($p['code_challenge_method']??'')!=='S256' || !preg_match('/^[A-Za-z0-9_-]{43,128}$/D',(string)($p['code_challenge']??''))) self::redirect_auth_error($uri,'invalid_request',$state);
        if (($p['resource']??'')!==uwmcp_url()) self::redirect_auth_error($uri,'invalid_target',$state);
        $requested=preg_split('/\s+/',trim((string)($p['scope']??'wp.read')),-1,PREG_SPLIT_NO_EMPTY);
        if (!$requested) $requested=array('wp.read');
        if (array_diff($requested,array('wp.read','wp.write','offline_access')) || !in_array('wp.read',$requested,true)) self::redirect_auth_error($uri,'invalid_scope',$state);
        if (!is_user_logged_in()) {
            $query=array_merge(array('action'=>'uwmcp_authorize'),$p);
            wp_safe_redirect(wp_login_url(add_query_arg($query,admin_url('admin-post.php'))));
            exit;
        }
        if (!current_user_can('manage_options')) wp_die('Only WordPress administrators can grant MCP access.', 'MCP authorisation',array('response'=>403));
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            check_admin_referer('uwmcp_authorization_consent');
            if (empty($_POST['uwmcp_approve'])) self::redirect_auth_error($uri,'access_denied',$state);
            $code=self::random_token(32);
            set_transient('uwmcp_code_'.self::hash($code),array('client_id'=>$p['client_id'],'redirect_uri'=>$uri,'resource'=>$p['resource'],'user_id'=>get_current_user_id(),'scope'=>implode(' ',array_unique($requested)),'challenge'=>$p['code_challenge']),300);
            wp_redirect(add_query_arg(array('code'=>$code,'state'=>$state,'iss'=>uwmcp_issuer()),$uri),302,'Universal WordPress MCP Bridge');
            exit;
        }
        nocache_headers();
        $action=admin_url('admin-post.php');
        $data=array_merge($p,array('action'=>'uwmcp_authorize'));
        $site=esc_html(get_bloginfo('name'));
        $client_name=esc_html($client['name']);
        $is_write=in_array('wp.write',$requested,true);
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WordPress MCP access</title><style>body{font:16px/1.6 system-ui,sans-serif;max-width:560px;margin:8vh auto;padding:20px;color:#17202b}main{border:1px solid #dde1e5;border-radius:14px;padding:28px}button{padding:12px 22px;background:#17202b;color:white;border:0;border-radius:7px;cursor:pointer}button.secondary{background:#eee;color:#222;margin-left:8px}small{color:#555}</style></head><body><main>';
        echo '<h1>Connect to '. $site .'</h1><p><strong>'. $client_name .'</strong> requests access as <strong>'.esc_html(wp_get_current_user()->display_name).'</strong>.</p>';
        $write_description = $is_write ? ', and access to enabled write tools including content edits and administrator-approved maintenance requests' : '';
        echo '<p>Access: read site information, pages and diagnostics'.esc_html($write_description).'.</p>';
        echo '<p><small>Publishing and removal operations require separate WordPress confirmation. This access can be revoked in Settings → Universal MCP Bridge.</small></p>';
        echo '<form method="post" action="'.esc_url($action).'">';
        foreach($data as $key=>$value) echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($value).'">';
        wp_nonce_field('uwmcp_authorization_consent');
        echo '<button name="uwmcp_approve" value="1" type="submit">Authorise access</button><button class="secondary" name="uwmcp_approve" value="0" type="submit">Deny</button></form></main></body></html>';
        exit;
    }
    private static function token_response($client,$user_id,$scope,$audience,$refresh='') {
        $tokens=get_option('uwmcp_tokens',array());if(!is_array($tokens))$tokens=array();
        $now=time();
        foreach($tokens as $k=>$row) if (($row['refresh_expires']??$row['expires']??0)<$now) unset($tokens[$k]);
        if (count($tokens)>=100) $tokens=array_slice($tokens,-80,null,true);
        $access=self::random_token();$access_id=self::hash($access);
        $new_refresh=in_array('offline_access',explode(' ',$scope),true)?self::random_token():'';
        $tokens[$access_id]=array('client_id'=>$client,'user_id'=>(int)$user_id,'scope'=>$scope,'aud'=>$audience,'expires'=>$now+self::TOKEN_TTL,'refresh_hash'=>$new_refresh?self::hash($new_refresh):'','refresh_expires'=>$new_refresh?$now+self::REFRESH_TTL:0,'issued'=>$now);
        update_option('uwmcp_tokens',$tokens,false);
        $reply=array('access_token'=>$access,'token_type'=>'Bearer','expires_in'=>self::TOKEN_TTL,'scope'=>$scope);
        if($new_refresh) $reply['refresh_token']=$new_refresh;
        return new WP_REST_Response($reply,200,array('Cache-Control'=>'no-store','Pragma'=>'no-cache'));
    }
    public static function token($req) {
        if (!self::enabled()) return self::fail('temporarily_unavailable','Bridge disabled.',503);
        $grant=(string)$req->get_param('grant_type');
        $id=(string)$req->get_param('client_id');
        $clients=get_option('uwmcp_clients',array());
        if (!$id || !isset($clients[$id])) return self::fail('invalid_client','Unregistered OAuth client.',401);
        if ($grant==='authorization_code') {
            $code=(string)$req->get_param('code');
            $name='uwmcp_code_'.self::hash($code);
            $row=get_transient($name);
            if (!is_array($row)) return self::fail('invalid_grant','The code is invalid or expired.');
            // Consume the code before checking PKCE, preventing replay.
            delete_transient($name);
            $verifier=(string)$req->get_param('code_verifier');
            $expected=rtrim(strtr(base64_encode(hash('sha256',$verifier,true)),'+/','-_'),'=');
            if (strlen($verifier)<43 || strlen($verifier)>128 || !hash_equals((string)$row['challenge'],$expected)) return self::fail('invalid_grant','PKCE verification failed.');
            if ($row['client_id']!==$id || $row['redirect_uri']!==(string)$req->get_param('redirect_uri') || $row['resource']!==(string)$req->get_param('resource')) return self::fail('invalid_grant','OAuth client, redirect or resource mismatch.');
            if (!user_can((int)$row['user_id'],'manage_options')) return self::fail('access_denied','Authorising user is no longer an administrator.',403);
            return self::token_response($id,$row['user_id'],$row['scope'],$row['resource']);
        }
        if ($grant==='refresh_token') {
            $raw=(string)$req->get_param('refresh_token');$h=self::hash($raw);$tokens=get_option('uwmcp_tokens',array());
            foreach($tokens as $key=>$record) {
                if (($record['client_id']??'')===$id && $raw!=='' && hash_equals((string)($record['refresh_hash']??''),$h)) {
                    if (($record['refresh_expires']??0)<time() || ($record['aud']??'')!==uwmcp_url() || !user_can((int)$record['user_id'],'manage_options')) return self::fail('invalid_grant','Refresh token expired or access revoked.');
                    unset($tokens[$key]);update_option('uwmcp_tokens',$tokens,false);
                    return self::token_response($id,$record['user_id'],$record['scope'],$record['aud']);
                }
            }
            return self::fail('invalid_grant','Refresh token invalid or revoked.');
        }
        return self::fail('unsupported_grant_type','Only authorization_code and refresh_token are supported.');
    }
    public static function authenticate($req,$scope='wp.read') {
        $auth=(string)$req->get_header('authorization');
        if (!preg_match('/^Bearer\s+([A-Za-z0-9_-]{32,200})$/iD',trim($auth),$m)) return null;
        $token_hash=self::hash($m[1]);
        $tokens=get_option('uwmcp_tokens',array());
        if (!isset($tokens[$token_hash])) return null;
        $record=$tokens[$token_hash];
        if ((int)($record['expires']??0)<time() || ($record['aud']??'')!==uwmcp_url()) return null;
        if (!in_array($scope,explode(' ',(string)$record['scope']),true)) return null;
        if (!user_can((int)$record['user_id'],'manage_options')) return null;
        return (int)$record['user_id'];
    }
    public static function unauthorised($scope='wp.read') {
        $response=new WP_REST_Response(array('error'=>'unauthorized','message'=>'Connect using WordPress OAuth.'),401);
        $response->header('WWW-Authenticate','Bearer resource_metadata="'.esc_url_raw(self::metadata_url()).'", scope="'.($scope==='wp.write'?'wp.read wp.write':'wp.read').'"');
        $response->header('Cache-Control','no-store');
        return $response;
    }
}
