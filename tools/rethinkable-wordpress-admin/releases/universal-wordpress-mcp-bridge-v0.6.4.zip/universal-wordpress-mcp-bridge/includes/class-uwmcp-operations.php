<?php
if (!defined('ABSPATH')) exit;

/** High-risk operations: MCP only prepares a request. WordPress administrator must approve in wp-admin. */
class UWMCP_Operations {
    public static function request_plugin_action($args) {
        if (!current_user_can('manage_options')) return new WP_Error('forbidden','Administrator access required.');
        $action=(string)($args['action']??'');$file=(string)($args['plugin']??'');
        if(!in_array($action,array('deactivate','uninstall'),true))return new WP_Error('action','Only deactivate and uninstall are supported.');
        require_once ABSPATH.'wp-admin/includes/plugin.php';
        $installed=get_plugins();
        if(!isset($installed[$file]) || validate_file($file)!==0)return new WP_Error('plugin','The plugin file must match an installed WordPress plugin exactly.');
        if($file===plugin_basename(UWMCP_PATH.'universal-wordpress-mcp-bridge.php'))return new WP_Error('self','This connector cannot uninstall or deactivate itself through MCP.');
        if(is_plugin_active_for_network($file))return new WP_Error('network_active','Network-active plugins must be managed in Network Admin, not via this site-level MCP tool.');
        if($action==='deactivate' && !is_plugin_active($file))return new WP_Error('already_inactive','This plugin is already inactive.');
        if($action==='uninstall' && is_plugin_active($file))return new WP_Error('active','Deactivate the plugin and verify the website before uninstalling it.');
        if($action==='uninstall' && !current_user_can('delete_plugins'))return new WP_Error('forbidden','You cannot permanently delete plugins with this WordPress account.');
        $token=rtrim(strtr(base64_encode(random_bytes(24)),'+/','-_'),'=');
        set_transient('uwmcp_pluginop_'.hash('sha256',$token),array('plugin'=>$file,'name'=>$installed[$file]['Name'],'version'=>$installed[$file]['Version'],'action'=>$action,'user_id'=>get_current_user_id()),600);
        return array('executed'=>false,'action'=>$action,'plugin'=>$file,'review_url'=>add_query_arg(array('action'=>'uwmcp_confirm_plugin_action','approval'=>$token),admin_url('admin-post.php')),'expires_in'=>600,'instruction'=>'Only a WordPress administrator can approve the operation. Plugin uninstall may permanently delete plugin settings and files.');
    }
    public static function confirm() {
        if (empty(uwmcp_settings()['allow_maintenance'])) wp_die('Maintenance requests have been disabled in the bridge settings.');
        $token=isset($_REQUEST['approval'])&&is_string($_REQUEST['approval'])?wp_unslash($_REQUEST['approval']):'';
        if(!preg_match('/^[A-Za-z0-9_-]{20,64}$/D',$token))wp_die('Invalid plugin action approval.');
        if(!is_user_logged_in()){
            $to=add_query_arg(array('action'=>'uwmcp_confirm_plugin_action','approval'=>$token),admin_url('admin-post.php'));
            wp_safe_redirect(wp_login_url($to));exit;
        }
        $key='uwmcp_pluginop_'.hash('sha256',$token);$pending=get_transient($key);
        if(!is_array($pending))wp_die('Approval request expired or already used.');
        if(!current_user_can('manage_options') || get_current_user_id()!==(int)$pending['user_id'] || !current_user_can('activate_plugins')) wp_die('You cannot approve this operation.');
        $file=$pending['plugin'];$action=$pending['action'];
        require_once ABSPATH.'wp-admin/includes/plugin.php';
        $all=get_plugins();
        if(!isset($all[$file]) || $all[$file]['Version']!==$pending['version'])wp_die('Plugin changed since this request was prepared. Request a new review.');
        if($file===plugin_basename(UWMCP_PATH.'universal-wordpress-mcp-bridge.php'))wp_die('Cannot remove the MCP connector through itself.');
        if($_SERVER['REQUEST_METHOD']==='POST') {
            check_admin_referer('uwmcp_plugin_action_'.$token);
            if(empty($_POST['uwmcp_confirm']))wp_die('Operation cancelled.');
            delete_transient($key);
            if($action==='deactivate'){
                deactivate_plugins($file);
                if(is_plugin_active($file))wp_die('WordPress did not deactivate the plugin. Please review manually.');
            } elseif($action==='uninstall'){
                if(!current_user_can('delete_plugins'))wp_die('Your account does not have permission to delete plugins.');
                if(is_plugin_active($file) || is_plugin_active_for_network($file))wp_die('The plugin must be inactive before deletion.');
                require_once ABSPATH.'wp-admin/includes/file.php';
                if(!WP_Filesystem())wp_die('WordPress needs filesystem credentials to delete this plugin. Please use Plugins in wp-admin.');
                $success=delete_plugins(array($file));
                if(is_wp_error($success))wp_die('Uninstall failed: '.esc_html($success->get_error_message()));
                if($success===false)wp_die('WordPress could not delete the plugin. Check filesystem access.');
            } else wp_die('Unsupported operation.');
            uwmcp_log('plugin_'.$action,'ok',get_current_user_id());
            wp_safe_redirect(admin_url('plugins.php?uwmcp_operation=completed'));exit;
        }
        nocache_headers();
        $warn=$action==='uninstall'?'This deletes plugin files and runs the plugin uninstall routine, which may permanently remove data. A complete backup is strongly recommended.':'This disables the plugin and may remove features from your public site. Test the site immediately after approval.';
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Review WordPress plugin action</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:600px;margin:10vh auto;padding:20px}button{padding:12px 20px;background:#17202b;color:white;border:0;border-radius:6px}</style></head><body><h1>Review plugin '.esc_html($action).'</h1>';
        echo '<p><strong>'.esc_html($pending['name']).'</strong> ('.esc_html($file).'), version '.esc_html($pending['version']).'</p><p>'.esc_html($warn).'</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uwmcp_confirm_plugin_action"><input type="hidden" name="approval" value="'.esc_attr($token).'">';
        wp_nonce_field('uwmcp_plugin_action_'.$token);
        echo '<button type="submit" name="uwmcp_confirm" value="1">Confirm '.esc_html($action).'</button></form><p><a href="'.esc_url(admin_url('plugins.php')).'">Cancel and return to Plugins</a></p></body></html>';exit;
    }
}
