<?php
if (!defined('ABSPATH')) exit;

class UWMCP_Server {
    private static function base_meta() { return array('io.modelcontextprotocol/serverInfo'=>array('name'=>'universal-wordpress-mcp-bridge','version'=>UWMCP_VERSION)); }
    public static function routes() {
        register_rest_route('universal-mcp/v1','/mcp',array(
            array('methods'=>'POST','callback'=>array(__CLASS__,'mcp'),'permission_callback'=>'__return_true'),
            array('methods'=>'GET','callback'=>array(__CLASS__,'mcp_get'),'permission_callback'=>'__return_true'),
            array('methods'=>'DELETE','callback'=>array(__CLASS__,'mcp_get'),'permission_callback'=>'__return_true'),
        ));
        register_rest_route('universal-mcp/v1','/oauth/register',array('methods'=>'POST','callback'=>array('UWMCP_OAuth','register_client'),'permission_callback'=>'__return_true'));
        register_rest_route('universal-mcp/v1','/oauth/token',array('methods'=>'POST','callback'=>array('UWMCP_OAuth','token'),'permission_callback'=>'__return_true'));
        register_rest_route('universal-mcp/v1','/oauth/metadata',array('methods'=>'GET','callback'=>function(){return rest_ensure_response(UWMCP_OAuth::server_metadata());},'permission_callback'=>'__return_true'));
        register_rest_route('universal-mcp/v1','/oauth/resource',array('methods'=>'GET','callback'=>function(){return rest_ensure_response(UWMCP_OAuth::resource_metadata());},'permission_callback'=>'__return_true'));
        register_rest_route('universal-mcp/v1','/health',array('methods'=>'GET','callback'=>function(){
            return rest_ensure_response(array('plugin'=>'Universal WordPress MCP Bridge','version'=>UWMCP_VERSION,'https'=>uwmcp_is_https(),'enabled'=>!empty(uwmcp_settings()['enabled']),'mcp'=>uwmcp_url()));
        },'permission_callback'=>'__return_true'));
    }
    public static function mcp_get() { return new WP_REST_Response(array('error'=>'method_not_allowed','message'=>'The MCP endpoint accepts stateless JSON-RPC over POST.'),405,array('Allow'=>'POST')); }
    private static function json_error($id,$code,$message,$status=400,$data=null) {
        $error=array('code'=>$code,'message'=>$message);if($data!==null)$error['data']=$data;
        return new WP_REST_Response(array('jsonrpc'=>'2.0','id'=>$id,'error'=>$error),$status,array('Cache-Control'=>'no-store'));
    }
    private static function rpc_result($id,$result,$modern) {
        if($modern) { $result['resultType']='complete';$result['_meta']=self::base_meta(); }
        return new WP_REST_Response(array('jsonrpc'=>'2.0','id'=>$id,'result'=>$result),200,array('Cache-Control'=>'no-store'));
    }
    private static function origin_ok($req) {
        $origin=(string)$req->get_header('origin');
        if ($origin==='')return true;
        $parsed=wp_parse_url($origin);if(!$parsed || !isset($parsed['host']) || !isset($parsed['scheme'])) return false;
        $host=strtolower($parsed['host']);
        $own=strtolower((string)wp_parse_url(home_url('/'),PHP_URL_HOST));
        if ($host===$own && strtolower($parsed['scheme'])==='https')return true;
        $settings=uwmcp_settings();
        $allowed=array_map('strtolower',preg_split('/[\s,]+/',(string)$settings['redirect_hosts'],-1,PREG_SPLIT_NO_EMPTY));
        return strtolower($parsed['scheme'])==='https' && in_array($host,$allowed,true);
    }
    public static function mcp($req) {
        $s=uwmcp_settings();
        if(!uwmcp_is_https() || empty($s['enabled'])) return self::json_error(null,-32000,'MCP bridge is disabled or HTTPS unavailable.',503);
        if(!self::origin_ok($req)) return self::json_error(null,-32000,'Disallowed Origin.',403);
        $body=$req->get_json_params();
        if(!is_array($body) || array_values($body)===$body || ($body['jsonrpc']??'')!=='2.0' || !is_string($body['method']??null))return self::json_error(null,-32600,'Invalid JSON-RPC request.');
        $method=$body['method'];$id=$body['id']??null;$params=$body['params']??array();
        if(!is_array($params))return self::json_error($id,-32602,'Parameters must be an object.');
        $requested=(string)$req->get_header('mcp-protocol-version');
        if($requested==='')$requested=(string)($params['protocolVersion']??'2025-06-18');
        $modern=($requested==='2026-07-28');
        if(!in_array($requested,array('2026-07-28','2025-11-25','2025-06-18','2025-03-26'),true))return self::json_error($id,-32602,'UnsupportedProtocolVersionError',400,array('supported'=>array('2026-07-28','2025-11-25','2025-06-18')));
        if($modern) {
            $meta=$params['_meta']??null;
            if(!is_array($meta) || ($meta['io.modelcontextprotocol/protocolVersion']??'')!==$requested || (string)$req->get_header('mcp-method')!==$method)
                return self::json_error($id,-32020,'HeaderMismatch: protocol or method metadata does not match.',400);
            if(in_array($method,array('tools/call'),true) && (string)$req->get_header('mcp-name')!==(string)($params['name']??''))
                return self::json_error($id,-32020,'HeaderMismatch: Mcp-Name must match the tool name.',400);
        }
        if($method==='notifications/initialized' || $method==='notifications/cancelled')return new WP_REST_Response(null,202,array('Cache-Control'=>'no-store'));
        if($method==='ping')return self::rpc_result($id,array(),$modern);
        if($method==='server/discover')return self::rpc_result($id,array('supportedVersions'=>array('2026-07-28','2025-11-25','2025-06-18'),'capabilities'=>array('tools'=>array('listChanged'=>true)),'ttlMs'=>0,'cacheScope'=>'private'),true);
        if($method==='initialize') {
            $version=(string)($params['protocolVersion']??'2025-06-18');
            if(!in_array($version,array('2025-03-26','2025-06-18','2025-11-25'),true))$version='2025-06-18';
            return self::rpc_result($id,array('protocolVersion'=>$version,'capabilities'=>array('tools'=>array('listChanged'=>true)),'serverInfo'=>array('name'=>'universal-wordpress-mcp-bridge','version'=>UWMCP_VERSION)),false);
        }
        // No sensitive tool names or content are disclosed without OAuth.
        $uid=UWMCP_OAuth::authenticate($req,'wp.read');
        if(!$uid)return UWMCP_OAuth::unauthorised();
        if($method==='tools/list')return self::rpc_result($id,array('tools'=>UWMCP_Tools::definitions(),'ttlMs'=>0,'cacheScope'=>'private'),$modern);
        if($method==='resources/list' || $method==='prompts/list')return self::rpc_result($id,array($method==='resources/list'?'resources':'prompts'=>array(),'ttlMs'=>0,'cacheScope'=>'private'),$modern);
        if($method==='tools/call') {
            $name=(string)($params['name']??'');
            if($name==='')return self::json_error($id,-32602,'A tool name is required.');
            if(UWMCP_Tools::scope($name)==='wp.write') {
                $uid=UWMCP_OAuth::authenticate($req,'wp.write');
                if(!$uid)return UWMCP_OAuth::unauthorised('wp.write');
            }
            $args=$params['arguments']??array();
            if(!is_array($args))return self::json_error($id,-32602,'Tool arguments must be an object.');
            $result=UWMCP_Tools::run($name,$args,$uid);
            return self::rpc_result($id,$result,$modern);
        }
        return self::json_error($id,-32601,'Method not found.',404);
    }
}
