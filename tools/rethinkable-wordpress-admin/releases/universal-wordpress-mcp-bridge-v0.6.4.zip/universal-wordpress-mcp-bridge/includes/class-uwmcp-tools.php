<?php
if (!defined('ABSPATH')) exit;

class UWMCP_Tools {
    private static function tool($name,$description,$properties=array(),$required=array(),$write=false) {
        return array(
            'name'=>$name,'description'=>$description,
            'inputSchema'=>array('type'=>'object','properties'=>(object)$properties,'required'=>$required,'additionalProperties'=>false),
            'annotations'=>array('readOnlyHint'=>!$write,'destructiveHint'=>false,'idempotentHint'=>!$write,'openWorldHint'=>false),
        );
    }
    private static function str_arg($description,$max=200) { return array('type'=>'string','description'=>$description,'maxLength'=>$max); }
    private static function int_arg($description,$min=1,$max=1000000) { return array('type'=>'integer','description'=>$description,'minimum'=>$min,'maximum'=>$max); }
    public static function definitions() {
        $tools=array(
            self::tool('site_info','Read basic WordPress site details, language, active theme and configuration of this bridge.'),
            self::tool('list_content','List WordPress pages, posts or an existing public custom post type. Pagination is bounded.',array(
                'post_type'=>self::str_arg('WordPress post type, e.g. page, post, event',70),
                'status'=>array('type'=>'string','enum'=>array('publish','draft','private','pending','future','trash','any')),
                'search'=>self::str_arg('Optional search text',150),
                'page'=>self::int_arg('Page number',1,100),
                'per_page'=>self::int_arg('Results per page, maximum 30',1,30)
            )),
            self::tool('get_content','Read an individual page or post, including RAW title and body, preserving qTranslate-XT language markers.',array('id'=>self::int_arg('WordPress post ID')) ,array('id')),
            self::tool('list_media','List media library items and attachment URLs.',array('page'=>self::int_arg('Page',1,100),'per_page'=>self::int_arg('Maximum 30 items',1,30))),
            self::tool('find_shortcode','Find published content containing a particular shortcode, including archived festival events.',array('shortcode'=>self::str_arg('Shortcode name without brackets, e.g. smartslider3',60),'limit'=>self::int_arg('Maximum matches to return',1,50)),array('shortcode')),
            self::tool('list_plugins','List active and inactive WordPress plugins and pending updates; does not change plugins.'),
            self::tool('site_diagnostics','Read core and theme versions, approximate table sizes, estimated InnoDB row counts and scheduled backup settings, without reading secrets.'),
            self::tool('inspect_database_table','Inspect one site-owned database table, optionally counting its actual rows. SHOW TABLE STATUS counts are estimates.',array('table'=>self::str_arg('Exact prefixed table name returned by site_diagnostics, e.g. wp_posts.',150),'exact_count'=>array('type'=>'boolean','description'=>'Run SELECT COUNT(*) on this one table, if it is no larger than 256 MB.')) ,array('table')),
            self::tool('backup_health','Read UpdraftPlus backup schedules, remote-destination type, and history metadata. Never exposes cloud credentials.'),
            self::tool('inspect_design_css','Read the site-wide WordPress-managed CSS overrides and revision hash; administrator-only.'),
            self::tool('list_cron_hooks','Read up to 60 scheduled WordPress task names, times and recurrence; optionally filter by hook substring. No events are executed or removed.',array('search'=>self::str_arg('Optional substring of cron hook name, e.g. depicter',100))),
        );
        $settings=uwmcp_settings();
        if (!empty($settings['allow_writes'])) {
            $tools[]=self::tool('create_draft','Create a draft WordPress page or post. This never publishes.',array('post_type'=>array('type'=>'string','enum'=>array('post','page'),'description'=>'WordPress core post or page. Plugin-specific event data should use the plugin own API.'),'title'=>self::str_arg('New draft title. qTranslate language markers are supported.',250),'content'=>self::str_arg('Full raw draft content (maximum 100000 characters).',100000)),array('post_type','title'),true);
            $tools[]=self::tool('replace_content','Replace exactly one occurrence of an exact text snippet in a WordPress page or post. Creates a WordPress revision and preserves qTranslate markers.',array('id'=>self::int_arg('Existing WordPress post ID'),'old_text'=>self::str_arg('Exact existing text snippet, nonempty.',20000),'new_text'=>self::str_arg('Replacement snippet.',30000),'expected_modified_gmt'=>self::str_arg('Optional value of modified_gmt returned by get_content to prevent conflicting edits.',30)),array('id','old_text','new_text'),true);
            $tools[]=self::tool('set_yoast_seo','Update a post or page Yoast SEO metadata, if Yoast is installed. Does not alter the permalink.',array('id'=>self::int_arg('Post/page ID'),'seo_title'=>self::str_arg('Search result title; can include qTranslate markers.',250),'meta_description'=>self::str_arg('Search description; can include language markers.',750),'social_description'=>self::str_arg('Optional social sharing description.',750)),array('id'),true);
            if (!empty($settings['allow_publish'])) {
                $tools[]=self::tool('request_publish','Prepare publication of a draft and return a WordPress administrator review URL. The post is NOT published until approved within WordPress.',array('id'=>self::int_arg('Draft post/page ID')),array('id'),true);
            }
        }
        if (!empty($settings['allow_maintenance'])) {
            $tools[]=self::tool('request_design_css','Prepare an administrator-approved replacement for the site-wide CSS overrides, without editing the theme. All changes require approval in WordPress.',array('css'=>self::str_arg('Complete replacement managed CSS (up to 30000 characters); do not include HTML or external imports.',30000),'expected_sha256'=>self::str_arg('Exact SHA-256 from inspect_design_css to prevent overwriting another edit.',64)),array('css','expected_sha256'),true);
            $tools[]=self::tool('request_plugin_action','Prepare one plugin deactivation or uninstall. No plugin is changed until the authorising WordPress administrator approves in wp-admin.',array('plugin'=>self::str_arg('Exact installed plugin file path returned by list_plugins.',220),'action'=>array('type'=>'string','enum'=>array('deactivate','uninstall'))),array('plugin','action'),true);
            $tools[]=self::tool('request_trash_content','Prepare moving one normal WordPress page/post to Trash (not permanent deletion). Requires an approval link opened by the same WordPress administrator.',array('id'=>self::int_arg('WordPress page or post ID')),array('id'),true);
            $tools[]=self::tool('request_cron_removal','Prepare removal of an apparently orphaned WordPress cron hook. Protected or active hooks are refused; administrator must review every removal.',array('hook'=>self::str_arg('Exact WP-Cron hook name returned by list_cron_hooks.',140)),array('hook'),true);
            $tools[]=self::tool('request_log_table_optimisation','Prepare a ONE-TIME WordPress administrator approval to optimise only Redirect Redirection request logs. Requires an independently verified backup and can temporarily lock the table.',array(),array(),true);
            $tools[]=self::tool('request_redirect_log_cleanup','Prepare deletion of up to 25000 OLD Redirect Redirection request-log records. Rules are never deleted. Requires WordPress administrator approval.',array('older_than_days'=>self::int_arg('Delete request logs older than this number of days, 30 to 3650.',30,3650)),array(),true);
        }
        // Always advertise the code tools so clients with a cached MCP catalogue
        // can discover them even if this setting was enabled after connection.
        // UWMCP_Code::can_read/can_modify enforce the live opt-in, admin role,
        // WordPress file-edit restrictions and per-change approval on every call.
        {
            $tools[]=self::tool('list_theme_code','List existing PHP and JavaScript files in the active WordPress theme. Read-only, bounded and excludes plugins, core, uploads and symlinks.');
            $tools[]=self::tool('read_theme_code','Read a bounded, numbered section of one existing active-theme PHP/JS file, and get the SHA-256 for a safe patch.',array(
                'path'=>self::str_arg('Relative PHP/JS file path returned by list_theme_code',220),
                'start_line'=>self::int_arg('First source line (1-based)',1,100000),
                'max_lines'=>self::int_arg('Maximum lines (up to 120)',1,120)
            ),array('path'));
            $tools[]=self::tool('request_theme_code_patch','Prepare an EXACT one-occurrence PHP/JavaScript patch within an existing active-theme file. PHP syntax checked; separate same-administrator WordPress approval required. Previous version stored for rollback. No file changed by this request.',array(
                'path'=>self::str_arg('Relative existing PHP or JS theme file path',220),
                'expected_sha256'=>self::str_arg('Current SHA-256 from read_theme_code',64),
                'old_text'=>self::str_arg('Exact text to replace, appearing once (maximum 16 KB)',16000),
                'new_text'=>self::str_arg('Replacement code snippet (maximum 24 KB)',24000)
            ),array('path','expected_sha256','old_text','new_text'),true);
            $tools[]=self::tool('list_theme_code_revisions','List the five previous active-theme code versions retained for controlled rollback. Does not return the source itself.');
            $tools[]=self::tool('request_theme_code_rollback','Prepare restoration of a saved PHP/JavaScript theme revision. Requires separate approval from the same administrator; no automatic rollback.',array(
                'revision_id'=>self::str_arg('Revision ID returned by list_theme_code_revisions',20)
            ),array('revision_id'),true);
        }
        return $tools;
    }
    public static function scope($tool) {
        return in_array($tool,array('create_draft','replace_content','set_yoast_seo','request_publish','request_plugin_action','request_trash_content','request_cron_removal','request_redirect_log_cleanup','request_log_table_optimisation','request_design_css','request_theme_code_patch','request_theme_code_rollback'),true)?'wp.write':'wp.read';
    }
    private static function text_length($value) { return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value); }
    private static function text_prefix($value,$limit) { return function_exists('mb_substr') ? mb_substr($value,0,$limit,'UTF-8') : substr($value,0,$limit); }
    private static function error($message) { return array('isError'=>true,'content'=>array(array('type'=>'text','text'=>(string)$message))); }
    public static function response($value) {
        $encoded=wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        return array('content'=>array(array('type'=>'text','text'=>$encoded)),'structuredContent'=>is_array($value)?$value:array('value'=>$value));
    }
    private static function safe_post_type($type) {
        $p=get_post_type_object($type);
        return $p && $p->public && $p->show_ui && !in_array($type,array('attachment','revision','nav_menu_item'),true);
    }
    private static function excerpt_post($p) {
        return array('id'=>$p->ID,'title'=>get_post_field('post_title',$p->ID,'raw'),'type'=>$p->post_type,'status'=>$p->post_status,'slug'=>$p->post_name,'modified_gmt'=>$p->post_modified_gmt,'permalink'=>get_permalink($p->ID));
    }
    private static function published_marker_balance($before,$after) {
        // If existing content has qTranslate-XT markers, don't allow an edit to remove or add a language block by accident.
        foreach(array('[:en]','[:it]','[:sl]','[:]','<!--:en-->','<!--:it-->','<!--:sl-->','<!--:-->') as $mark) {
            if (substr_count($before,$mark)!==substr_count($after,$mark)) return false;
        }
        return true;
    }
    private static function check_post($id,$cap='read_post') {
        $p=get_post($id);
        if (!$p || !self::safe_post_type($p->post_type)) return new WP_Error('not_found','Content ID was not found or its type is excluded.');
        if (!current_user_can($cap,$id)) return new WP_Error('forbidden','Your WordPress account cannot access this item.');
        return $p;
    }
    public static function run($name,$args,$user_id) {
        $available=array_column(self::definitions(),'name');
        if (!in_array($name,$available,true)) return self::error('Unknown or disabled tool.');
        $write=self::scope($name)==='wp.write';
        $settings=uwmcp_settings();
        if ($write && in_array($name,array('request_plugin_action','request_trash_content','request_cron_removal','request_redirect_log_cleanup','request_log_table_optimisation','request_design_css'),true) && empty($settings['allow_maintenance'])) return self::error('Maintenance requests are disabled in WordPress settings.');
        if ($write && !in_array($name,array('request_plugin_action','request_trash_content','request_cron_removal','request_redirect_log_cleanup','request_log_table_optimisation','request_design_css','request_theme_code_patch','request_theme_code_rollback'),true) && empty($settings['allow_writes'])) return self::error('Content write tools are disabled in WordPress settings.');
        if (!is_array($args))$args=array();
        $previous=get_current_user_id();
        wp_set_current_user($user_id);
        try {
            $result=self::dispatch($name,$args);
            uwmcp_log($name,is_wp_error($result)?'error':'ok',$user_id);
            return is_wp_error($result)?self::error($result->get_error_message()):self::response($result);
        } catch (Throwable $e) {
            uwmcp_log($name,'exception',$user_id);
            return self::error('The operation could not be completed. Inspect WordPress debug logs if the problem persists.');
        } finally {
            wp_set_current_user($previous);
        }
    }
    private static function dispatch($name,$a) {
        global $wpdb;
        switch($name) {
            case 'site_info':
                $theme=wp_get_theme();
                return array('name'=>get_bloginfo('name'),'url'=>home_url('/'),'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'language'=>get_locale(),'theme'=>array('name'=>$theme->get('Name'),'version'=>$theme->get('Version')),'bridge'=>array('version'=>UWMCP_VERSION,'writes_enabled'=>!empty(uwmcp_settings()['allow_writes']),'publishing_approval_enabled'=>!empty(uwmcp_settings()['allow_publish']),'maintenance_requests_enabled'=>!empty(uwmcp_settings()['allow_maintenance']),'code_edits_enabled'=>!empty(uwmcp_settings()['allow_code_edits']),'theme_editor_capability'=>current_user_can('edit_themes'),'file_edit_restricted'=>(defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS)));
            case 'list_content':
                $type=sanitize_key((string)($a['post_type']??'page'));
                if(!self::safe_post_type($type)) return new WP_Error('bad_type','Unknown or private post type.');
                $status=(string)($a['status']??'publish');
                if(!in_array($status,array('publish','draft','pending','future','private','trash','any'),true))return new WP_Error('bad_status','Invalid post status.');
                $limit=min(30,max(1,(int)($a['per_page']??15)));$page=min(100,max(1,(int)($a['page']??1)));
                $query=new WP_Query(array('post_type'=>$type,'post_status'=>$status,'posts_per_page'=>$limit,'paged'=>$page,'s'=>substr(sanitize_text_field((string)($a['search']??'')),0,150),'orderby'=>'modified','order'=>'DESC','no_found_rows'=>false));
                $items=array();foreach($query->posts as $p)if(current_user_can('read_post',$p->ID))$items[]=self::excerpt_post($p);
                return array('items'=>$items,'page'=>$page,'total'=>(int)$query->found_posts,'total_pages'=>(int)$query->max_num_pages);
            case 'get_content':
                $id=absint($a['id']??0);$p=self::check_post($id);
                if(is_wp_error($p))return $p;
                $content=get_post_field('post_content',$id,'raw');
                $raw_title=get_post_field('post_title',$id,'raw');
                return array_merge(self::excerpt_post($p),array('title_raw'=>$raw_title,'content_raw'=>self::text_prefix($content,80000),'content_chars'=>self::text_length($content),'content_truncated'=>self::text_length($content)>80000,'sha256'=>hash('sha256',$content),'edit_url'=>get_edit_post_link($id,'raw')));
            case 'list_media':
                $page=min(100,max(1,(int)($a['page']??1)));$limit=min(30,max(1,(int)($a['per_page']??15)));
                $q=new WP_Query(array('post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>$limit,'paged'=>$page,'orderby'=>'date','order'=>'DESC'));
                $items=array();foreach($q->posts as $p) { if(!current_user_can('read_post',$p->ID))continue;
                    $items[]=array('id'=>$p->ID,'title'=>$p->post_title,'mime'=>$p->post_mime_type,'url'=>wp_get_attachment_url($p->ID),'alt'=>(string)get_post_meta($p->ID,'_wp_attachment_image_alt',true)); }
                return array('items'=>$items,'page'=>$page,'total'=>(int)$q->found_posts);
            case 'find_shortcode':
                $shortcode=(string)($a['shortcode']??'');
                if (!preg_match('/^[A-Za-z0-9_-]{1,60}$/D',$shortcode))return new WP_Error('bad_shortcode','Provide a shortcode name without punctuation.');
                $limit=min(50,max(1,(int)($a['limit']??20)));
                $like='%'.$wpdb->esc_like('['.$shortcode).'%';
                $rows=$wpdb->get_results($wpdb->prepare("SELECT ID,post_type,post_title,post_status FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_status='publish' AND post_type NOT IN ('revision','attachment','nav_menu_item') ORDER BY ID DESC LIMIT %d",$like,$limit),ARRAY_A);
                $items=array();foreach((array)$rows as $r)if(current_user_can('read_post',(int)$r['ID']))$items[]=array('id'=>(int)$r['ID'],'type'=>$r['post_type'],'title'=>$r['post_title'],'permalink'=>get_permalink((int)$r['ID']));
                return array('shortcode'=>$shortcode,'matches'=>$items,'limit'=>$limit);
            case 'list_plugins':
                if(!current_user_can('manage_options'))return new WP_Error('forbidden','Administrators only.');
                require_once ABSPATH.'wp-admin/includes/plugin.php';
                $list=array();$installed=get_plugins();$active=(array)get_option('active_plugins',array());$updates=get_site_transient('update_plugins');
                foreach($installed as $file=>$p){$list[]=array('slug'=>$file,'name'=>$p['Name'],'version'=>$p['Version'],'active'=>in_array($file,$active,true)||is_plugin_active_for_network($file),'update'=>isset($updates->response[$file])?(string)$updates->response[$file]->new_version:null);}
                usort($list,function($a,$b){return strcasecmp($a['name'],$b['name']);});
                return array('count'=>count($list),'plugins'=>$list);
            case 'site_diagnostics':
                $theme=wp_get_theme();
                $tables=array();$total=0;
                $status=$wpdb->get_results($wpdb->prepare('SHOW TABLE STATUS LIKE %s',$wpdb->esc_like($wpdb->prefix).'%'),ARRAY_A);
                foreach((array)$status as $r){$bytes=(int)($r['Data_length']??0)+(int)($r['Index_length']??0);$total+=$bytes;
                    $tables[]=array('table'=>$r['Name'],'approx_mb'=>round($bytes/1048576,2),'estimated_rows'=>(int)($r['Rows']??0));}
                usort($tables,function($a,$b){return $b['approx_mb']<=>$a['approx_mb'];});
                $file_schedule=get_option('updraft_interval','unknown');$db_schedule=get_option('updraft_interval_database','unknown');
                return array('wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'active_theme'=>$theme->get('Name'),'debug'=>(defined('WP_DEBUG') && WP_DEBUG),'database'=>array('approx_mb'=>round($total/1048576,2),'size_note'=>'Allocation estimate from SHOW TABLE STATUS; InnoDB row counts are estimates, not exact.', 'largest_tables'=>array_slice($tables,0,15)),'updraftplus_if_installed'=>array('files_schedule'=>$file_schedule,'database_schedule'=>$db_schedule,'uploads_included'=>(bool)get_option('updraft_include_uploads',false),'remote_destination_configured'=>(bool)get_option('updraft_service',false)));
            case 'inspect_database_table':
                return UWMCP_Diagnostics::inspect_table($a);
            case 'backup_health':
                return UWMCP_Diagnostics::backup_health();
            case 'list_theme_code':
                return UWMCP_Code::list_files();
            case 'read_theme_code':
                return UWMCP_Code::read_file($a);
            case 'request_theme_code_patch':
                return UWMCP_Code::request_patch($a);
            case 'list_theme_code_revisions':
                return UWMCP_Code::list_revisions();
            case 'request_theme_code_rollback':
                return UWMCP_Code::request_rollback($a);
            case 'inspect_design_css':
                return UWMCP_Design::inspect();
            case 'request_design_css':
                return UWMCP_Design::request($a);
            case 'list_cron_hooks':
                $cron=function_exists('_get_cron_array')?_get_cron_array():array();$entries=array();
                $search=substr((string)($a['search']??''),0,100);$truncated=false;
                foreach((array)$cron as $timestamp=>$events)foreach((array)$events as $hook=>$jobs){
                    if($search!=='' && stripos((string)$hook,$search)===false)continue;
                    if(count($entries)>=60){$truncated=true;break 2;}
                    $entries[]=array('hook'=>$hook,'next_run_gmt'=>gmdate('c',(int)$timestamp),'recurrences'=>array_values(array_unique(array_map(function($job){return $job['schedule']??'one-off';},$jobs))));
                }
                return array('events'=>$entries,'truncated'=>$truncated,'search'=>$search);
            case 'create_draft':
                $type=sanitize_key((string)($a['post_type']??'post'));
                if(!in_array($type,array('post','page'),true))return new WP_Error('bad_type','Draft creation supports posts and pages only. Plugin-owned event types need their own APIs.');
                $obj=get_post_type_object($type);
                if(!current_user_can($obj->cap->create_posts))return new WP_Error('forbidden','Your user cannot create this post type.');
                $title=(string)($a['title']??'');$content=(string)($a['content']??'');
                if (trim($title)==='' || self::text_length($title)>250 || self::text_length($content)>100000) return new WP_Error('invalid_content','Title is required; title maximum 250 characters, content maximum 100000 characters.');
                $id=wp_insert_post(array('post_type'=>$type,'post_status'=>'draft','post_title'=>$title,'post_content'=>$content),true);
                if(is_wp_error($id))return $id;
                return array('id'=>$id,'status'=>'draft','edit_url'=>get_edit_post_link($id,'raw'));
            case 'replace_content':
                $id=absint($a['id']??0);$p=self::check_post($id,'edit_post');if(is_wp_error($p))return $p;
                $old=(string)($a['old_text']??'');$new=(string)($a['new_text']??'');
                if($old==='' || strlen($old)>60000 || strlen($new)>100000)return new WP_Error('bad_patch','Old text must be nonempty and snippets must fit within the size limits.');
                $modified=(string)($a['expected_modified_gmt']??'');
                if($modified!=='' && $modified!==$p->post_modified_gmt)return new WP_Error('stale_revision','The content changed since you last read it. Read the page again.');
                $original=get_post_field('post_content',$id,'raw');
                if(substr_count($original,$old)!==1)return new WP_Error('ambiguous_patch','Exact snippet must appear exactly once. Nothing was changed.');
                $next=str_replace($old,$new,$original);
                if(!self::published_marker_balance($original,$next))return new WP_Error('language_markers','This edit would change multilingual language markers. Use smaller edits that preserve the structure.');
                $status=wp_update_post(array('ID'=>$id,'post_content'=>$next),true);
                if(is_wp_error($status))return $status;
                return array('id'=>$id,'updated'=>true,'status'=>get_post_status($id),'sha256'=>hash('sha256',$next),'edit_url'=>get_edit_post_link($id,'raw'));
            case 'set_yoast_seo':
                $id=absint($a['id']??0);$p=self::check_post($id,'edit_post');if(is_wp_error($p))return $p;
                if(!defined('WPSEO_VERSION'))return new WP_Error('plugin_missing','Yoast SEO is not active on this site.');
                $fields=array('seo_title'=>'_yoast_wpseo_title','meta_description'=>'_yoast_wpseo_metadesc','social_description'=>'_yoast_wpseo_opengraph-description');
                $changed=array();
                foreach($fields as $field=>$meta)if(array_key_exists($field,$a)){
                    $text=(string)$a[$field];if(self::text_length($text)>750)return new WP_Error('too_long','SEO metadata too long.');
                    update_post_meta($id,$meta,$text);$changed[]=$field;
                }
                if(!$changed)return new WP_Error('no_fields','Specify at least one SEO field to update.');
                // Using the standard WordPress save hooks lets indexing plugins react normally.
                wp_update_post(array('ID'=>$id,'post_excerpt'=>$p->post_excerpt));
                return array('id'=>$id,'changed'=>$changed,'note'=>'Verify public meta tags; Yoast or CDN caches may need to be rebuilt.');
            case 'request_plugin_action':
                return UWMCP_Operations::request_plugin_action($a);
            case 'request_trash_content':
                return UWMCP_Maintenance::request_trash_content($a);
            case 'request_cron_removal':
                return UWMCP_Maintenance::request_cron_removal($a);
            case 'request_log_table_optimisation':
                return UWMCP_Maintenance::request_log_table_optimisation($a);
            case 'request_redirect_log_cleanup':
                return UWMCP_Maintenance::request_redirect_log_cleanup($a);
            case 'request_publish':
                $settings=uwmcp_settings();if(empty($settings['allow_publish']))return new WP_Error('disabled','Publication approval is disabled in Settings.');
                $id=absint($a['id']??0);$p=self::check_post($id,'edit_post');if(is_wp_error($p))return $p;
                if(!current_user_can('publish_posts'))return new WP_Error('forbidden','Your account cannot publish posts.');
                if($p->post_status!=='draft' && $p->post_status!=='pending')return new WP_Error('invalid_status','Only drafts and pending posts can be submitted for approval.');
                $key=rtrim(strtr(base64_encode(random_bytes(24)),'+/','-_'),'=');
                set_transient('uwmcp_publish_'.hash('sha256',$key),array('post_id'=>$id,'user_id'=>get_current_user_id(),'content_hash'=>hash('sha256',$p->post_content)),600);
                return array('published'=>false,'id'=>$id,'review_url'=>add_query_arg(array('action'=>'uwmcp_confirm_publish','approval'=>$key),admin_url('admin-post.php')),'expires_in'=>600,'instruction'=>'A WordPress administrator must open the review URL and approve publishing.');
        }
        return new WP_Error('no_tool','Tool not found.');
    }
    public static function confirm_publish() {
        $token=isset($_REQUEST['approval']) && is_string($_REQUEST['approval'])?wp_unslash($_REQUEST['approval']):'';
        if(!preg_match('/^[A-Za-z0-9_-]{20,64}$/D',$token))wp_die('Invalid publishing link.');
        if(!is_user_logged_in()){
            $destination=add_query_arg(array('action'=>'uwmcp_confirm_publish','approval'=>$token),admin_url('admin-post.php'));
            wp_safe_redirect(wp_login_url($destination));exit;
        }
        $key='uwmcp_publish_'.hash('sha256',$token);$info=get_transient($key);
        if(!is_array($info))wp_die('Publishing request expired or already used.');
        $id=(int)$info['post_id'];$p=get_post($id);
        if(!$p || get_current_user_id()!==(int)$info['user_id'] || !current_user_can('manage_options') || !current_user_can('edit_post',$id) || !current_user_can('publish_posts'))wp_die('You are not permitted to approve this request.');
        if(hash('sha256',$p->post_content)!==$info['content_hash'] || !in_array($p->post_status,array('draft','pending'),true))wp_die('The content changed or was already published. Request a new review.');
        if($_SERVER['REQUEST_METHOD']==='POST') {
            check_admin_referer('uwmcp_publish_'.$token);
            if(empty($_POST['uwmcp_confirm']))wp_die('Publication cancelled.');
            delete_transient($key);
            $result=wp_update_post(array('ID'=>$id,'post_status'=>'publish'),true);
            if(is_wp_error($result))wp_die('Publishing failed: '.esc_html($result->get_error_message()));
            uwmcp_log('publish_approved','ok',get_current_user_id());
            wp_safe_redirect(get_edit_post_link($id,'raw'));exit;
        }
        nocache_headers();
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Approve publishing</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:560px;margin:10vh auto;padding:20px}button{padding:12px 20px;background:#17202b;color:white;border:0;border-radius:5px}</style></head><body><h1>Publish this WordPress content?</h1>';
        echo '<p><strong>'.esc_html(get_the_title($id)).'</strong></p><p>This changes the item from '.esc_html($p->post_status).' to publicly published. You can <a href="'.esc_url(get_edit_post_link($id,'raw')).'">review the draft</a> first.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uwmcp_confirm_publish"><input type="hidden" name="approval" value="'.esc_attr($token).'">';
        wp_nonce_field('uwmcp_publish_'.$token);
        echo '<button type="submit" name="uwmcp_confirm" value="1">Confirm publication</button></form></body></html>';exit;
    }
}
