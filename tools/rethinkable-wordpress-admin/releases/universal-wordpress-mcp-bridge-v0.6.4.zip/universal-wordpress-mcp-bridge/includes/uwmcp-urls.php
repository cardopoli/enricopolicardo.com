<?php
/** Stable endpoint URLs, intentionally independent of multilingual URL rewriting. */
if (!defined('ABSPATH')) exit;

function uwmcp_site_base() {
    // home_url()/rest_url() can be rewritten to /it/, /en/, etc. by language plugins.
    // The stored home option is the canonical address of the public WordPress installation.
    $home = (string) get_option('home', '');
    if ($home === '') $home = (string) home_url('/');
    return untrailingslashit($home);
}
function uwmcp_rest_endpoint($path) {
    $prefix = function_exists('rest_get_url_prefix') ? rest_get_url_prefix() : 'wp-json';
    return uwmcp_site_base() . '/' . trim($prefix, '/') . '/universal-mcp/v1/' . ltrim($path, '/');
}
function uwmcp_url() { return uwmcp_rest_endpoint('mcp'); }
function uwmcp_issuer() { return uwmcp_site_base(); }
function uwmcp_is_https() {
    return strtolower((string) wp_parse_url(uwmcp_site_base(), PHP_URL_SCHEME)) === 'https';
}
function uwmcp_wellknown_url($type) {
    $suffix = $type === 'authorization' ? 'oauth-authorization-server' : 'oauth-protected-resource';
    return uwmcp_site_base() . '/.well-known/' . $suffix;
}
