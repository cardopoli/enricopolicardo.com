=== Universal WordPress MCP Bridge (Beta) ===
Contributors: community-preview
Tags: mcp, ai, integrations, wordpress, oauth
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 0.6.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A self-hosted, WordPress-native remote MCP bridge with OAuth login and admin-approved content, plugin, cron and limited database maintenance; includes read-only exact row counts and remote-backup checks.

== Description ==

Experimental beta. Installs on any compatible self-hosted WordPress site; no desktop bridge or external vendor service. Disabled by default. HTTPS and WordPress admin OAuth consent required.

Full documentation: README.md inside the plugin ZIP.

== Installation ==

1. Plugins -> Add New -> Upload Plugin, select this ZIP.
2. Activate then go to Settings -> Universal MCP Bridge.
3. Test the health and OAuth discovery URLs, then enable the bridge.
4. Connect using an MCP client that supports remote Streamable HTTP and OAuth dynamic client registration.

== Security ==

Read the README.md. Never enable on an untrusted installation without a backup and testing.

Version 0.5.0 adds opt-in accessible submenu toggles, with admin-only preview; original header navigation remains unchanged.

== Changelog ==

= 0.6.4 =
* New installs allow only claude.ai as an OAuth callback domain by default. Existing installs keep their saved list.
* Documentation is now client-neutral.

= 0.6.0 =
Adds opt-in, same-administrator approved active-theme PHP/JS exact patches with path confinement, PHP syntax check, SHA-256 concurrency protection, and stored rollback revisions. Does not enable code editing for plugins or WordPress core.
