<?php
// Remove this plugin's credentials and settings only. Never remove site content.
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
foreach(array('uwmcp_settings','uwmcp_clients','uwmcp_tokens','uwmcp_audit') as $option)delete_option($option);
